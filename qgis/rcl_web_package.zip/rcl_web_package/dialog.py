"""The RCL Web Package panel."""
import json
import os
import re
import time
import webbrowser

from qgis.core import (
    Qgis,
    QgsApplication,
    QgsAuthMethodConfig,
    QgsLayerTreeGroup,
    QgsLayerTreeLayer,
    QgsMapLayer,
    QgsMapLayerProxyModel,
    QgsCoordinateTransform,
    QgsProject,
    QgsSettings,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.gui import QgsFieldExpressionWidget, QgsFileWidget, QgsMapLayerComboBox, QgsRubberBand
from qgis.PyQt.QtCore import QDate, QDateTime, Qt, QTimer
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDateEdit, QDialog, QDialogButtonBox, QDoubleSpinBox, QFileDialog, QFormLayout,
    QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QProgressDialog,
    QPushButton, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QListWidget, QListWidgetItem, QAbstractItemView, QInputDialog,
    QButtonGroup, QSplitter, QTextBrowser, QWidget, QSpinBox,
)

from .core import boundary as bnd
from .core import package as pkg
from .core import preview_server
from .core.features import default_fields, guess_direction, slug, visible_fields
from .core import winvault
from .core.session import DEFAULT_PUBLIC_KEY, DEFAULT_SITE, DEFAULT_URL, Session, SignedOut, SignInError
from .core.supabase_client import ROLE_NAMES, Portal, PortalError
from .core.tiler import Cancelled

SETTINGS = "rcl_web_package"
SCOPE = "rcl_web_package"


def _settings():
    return QgsSettings()


# ------------------------------------------------------------------ signing in
# Staff sign in with their email, password and a 6-digit code (two-factor). No password or key is kept:
# only the sign-in's refresh token, in order of preference
#   1. Windows Credential Manager (encrypted per Windows user, no extra passwords)
#   2. the QGIS password store (needs a master password; disabled on some installs)
#   3. memory only, for this QGIS session
_SESSION = {}
AUTH_NAME = "RCL map portal sign-in"


def _connection():
    """Supabase address and public key: built in. QGIS settings can point at a test project (not shown in the UI)."""
    s = _settings()
    return (s.value(f"{SETTINGS}/test_supabase_url", "") or DEFAULT_URL,
            s.value(f"{SETTINGS}/test_public_key", "") or DEFAULT_PUBLIC_KEY)


def _save_qgis_store(token):
    am = QgsApplication.authManager()
    if am.isDisabled() or not am.setMasterPassword(True):
        return False
    s = _settings()
    cfg_id = s.value(f"{SETTINGS}/auth_id", "") or ""
    cfg = QgsAuthMethodConfig("Basic")
    if cfg_id and not am.loadAuthenticationConfig(cfg_id, cfg, True):
        cfg, cfg_id = QgsAuthMethodConfig("Basic"), ""
    cfg.setName(AUTH_NAME)
    cfg.setMethod("Basic")
    cfg.setConfig("username", "sign-in")
    cfg.setConfig("password", token)
    if cfg_id and cfg.id():
        ok = am.updateAuthenticationConfig(cfg)
    else:
        ok = am.storeAuthenticationConfig(cfg) and bool(cfg.id())
        if ok:
            s.setValue(f"{SETTINGS}/auth_id", cfg.id())
    check = QgsAuthMethodConfig()
    return bool(ok) and am.loadAuthenticationConfig(cfg.id(), check, True) and check.config("password") == token


def _load_qgis_store():
    cfg_id = _settings().value(f"{SETTINGS}/auth_id", "")
    am = QgsApplication.authManager()
    if not cfg_id or am.isDisabled():
        return None
    cfg = QgsAuthMethodConfig()
    if not am.loadAuthenticationConfig(cfg_id, cfg, True):
        return None
    if cfg.name() != AUTH_NAME:                     # the secret key an older version kept: never used now
        return None
    return cfg.config("password") or None


def _forget_qgis_store():
    cfg_id = _settings().value(f"{SETTINGS}/auth_id", "")
    if cfg_id:
        try:
            QgsApplication.authManager().removeAuthenticationConfig(cfg_id)
        except Exception:  # noqa
            pass
        _settings().remove(f"{SETTINGS}/auth_id")


def _save_token(token):
    """Keep the (rotating) refresh token. Returns where it went: "windows", "qgis", or None (this session only)."""
    _SESSION["token"] = token
    where = _SESSION.get("where")
    if where in (None, "windows") and winvault.save(token):
        _SESSION["where"] = "windows"
    elif where in (None, "qgis") and _save_qgis_store(token):
        _SESSION["where"] = "qgis"
    else:
        _SESSION["where"] = "memory"
    return _SESSION["where"] if _SESSION["where"] != "memory" else None


def _forget_old_key():
    """Older versions kept the portal's secret key on this computer. It's no longer needed: remove it."""
    if _settings().value(f"{SETTINGS}/portal_url", ""):
        winvault.delete(winvault.OLD_TARGET)
        cfg_id = _settings().value(f"{SETTINGS}/auth_id", "")
        cfg = QgsAuthMethodConfig()
        am = QgsApplication.authManager()
        if cfg_id and not am.isDisabled() and am.loadAuthenticationConfig(cfg_id, cfg, False) \
                and cfg.name() != AUTH_NAME:
            _forget_qgis_store()
        for k in ("portal_url", "my_email"):
            _settings().remove(f"{SETTINGS}/{k}")


def sign_out():
    p = _SESSION.pop("portal", None)
    if p is not None:
        p.session.sign_out()
    _SESSION.clear()
    winvault.delete()
    _forget_qgis_store()


def load_portal():
    """The signed-in portal, or None if nobody is signed in on this computer (never prompts)."""
    p = _SESSION.get("portal")
    if p is not None:
        return p
    _forget_old_key()
    token = _SESSION.get("token") or winvault.load() or _load_qgis_store()
    if not token:
        return None
    _SESSION["where"] = "windows" if winvault.load() == token else ("qgis" if _load_qgis_store() == token else "memory")
    url, key = _connection()
    try:
        session = Session.resume(token, url=url, public_key=key, on_refresh=_save_token, timeout=15)
        portal = Portal(session)
        portal.check()
    except SignedOut:
        sign_out()                                  # saved sign-in no longer works: ask again next time
        return None
    except (SignInError, PortalError):
        return None                                 # offline, or not staff any more: try again later
    _SESSION["portal"] = portal
    return portal


def portal_site():
    return _settings().value(f"{SETTINGS}/portal_site", DEFAULT_SITE) or DEFAULT_SITE


# Shared RCL locations, used unless someone has chosen their own folder.
SHARED_ROOT = r"X:\Shared\RuralConsulting\Products+Services\Web Portal"
REGISTER_NAME = "RCL Web Portal register.xlsx"
_OLD_ROOT = os.path.join(os.path.expanduser("~"), "RCL Web Packages")
_OLD_REGISTER = os.path.join(os.path.expanduser("~"), REGISTER_NAME)


def _same(a, b):
    return os.path.normcase(os.path.normpath(a or "")) == os.path.normcase(os.path.normpath(b or ""))


def default_out_root():
    """The shared Web Portal folder, or a folder in the user's home if the X: drive isn't there."""
    return SHARED_ROOT if os.path.isdir(os.path.dirname(SHARED_ROOT)) else _OLD_ROOT


def out_root():
    """Where packages are saved. Settings still pointing at the old per-user default move to the shared folder."""
    saved = _settings().value(f"{SETTINGS}/out_root", "") or ""
    if not saved or _same(saved, _OLD_ROOT):
        return default_out_root()
    return saved


def register_path():
    """Where the customers-and-maps register is kept: the shared Web Portal folder by default.
    The file itself is rewritten from the portal each time, so everyone sees the same list."""
    saved = _settings().value(f"{SETTINGS}/register_path", "") or ""
    if saved and not _same(saved, _OLD_REGISTER):
        return saved
    root = out_root()
    if _same(root, SHARED_ROOT):
        return os.path.join(SHARED_ROOT, REGISTER_NAME)
    base = os.path.dirname(root) if os.path.basename(root.rstrip("\\/")).lower() == "rcl web packages" else root
    return os.path.join(base, REGISTER_NAME)


def _update_register(parent, portal, quiet=False):
    """Rewrite the register spreadsheet from the portal. Returns its path, or None if it couldn't be written."""
    from .core.register import build_register
    path = register_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        build_register(portal, path, portal_site(), out_root(), idle_months())
        return path
    except PermissionError:
        msg = (f"The register couldn't be updated because it's open in Excel:\n{path}\n\n"
               "Close it, then use Published properties > Update register.")
    except (PortalError, OSError) as e:
        msg = f"The register couldn't be updated: {e}"
    if quiet:
        iface = getattr(parent, "iface", None) or getattr(getattr(parent, "parent", lambda: None)(), "iface", None)
        if iface:
            iface.messageBar().pushMessage("RCL portal", msg.replace("\n", " "), Qgis.Warning, 10)
    else:
        QMessageBox.warning(parent, "Register", msg)
    return None


def idle_months():
    """Remind about maps customers haven't opened for this many months (0 = never)."""
    return int(_settings().value(f"{SETTINGS}/idle_months", 12) or 0)


def get_portal(parent, publish=False):
    """The signed-in portal, asking to sign in the first time. publish=True: also needs a publisher or admin."""
    portal = load_portal()
    if portal is None:
        d = PortalSettingsDialog(parent)
        if d.exec_() != QDialog.Accepted or d.portal is None:
            return None
        portal = d.portal
    if publish and not portal.can_publish:
        QMessageBox.information(parent, "RCL portal", f"You're signed in as {portal.email} with the staff role, "
                                "which can look at maps and work the suggestions inbox but not publish or change "
                                "access. Ask an admin to make you a publisher (portal > Staff).")
        return None
    return portal


def require_publisher(parent, portal):
    """True if this person may change the portal; otherwise explains why not."""
    if portal.can_publish:
        return True
    QMessageBox.information(parent, "RCL portal", "Your staff role can look but not change this. "
                            "Ask an admin to make you a publisher (portal > Staff).")
    return False


class PortalSettingsDialog(QDialog):
    """Sign in (email, password, 6-digit code) and the tool's settings."""

    def __init__(self, parent=None):
        super().__init__(parent)
        _forget_old_key()
        self.setWindowTitle("Sign in to the RCL portal")
        self.setMinimumWidth(480)
        self.portal = load_portal()
        form = QFormLayout(self)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.out_b = QPushButton("Sign out")
        self.out_b.clicked.connect(self._sign_out)
        r = QHBoxLayout()
        r.addWidget(self.status, 1)
        r.addWidget(self.out_b)
        form.addRow(r)
        self.email = QLineEdit(_settings().value(f"{SETTINGS}/last_email", ""))
        self.email.setPlaceholderText("you@ruralconsulting.co.nz")
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.code = QLineEdit()
        self.code.setPlaceholderText("6-digit code from your authenticator app")
        self.code.setMaxLength(7)
        self.code.setInputMask("")
        self.signin_box = QGroupBox("Sign in")
        f2 = QFormLayout(self.signin_box)
        f2.addRow("Email", self.email)
        f2.addRow("Password", self.password)
        f2.addRow("Code", self.code)
        help_ = QLabel(f"Use your RCL portal sign-in. First time? Sign in at <a href=\"{DEFAULT_SITE}\">{DEFAULT_SITE}</a> "
                       "to set up two-factor (an authenticator app on your phone), then sign in here. "
                       "Your password isn't kept on this computer.")
        help_.setWordWrap(True)
        help_.setOpenExternalLinks(True)
        f2.addRow(help_)
        form.addRow(self.signin_box)
        self.site = QLineEdit(portal_site())
        self.site.setToolTip("Goes in the sign-in details you send customers")
        self.reg = QgsFileWidget()
        self.reg.setStorageMode(QgsFileWidget.SaveFile)
        self.reg.setFilter("Excel workbook (*.xlsx)")
        self.reg.setFilePath(register_path())
        form.addRow("Portal web address", self.site)
        form.addRow("Register spreadsheet", self.reg)
        self.idle = QSpinBox()
        self.idle.setRange(0, 60)
        self.idle.setSuffix(" months")
        self.idle.setSpecialValueText("Never")
        self.idle.setValue(idle_months())
        self.idle.setToolTip("When QGIS starts, mention maps that customers haven't opened for this long, so you can "
                             "take them offline to save space (Published properties > Clean up...).")
        form.addRow("Unused maps reminder", self.idle)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.ok_b = bb.button(QDialogButtonBox.Ok)
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        form.addRow(bb)
        self.code.returnPressed.connect(self._save)
        self._show_state()
        if self.portal is None:
            (self.password if self.email.text() else self.email).setFocus()

    def _show_state(self):
        p = self.portal
        if p is not None:
            self.status.setText(f"Signed in as <b>{p.email}</b> ({ROLE_NAMES.get(p.role, p.role)}).")
        else:
            self.status.setText("Not signed in.")
        self.out_b.setVisible(p is not None)
        self.signin_box.setVisible(p is None)
        self.ok_b.setText("Save" if p is not None else "Sign in")
        self.adjustSize()

    def _sign_out(self):
        sign_out()
        self.portal = None
        self._show_state()
        self.password.setFocus()

    def _save_settings(self):
        _settings().setValue(f"{SETTINGS}/idle_months", self.idle.value())
        _settings().setValue(f"{SETTINGS}/portal_site", self.site.text().strip().rstrip("/") or DEFAULT_SITE)
        if self.reg.filePath().strip():
            _settings().setValue(f"{SETTINGS}/register_path", self.reg.filePath().strip())

    def _save(self):
        if self.portal is not None:
            self._save_settings()
            self.accept()
            return
        email, pw, code = self.email.text().strip().lower(), self.password.text(), self.code.text().strip()
        if "@" not in email or not pw:
            QMessageBox.warning(self, "Sign in", "Enter your email address and password.")
            return
        if not code:
            QMessageBox.warning(self, "Sign in", "Enter the 6-digit code from your authenticator app.")
            self.code.setFocus()
            return
        url, key = _connection()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            _SESSION.pop("where", None)
            session = Session(url=url, public_key=key, on_refresh=_save_token)
            session.sign_in(email, pw, code)
            portal = Portal(session)
            portal.check()
        except (SignInError, PortalError) as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Sign in", str(e))
            self.code.clear()
            self.code.setFocus()
            return
        QApplication.restoreOverrideCursor()
        self.password.clear()
        _settings().setValue(f"{SETTINGS}/last_email", email)
        _SESSION["portal"] = portal
        self.portal = portal
        self._save_settings()
        if _SESSION.get("where") == "memory":
            QMessageBox.warning(self, "Sign in", "Signed in, but this computer couldn't keep the sign-in, so you'll "
                                "need to sign in again after closing QGIS.")
        self.accept()


def show_credentials(parent, creds, existing=()):
    """Show new sign-in details once, ready to copy into an email or text."""
    if not creds and not existing:
        return
    site = portal_site()
    parts = []
    for email, pw in creds:
        parts.append(f"Your farm maps are ready at {site}\n\nEmail: {email}\nPassword: {pw}\n\n"
                     "You can change your password after signing in (link at the bottom of the map panel).")
    if existing:
        parts.append("Already had an account (they use their existing password):\n" + "\n".join(existing))
    text = "\n\n----------\n\n".join(parts)
    d = QDialog(parent)
    d.setWindowTitle("Sign-in details")
    d.setMinimumSize(520, 340)
    lay = QVBoxLayout(d)
    note = QLabel("<b>Copy these now.</b> Passwords aren't stored anywhere you can look them up later; "
                  "if one is lost, use Published properties > Reset password.")
    note.setWordWrap(True)
    lay.addWidget(note)
    box = QPlainTextEdit(text)
    box.setReadOnly(True)
    lay.addWidget(box, 1)
    bb = QDialogButtonBox(QDialogButtonBox.Close)
    copy = bb.addButton("Copy", QDialogButtonBox.ActionRole)
    copy.clicked.connect(lambda: (QApplication.clipboard().setText(text), copy.setText("Copied")))
    bb.rejected.connect(d.reject)
    lay.addWidget(bb)
    d.exec_()


def _nice_date(iso):
    d = QDate.fromString(str(iso)[:10], "yyyy-MM-dd")
    return d.toString("d MMM yyyy") if d.isValid() else str(iso)[:10]


STATUS_LABELS = {"new": "New", "in_progress": "In progress", "done": "Done", "not_changed": "Not changed"}
STATUS_COLORS = {"new": "#e8590c", "in_progress": "#1c7ed6", "done": "#2f9e44", "not_changed": "#868e96"}
SHOW = [("open", "Open (new and in progress)"), ("new", "New"), ("in_progress", "In progress"), ("done", "Done"),
        ("not_changed", "Not changed"), ("all", "All")]


def _h(text):
    return str(text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")


def _when(iso):
    d = QDateTime.fromString(str(iso)[:19], "yyyy-MM-ddTHH:mm:ss")
    if not d.isValid():
        return _nice_date(iso)
    d.setTimeSpec(Qt.UTC)
    return d.toLocalTime().toString("d MMM yyyy, h:mm ap")


class SuggestionsDialog(QDialog):
    """Suggestions inbox: customers' suggested changes for every property (or one), with status, reply,
    internal notes, history and delete. The same as the inbox in the portal."""

    def __init__(self, portal, farm=None, iface=None, photo_root=None, parent=None, select=None):
        super().__init__(parent)
        self.portal, self.farm, self.iface = portal, farm, iface
        self.photo_root = photo_root or out_root()
        self.rows, self.farms, self.maps = [], {}, {}
        self.setWindowTitle(f"Suggestions: {farm['name']}" if farm else "Suggestions inbox")
        self.resize(1060, 700)
        lay = QVBoxLayout(self)

        top = QHBoxLayout()
        top.addWidget(QLabel("Show"))
        self.show_c = QComboBox()
        for k, label in SHOW:
            self.show_c.addItem(label, k)
        top.addWidget(self.show_c)
        self.farm_c = QComboBox()
        if not farm:
            top.addSpacing(10)
            top.addWidget(QLabel("Property"))
            top.addWidget(self.farm_c, 1)
        else:
            self.show_c.setCurrentIndex(len(SHOW) - 1)          # one property: show everything
        top.addStretch(1)
        self.refresh_b = QPushButton("Refresh")
        self.web_b = QPushButton("Open the portal inbox")
        self.web_b.setToolTip("The same inbox in your web browser (works on a phone too)")
        top.addWidget(self.refresh_b)
        top.addWidget(self.web_b)
        lay.addLayout(top)

        split = QSplitter(Qt.Horizontal)
        self.list = QTreeWidget()
        self.list.setHeaderLabels(["Date", "Property", "Map", "From", "Suggestion", "Photos", "Status"])
        self.list.setRootIsDecorated(False)
        self.list.setColumnHidden(1, bool(farm))
        self.list.header().setSectionResizeMode(4, QHeaderView.Stretch)
        for c in (0, 1, 2, 3, 5, 6):
            self.list.header().setSectionResizeMode(c, QHeaderView.ResizeToContents)
        split.addWidget(self.list)

        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(8, 0, 0, 0)
        self.detail = QLabel("")
        self.detail.setWordWrap(True)
        self.detail.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.detail.setAlignment(Qt.AlignTop)
        rl.addWidget(self.detail)
        srow = QHBoxLayout()
        srow.addWidget(QLabel("Status"))
        self.status_g = QButtonGroup(self)
        self.status_g.setExclusive(True)
        for k, label in STATUS_LABELS.items():
            b = QPushButton(label)
            b.setCheckable(True)
            b.setProperty("status", k)
            self.status_g.addButton(b)
            srow.addWidget(b)
        srow.addStretch(1)
        rl.addLayout(srow)
        rl.addWidget(QLabel("Reply to the customer (they see it on the map)"))
        self.reply = QPlainTextEdit()
        self.reply.setPlaceholderText("e.g. Thanks, we've updated the fence line in the 16 Oct map")
        self.reply.setFixedHeight(60)
        rl.addWidget(self.reply)
        self.reply_b = QPushButton("Save reply")
        rr = QHBoxLayout()
        rr.addWidget(self.reply_b)
        rr.addStretch(1)
        rl.addLayout(rr)
        rl.addWidget(QLabel("Internal note (only RCL staff see these)"))
        self.note = QPlainTextEdit()
        self.note.setPlaceholderText("What you've done or still need to do")
        self.note.setFixedHeight(48)
        rl.addWidget(self.note)
        self.note_b = QPushButton("Add note")
        nr = QHBoxLayout()
        nr.addWidget(self.note_b)
        nr.addStretch(1)
        rl.addLayout(nr)
        rl.addWidget(QLabel("History"))
        self.history = QTextBrowser()
        self.history.setOpenLinks(False)
        rl.addWidget(self.history, 1)
        ar = QHBoxLayout()
        self.onweb_b = QPushButton("See it on the web map")
        self.del_b = QPushButton("Delete…")
        ar.addWidget(self.onweb_b)
        ar.addStretch(1)
        ar.addWidget(self.del_b)
        rl.addLayout(ar)
        split.addWidget(right)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        lay.addWidget(split, 1)

        bb = QHBoxLayout()
        self.map_b = QPushButton("Show these on the QGIS map")
        self.map_b.setToolTip("Adds the suggestions in the list (with photos) to your project as a point layer")
        close = QPushButton("Close")
        bb.addWidget(self.map_b)
        bb.addStretch(1)
        bb.addWidget(close)
        lay.addLayout(bb)

        self.list.currentItemChanged.connect(self._pick)
        self.show_c.currentIndexChanged.connect(lambda *_: self._fill())
        self.farm_c.currentIndexChanged.connect(lambda *_: self._fill())
        self.refresh_b.clicked.connect(lambda: self._load(self._current_id()))
        self.web_b.clicked.connect(lambda: webbrowser.open(portal_site().rstrip("/") + "/#~inbox"
                                                          + (("/" + self._current_id()) if self._current_id() else "")))
        self.status_g.buttonClicked.connect(self._set_status)
        self.reply_b.clicked.connect(self._save_reply)
        self.note_b.clicked.connect(self._add_note)
        self.onweb_b.clicked.connect(self._on_web)
        self.del_b.clicked.connect(self._delete)
        self.map_b.clicked.connect(self._to_map)
        close.clicked.connect(self.accept)
        self._load(select)

    # ---------------------------------------------------------------- data
    def _current(self):
        it = self.list.currentItem()
        return it.data(0, Qt.UserRole) if it else None

    def _current_id(self):
        r = self._current()
        return r["id"] if r else None

    def _load(self, select=None):
        try:
            self.rows = self.portal.suggestions(self.farm["id"] if self.farm else None)
            farms = [self.farm] if self.farm else self.portal.list_farms()
            self.farms = {f["id"]: f for f in farms}
            self.maps = {m["id"]: m for m in self.portal.all_maps()}
        except PortalError as e:
            QMessageBox.warning(self, "Suggestions", str(e))
            self.rows = []
        if not self.farm:
            keep = self.farm_c.currentData()
            self.farm_c.blockSignals(True)
            self.farm_c.clear()
            self.farm_c.addItem("All properties", None)
            for fid in sorted({r["farm_id"] for r in self.rows}, key=lambda i: self._farm_name(i).lower()):
                self.farm_c.addItem(self._farm_name(fid), fid)
            self.farm_c.setCurrentIndex(max(0, self.farm_c.findData(keep)))
            self.farm_c.blockSignals(False)
        if select and not any(r["id"] == select for r in self._shown()):
            self.show_c.setCurrentIndex(len(SHOW) - 1)            # make sure the one asked for is in the list
        self._fill(select)

    def _farm_name(self, fid):
        f = self.farms.get(fid)
        return f["name"] if f else "Property removed"

    def _shown(self):
        k, fid = self.show_c.currentData(), self.farm_c.currentData() if not self.farm else None
        return [r for r in self.rows
                if (k == "all" or (k == "open" and r["status"] in ("new", "in_progress")) or r["status"] == k)
                and (not fid or r["farm_id"] == fid)]

    def _fill(self, select=None):
        select = select or self._current_id()
        self.list.blockSignals(True)
        self.list.clear()
        for r in self._shown():
            m = self.maps.get(r.get("map_id")) or {}
            it = QTreeWidgetItem([_nice_date(r["created_at"]), self._farm_name(r["farm_id"]), m.get("title", ""),
                                  r.get("author_email") or "", r["body"].replace("\n", " ")[:120],
                                  str(len(r.get("photos") or [])) if r.get("photos") else "",
                                  STATUS_LABELS.get(r["status"], r["status"])])
            it.setData(0, Qt.UserRole, r)
            it.setForeground(6, QColor(STATUS_COLORS.get(r["status"], "#000")))
            self.list.addTopLevelItem(it)
            if select and r["id"] == select:
                self.list.setCurrentItem(it)
        if self.list.currentItem() is None and self.list.topLevelItemCount():
            self.list.setCurrentItem(self.list.topLevelItem(0))
        self.list.blockSignals(False)
        self.map_b.setEnabled(self.list.topLevelItemCount() > 0)
        self._pick(self.list.currentItem())

    def _pick(self, it, *_):
        r = it.data(0, Qt.UserRole) if it else None
        for w in [self.reply, self.reply_b, self.note, self.note_b, self.onweb_b, self.del_b] + self.status_g.buttons():
            w.setEnabled(r is not None)
        if r is None:
            self.detail.setText("No suggestions yet." if not self.rows else "Nothing here with this filter.")
            self.history.clear()
            self.reply.setPlainText("")
            return
        m = self.maps.get(r.get("map_id")) or {}
        about = " · ".join(x for x in (r.get("layer_title"), r.get("feature_label")) if x) or "A spot on the map"
        n = len(r.get("photos") or [])
        self.detail.setText(
            f"<span style='color:{STATUS_COLORS.get(r['status'])}'><b>{STATUS_LABELS.get(r['status'], r['status'])}</b></span>"
            f" · {_h(self._farm_name(r['farm_id']))}{(' · ' + _h(m['title'])) if m else ''}"
            f"<h3 style='margin:4px 0'>{_h(about)}</h3><p style='margin:0 0 6px'>{_h(r['body'])}</p>"
            f"<small>From {_h(r.get('author_email'))}, {_when(r['created_at'])}"
            f"{f' · {n} photo' + ('s' if n > 1 else '') + ' (Show these on the QGIS map, or see it on the web map)' if n else ''}</small>")
        for b in self.status_g.buttons():
            b.setChecked(b.property("status") == r["status"])
        self.reply.setPlainText(r.get("reply") or "")
        self.note.setPlainText("")
        self._history(r)

    def _history(self, r):
        try:
            events = self.portal.suggestion_events(r["id"])
        except PortalError as e:
            self.history.setHtml(f"<i>Couldn't load the history: {_h(e)}</i>")
            return
        lines = []
        for e in events:
            k = e["kind"]
            if k == "created":
                what = "Sent the suggestion"
            elif k == "status":
                what = "Status: " + STATUS_LABELS.get(e.get("status"), e.get("status") or "")
            elif k == "reply":
                what = f"Replied: <i>“{_h(e['body'])}”</i>" if e.get("body") else "Removed the reply"
            elif k == "note":
                what = f"<span style='background:#fff7e0;color:#231f20'><b>Note:</b> {_h(e.get('body'))}</span>"
            else:
                what = _h(e.get("body") or k)
            lines.append(f"<p style='margin:0 0 6px'><small style='color:gray'>{_when(e['at'])} · {_h(e.get('by_email'))}</small><br>{what}</p>")
        self.history.setHtml("".join(lines) or "<i>Nothing yet.</i>")
        sb = self.history.verticalScrollBar()
        sb.setValue(sb.maximum())                    # latest at the bottom, in view

    # ---------------------------------------------------------------- actions
    def _set_status(self, button):
        r = self._current()
        if not r or button.property("status") == r["status"]:
            return
        try:
            self.portal.update_suggestion(r["id"], status=button.property("status"))
        except PortalError as e:
            QMessageBox.warning(self, "Suggestions", str(e))
        self._load(r["id"])

    def _save_reply(self):
        r = self._current()
        if not r or (self.reply.toPlainText().strip() or None) == (r.get("reply") or None):
            return
        try:
            self.portal.update_suggestion(r["id"], reply=self.reply.toPlainText())
        except PortalError as e:
            QMessageBox.warning(self, "Suggestions", str(e))
        self._load(r["id"])

    def _add_note(self):
        r = self._current()
        if not r or not self.note.toPlainText().strip():
            return
        try:
            self.portal.add_note(r["id"], self.note.toPlainText())
        except PortalError as e:
            QMessageBox.warning(self, "Suggestions", str(e))
            return
        self.note.setPlainText("")
        self._history(r)

    def _on_web(self):
        r = self._current()
        f, m = self.farms.get(r["farm_id"]) if r else None, self.maps.get(r.get("map_id")) if r else None
        if f and m:
            webbrowser.open(f"{portal_site().rstrip('/')}/#{f['slug']}/{m['slug']}/s:{r['id']}")

    def _delete(self):
        r = self._current()
        if not r:
            return
        if QMessageBox.question(self, "Delete suggestion", "Delete this suggestion, its photos and history? The customer "
                                "won't see it any more. This can't be undone.") != QMessageBox.Yes:
            return
        try:
            self.portal.delete_suggestion(r)
        except PortalError as e:
            QMessageBox.warning(self, "Delete suggestion", str(e))
        self._load()

    def _to_map(self):
        from qgis.core import (QgsCategorizedSymbolRenderer, QgsEditorWidgetSetup, QgsFeature, QgsGeometry,
                               QgsMarkerSymbol, QgsPointXY, QgsRendererCategory)
        rows = self._shown()
        if not rows:
            return
        name = f"Suggestions – {self.farm['name']}" if self.farm else "Suggestions – RCL portal"
        prj = QgsProject.instance()
        for old in prj.mapLayersByName(name):
            prj.removeMapLayer(old.id())
        uri = ("Point?crs=EPSG:4326&field=id:string&field=status:string&field=created:string&field=author:string"
               "&field=property:string&field=map:string&field=about:string&field=comment:string(4000)&field=reply:string(4000)"
               "&field=photo1:string&field=photo2:string&field=photo3:string&field=photo_count:integer")
        lyr = QgsVectorLayer(uri, name, "memory")
        feats = []
        prog = QProgressDialog("Fetching photos…", None, 0, len(rows), self)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(400)
        for i, r in enumerate(rows):
            prog.setValue(i)
            QApplication.processEvents()
            f_ = self.farms.get(r["farm_id"]) or {}
            folder = os.path.join(self.photo_root, f_.get("slug") or slug(self._farm_name(r["farm_id"])), "suggestions")
            local = []
            for j, path in enumerate(r.get("photos") or []):
                dest = os.path.join(folder, r["id"], f"{j + 1}.jpg")
                try:
                    if os.path.isfile(dest) or self.portal.download_photo(path, dest):
                        local.append(dest)
                except PortalError:
                    pass
            f = QgsFeature(lyr.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(r["lng"], r["lat"])))
            about = " · ".join(x for x in (r.get("layer_title"), r.get("feature_label")) if x)
            f.setAttributes([r["id"], STATUS_LABELS.get(r["status"], r["status"]), str(r["created_at"])[:16].replace("T", " "),
                             r.get("author_email"), self._farm_name(r["farm_id"]),
                             (self.maps.get(r.get("map_id")) or {}).get("title", ""), about, r["body"], r.get("reply"),
                             *(local + [None, None, None])[:3], len(r.get("photos") or [])])
            feats.append(f)
        prog.close()
        lyr.dataProvider().addFeatures(feats)
        lyr.updateExtents()
        for fld in ("photo1", "photo2", "photo3"):
            lyr.setEditorWidgetSetup(lyr.fields().indexOf(fld), QgsEditorWidgetSetup(
                "ExternalResource", {"DocumentViewer": 1, "DocumentViewerHeight": 320, "FileWidget": False}))
        cats = []
        for k, label in STATUS_LABELS.items():
            sym = QgsMarkerSymbol.createSimple({"name": "circle", "color": STATUS_COLORS[k], "size": "4",
                                                "outline_color": "white", "outline_width": "0.6"})
            cats.append(QgsRendererCategory(label, sym, label))
        lyr.setRenderer(QgsCategorizedSymbolRenderer("status", cats))
        lyr.setDisplayExpression('"comment"')
        lyr.setMapTipTemplate('<b>[% "status" %]</b> · [% "property" %] · [% "author" %] · [% "created" %]<br>[% "about" %]'
                              '<p>[% "comment" %]</p>[% CASE WHEN "photo1" IS NOT NULL THEN '
                              "'<img width=\"280\" src=\"file:///' || replace(\"photo1\", '\\\\', '/') || '\">' END %]")
        prj.addMapLayer(lyr)
        if self.iface:
            canvas = self.iface.mapCanvas()
            ext = QgsCoordinateTransform(lyr.crs(), canvas.mapSettings().destinationCrs(), prj).transformBoundingBox(lyr.extent())
            ext.grow(max(ext.width(), ext.height(), 200) * 0.3)
            canvas.setExtent(ext)
            canvas.refresh()
            self.iface.messageBar().pushMessage(
                "Suggestions", f"Added {len(feats)} suggestions to the map. Click one with Identify to see its photos.",
                Qgis.Info, 8)


def open_inbox(iface, parent=None, select=None):
    """The suggestions inbox for every property (toolbar button, panel button, startup notice)."""
    portal = get_portal(parent or (iface.mainWindow() if iface else None))
    if portal is None:
        return
    SuggestionsDialog(portal, None, iface, None, parent or (iface.mainWindow() if iface else None), select=select).exec_()


def open_staff_page():
    """Staff are managed in the portal now (admins only): who is staff, their role, two-factor and passwords."""
    webbrowser.open(DEFAULT_SITE.rstrip("/") + "/#~staff")


class CleanupDialog(QDialog):
    """Every map on the portal with its size online and when customers last opened it. Maps nobody uses can be
    taken offline to save space; the copy on this computer is kept, and publishing it again brings the map back."""

    def __init__(self, portal, parent=None, report=None):
        super().__init__(parent)
        from .core.register import folder_size, local_folder
        self._folder_size, self._local_folder = folder_size, local_folder
        self.portal = portal
        self.setWindowTitle("Clean up the portal")
        self.resize(1000, 580)
        lay = QVBoxLayout(self)
        intro = QLabel("Taking a map offline removes it (and its earlier version) from the portal to free up space. "
                       "Customers stop seeing it. The map's record, people's access and suggestions stay, and the copy "
                       "in your packages folder isn't touched: to bring it back, use Publish to portal with that saved "
                       "package and choose “New version of …”.")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        top = QHBoxLayout()
        top.addWidget(QLabel("Tick maps customers haven't opened for"))
        self.months = QSpinBox()
        self.months.setRange(1, 60)
        self.months.setValue(idle_months() or 12)
        self.months.setSuffix(" months")
        top.addWidget(self.months)
        top.addStretch(1)
        self.total = QLabel("")
        top.addWidget(self.total)
        lay.addLayout(top)
        self.list = QTreeWidget()
        self.list.setHeaderLabels(["Property / map", "Last opened by a customer", "Published", "Online", "Copy on this computer"])
        self.list.setRootIsDecorated(False)
        self.list.header().setSectionResizeMode(0, QHeaderView.Stretch)
        for c in (1, 2, 3, 4):
            self.list.header().setSectionResizeMode(c, QHeaderView.ResizeToContents)
        lay.addWidget(self.list, 1)
        bb = QHBoxLayout()
        self.sel = QLabel("")
        self.go = QPushButton("Take ticked maps offline…")
        close = QPushButton("Close")
        bb.addWidget(self.sel, 1)
        bb.addWidget(self.go)
        bb.addWidget(close)
        lay.addLayout(bb)
        self.months.valueChanged.connect(self._tick_idle)
        self.list.itemChanged.connect(self._count)
        self.go.clicked.connect(self._go)
        close.clicked.connect(self.accept)
        self._load(report)

    def _load(self, report=None):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self.report = report or self.portal.storage_report()
        except PortalError as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Clean up", str(e))
            self.report = {"maps": [], "farms": {}, "photos": 0}
        finally:
            if QApplication.overrideCursor():
                QApplication.restoreOverrideCursor()
        root = out_root()
        self.list.blockSignals(True)
        self.list.clear()
        for r in sorted(self.report["maps"], key=lambda r: (r["farm"]["name"].lower(), r["map"]["title"].lower())):
            local = self._local_folder(root, r["farm"], r["map"])
            lbytes, builds = self._folder_size(local)
            r["local"], r["local_bytes"] = local, lbytes
            it = QTreeWidgetItem([f"{r['farm']['name']} · {r['map']['title']}",
                                  _nice_date(r["last_visit"]) if r["last_visit"] else "never",
                                  _nice_date(r["published_at"]) if r["published_at"] else "",
                                  f"{(r['online_bytes'] or 0) / 1e6:,.0f} MB" if not r["archived_at"] else
                                  "offline since " + _nice_date(r["archived_at"]),
                                  f"yes, {lbytes / 1e6:,.0f} MB" if lbytes is not None else "not found"])
            it.setData(0, Qt.UserRole, r)
            if r["archived_at"] or not r["published_at"]:
                it.setFlags(it.flags() & ~Qt.ItemIsEnabled)
            else:
                it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
                it.setCheckState(0, Qt.Unchecked)
            if lbytes is None and not r["archived_at"]:
                it.setToolTip(4, "No package folder found for this map in your packages folder. If you take it offline "
                                 "you'd need to build it again from the QGIS project to republish it.")
            self.list.addTopLevelItem(it)
        self.list.blockSignals(False)
        online = sum(self.report["farms"].values())
        self.total.setText(f"On the portal: {online / 1e9:.2f} GB of maps, "
                           f"{self.report['photos'] / 1e9:.2f} GB of suggestion photos")
        self._tick_idle()

    def _tick_idle(self, *_):
        from .core.register import idle_maps
        idle = {r["map"]["id"] for r in idle_maps(self.report, self.months.value())}
        self.list.blockSignals(True)
        for i in range(self.list.topLevelItemCount()):
            it = self.list.topLevelItem(i)
            if it.flags() & Qt.ItemIsUserCheckable:
                it.setCheckState(0, Qt.Checked if it.data(0, Qt.UserRole)["map"]["id"] in idle else Qt.Unchecked)
        self.list.blockSignals(False)
        self._count()

    def _ticked(self):
        return [self.list.topLevelItem(i).data(0, Qt.UserRole) for i in range(self.list.topLevelItemCount())
                if self.list.topLevelItem(i).flags() & Qt.ItemIsUserCheckable
                and self.list.topLevelItem(i).checkState(0) == Qt.Checked]

    def _count(self, *_):
        t = self._ticked()
        mb = sum(r["online_bytes"] or 0 for r in t) / 1e6
        self.sel.setText(f"{len(t)} ticked, about {mb:,.0f} MB online" if t else "Nothing ticked")
        self.go.setEnabled(bool(t) and self.portal.can_publish)
        if not self.portal.can_publish:
            self.go.setToolTip("Needs the publisher role (ask an admin: portal > Staff)")

    def _go(self):
        t = self._ticked()
        missing = [f"{r['farm']['name']} · {r['map']['title']}" for r in t if r.get("local_bytes") is None]
        msg = "Take these maps offline? Customers stop seeing them.\n\n" + \
              "\n".join(f"• {r['farm']['name']} · {r['map']['title']}" for r in t)
        if missing:
            msg += ("\n\nNo copy was found in your packages folder for:\n" + "\n".join("• " + m for m in missing) +
                    "\nTo publish these again you'd build them from their QGIS project.")
        if QMessageBox.question(self, "Take maps offline", msg) != QMessageBox.Yes:
            return
        freed = 0
        prog = QProgressDialog("Taking maps offline…", None, 0, len(t), self)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(0)
        try:
            for i, r in enumerate(t):
                prog.setValue(i)
                prog.setLabelText(f"{r['farm']['name']} · {r['map']['title']}")
                QApplication.processEvents()
                freed += self.portal.take_offline(r["farm"]["id"], r["map"]["id"])
        except PortalError as e:
            QMessageBox.warning(self, "Take maps offline", str(e))
        prog.close()
        _update_register(self, self.portal, quiet=True)
        QMessageBox.information(self, "Take maps offline", f"Done. {freed / 1e6:,.0f} MB freed on the portal.")
        self._load()


class AccessDialog(QDialog):
    """Published properties: who can see each one, its map versions, deleting it."""

    def __init__(self, portal, farm_name="", parent=None):
        super().__init__(parent)
        self.portal = portal
        self.setWindowTitle("Published properties")
        self.setMinimumWidth(820)
        lay = QFormLayout(self)
        self.farm = QComboBox()
        self._reload_farms(farm_name)
        lay.addRow("Property", self.farm)
        self.maps = QTreeWidget()
        self.maps.setHeaderLabels(["Map", "Type", "Published", "Surveyed", "Earlier version"])
        self.maps.setRootIsDecorated(False)
        self.maps.setMinimumHeight(110)
        self.maps.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.maps.header().setMinimumSectionSize(90)
        for c in (1, 2, 3, 4):
            self.maps.header().setSectionResizeMode(c, QHeaderView.ResizeToContents)
        lay.addRow("Maps", self.maps)
        r0 = QHBoxLayout()
        self.open_b = QPushButton("Open in portal")
        self.edit_b = QPushButton("Edit details…")
        self.edit_b.setToolTip("Change the map's title, type and description")
        self.restore_b = QPushButton("Previous version")
        self.restore_b.setToolTip("Show customers this map's previous published version again (the current one is kept)")
        self.delmap_b = QPushButton("Delete map…")
        for b in (self.open_b, self.edit_b, self.restore_b, self.delmap_b):
            r0.addWidget(b)
        r0.addStretch(1)
        lay.addRow("", r0)
        self.info = QLabel("")
        self.info.setWordWrap(True)
        r_s = QHBoxLayout()
        self.sugg_label = QLabel("")
        self.sugg_b = QPushButton("Suggestions…")
        r_s.addWidget(self.sugg_label, 1)
        r_s.addWidget(self.sugg_b)
        lay.addRow("Suggestions", r_s)
        self.people = QListWidget()
        self.people.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.people.setMinimumHeight(140)
        lay.addRow("Has access", self.people)
        r = QHBoxLayout()
        self.reset_b = QPushButton("Reset password")
        self.remove_b = QPushButton("Remove access")
        r.addWidget(self.reset_b)
        r.addWidget(self.remove_b)
        r.addStretch(1)
        lay.addRow("", r)
        r2 = QHBoxLayout()
        self.new = QLineEdit()
        self.new.setPlaceholderText("email addresses, separated by commas")
        self.add_b = QPushButton("Give access")
        r2.addWidget(self.new, 1)
        r2.addWidget(self.add_b)
        lay.addRow("Add people", r2)
        bb = QDialogButtonBox(QDialogButtonBox.Close)
        self.delete_b = bb.addButton("Delete property…", QDialogButtonBox.ActionRole)
        reg_b = bb.addButton("Update register", QDialogButtonBox.ActionRole)
        reg_b.setToolTip("Rewrite the customers-and-maps spreadsheet: " + register_path())
        reg_b.clicked.connect(self._register)
        clean_b = self.clean_b = bb.addButton("Clean up…", QDialogButtonBox.ActionRole)
        clean_b.setToolTip("Sizes on the portal, and taking maps customers no longer open offline to save space")
        clean_b.clicked.connect(lambda: (CleanupDialog(self.portal, self).exec_(), self._load()))
        staff_b = bb.addButton("RCL staff…", QDialogButtonBox.ActionRole)
        staff_b.setToolTip("Opens the Staff page in the portal (admins): add staff, set roles, reset passwords "
                           "and two-factor")
        staff_b.clicked.connect(open_staff_page)
        staff_b.setVisible(self.portal.is_admin)
        bb.rejected.connect(self.reject)
        lay.addRow(bb)
        self.farm.currentTextChanged.connect(self._load)
        self.open_b.clicked.connect(self._open)
        self.edit_b.clicked.connect(self._edit_map)
        self.restore_b.clicked.connect(self._restore)
        self.delmap_b.clicked.connect(self._delete_map)
        self.maps.currentItemChanged.connect(self._map_changed)
        self.maps.itemDoubleClicked.connect(lambda *_: self._edit_map())
        self.delete_b.clicked.connect(self._delete)
        self.sugg_b.clicked.connect(self._suggestions)
        self.reset_b.clicked.connect(self._reset)
        self.remove_b.clicked.connect(self._remove)
        self.add_b.clicked.connect(self._add)
        self.new.returnPressed.connect(self._add)
        self._load()

    def _farm(self):
        return next((f for f in self.farms if f["name"] == self.farm.currentText()), None)

    def _selected(self):
        return [i.data(Qt.UserRole) or i.text() for i in self.people.selectedItems()]

    def _reload_farms(self, select=""):
        try:
            self.farms = self.portal.list_farms()
        except PortalError as e:
            self.farms = []
            QMessageBox.warning(self, "Portal", str(e))
        self.farm.blockSignals(True)
        self.farm.clear()
        self.farm.addItems([f["name"] for f in self.farms])
        if select in [f["name"] for f in self.farms]:
            self.farm.setCurrentText(select)
        self.farm.blockSignals(False)

    def _register(self):
        path = _update_register(self, self.portal)
        if path and QMessageBox.question(self, "Register", f"Register updated:\n{path}\n\nOpen it now?") == QMessageBox.Yes:
            webbrowser.open("file:///" + path.replace("\\", "/"))

    def _map(self):
        it = self.maps.currentItem()
        return it.data(0, Qt.UserRole) if it else None

    def _show_maps(self, f, select=None):
        self.maps.clear()
        try:
            maps = self.portal.list_maps(f["id"])
            infos = {m["id"]: self.portal.map_info(m["id"]) for m in maps}
        except PortalError as e:
            QMessageBox.warning(self, "Published properties", str(e))
            return
        for m in maps:
            rows = infos[m["id"]]
            cur = next((r for r in rows if r["is_current"]), None)
            older = [r for r in rows if not r["is_current"]]
            it = QTreeWidgetItem([m["title"], m.get("kind") or "",
                                  _nice_date(cur["published_at"]) if cur else
                                  ("offline since " + _nice_date(m["archived_at"]) if m.get("archived_at") else "not published"),
                                  _nice_date(cur["survey_date"]) if cur and cur.get("survey_date") else "",
                                  _nice_date(older[0]["published_at"]) if older else ""])
            it.setData(0, Qt.UserRole, dict(m, has_previous=bool(older)))
            it.setToolTip(0, m.get("description") or "")
            self.maps.addTopLevelItem(it)
            if select and m["id"] == select:
                self.maps.setCurrentItem(it)
        if self.maps.currentItem() is None and self.maps.topLevelItemCount():
            self.maps.setCurrentItem(self.maps.topLevelItem(0))
        self._map_changed()

    def _map_changed(self, *_):
        m = self._map()
        for b in (self.open_b, self.edit_b, self.delmap_b):
            b.setEnabled(m is not None)
        self.restore_b.setEnabled(bool(m and m.get("has_previous")))
        self._lock_writes()

    def _lock_writes(self):
        """The staff role can look and work suggestions but not change maps, properties or access."""
        if self.portal.can_publish:
            return
        tip = "Needs the publisher role (ask an admin: portal > Staff)"
        for b in (self.edit_b, self.restore_b, self.delmap_b, self.delete_b, self.reset_b, self.remove_b,
                  self.add_b, self.clean_b):
            b.setEnabled(False)
            b.setToolTip(tip)
        self.new.setEnabled(False)

    def _edit_map(self):
        m = self._map()
        if not m:
            return
        d = QDialog(self)
        d.setWindowTitle("Map details")
        d.setMinimumWidth(460)
        fl = QFormLayout(d)
        t = QLineEdit(m["title"])
        k = QComboBox()
        k.setEditable(True)
        k.addItems(MAP_KINDS)
        k.setCurrentText(m.get("kind") or "")
        desc = QPlainTextEdit(m.get("description") or "")
        desc.setFixedHeight(90)
        fl.addRow("Map title", t)
        fl.addRow("Type", k)
        fl.addRow("Description", desc)
        fl.addRow(QLabel("Changes show in the portal straight away; no need to republish."))
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        fl.addRow(bb)
        if d.exec_() != QDialog.Accepted or not t.text().strip():
            return
        try:
            self.portal.update_map(m["id"], title=t.text().strip(), kind=k.currentText().strip(),
                                   description=desc.toPlainText().strip())
        except PortalError as e:
            QMessageBox.warning(self, "Map details", str(e))
            return
        self._show_maps(self._farm(), select=m["id"])
        _update_register(self, self.portal)

    def _delete_map(self):
        f, m = self._farm(), self._map()
        if not f or not m:
            return
        if QMessageBox.question(self, "Delete map", f"Delete the map “{m['title']}” from “{f['name']}”? Customers stop "
                                "seeing it straight away. Other maps of this property, and people's access, stay.\n\n"
                                "Your packages on this computer aren't touched.") != QMessageBox.Yes:
            return
        try:
            self.portal.delete_map(f["id"], m["id"])
        except PortalError as e:
            QMessageBox.warning(self, "Delete map", str(e))
        self._show_maps(f)
        _update_register(self, self.portal)

    def _show_suggestions_count(self, f):
        try:
            rows = self.portal.suggestions(f["id"])
        except PortalError:
            self.sugg_label.setText("")
            return
        new = sum(1 for r in rows if r["status"] == "new")
        busy = sum(1 for r in rows if r["status"] == "in_progress")
        self.sugg_label.setText(f"{new} new, {busy} in progress, {len(rows)} in total" if rows else "None yet")
        self.sugg_b.setEnabled(bool(rows))

    def _suggestions(self):
        f = self._farm()
        if f:
            parent = self.parent()
            SuggestionsDialog(self.portal, f, getattr(parent, "iface", None),
                              out_root(), self).exec_()
            self._show_suggestions_count(f)

    def _open(self):
        f, m = self._farm(), self._map()
        if f:
            webbrowser.open(portal_site().rstrip("/") + "/#" + f["slug"] + (("/" + m["slug"]) if m else ""))

    def _restore(self):
        f, m = self._farm(), self._map()
        if not f or not m or QMessageBox.question(
                self, "Use previous version",
                f"Show customers the previous version of “{m['title']}” again? The current one is kept, "
                "so you can switch back by doing this again.") != QMessageBox.Yes:
            return
        try:
            self.portal.restore_previous(m["id"])
        except PortalError as e:
            QMessageBox.warning(self, "Published properties", str(e))
        self._show_maps(f, select=m["id"])

    def _delete(self):
        f = self._farm()
        if not f:
            return
        typed, ok = QInputDialog.getText(
            self, "Delete property",
            f"This permanently deletes “{f['name']}” from the portal: its maps, earlier versions and everyone's "
            "access to it. People's sign-ins are kept for any other properties.\n\n"
            "Your package on this computer isn't touched, so you can publish it again later.\n\n"
            "Type the property name to confirm:")
        if not ok:
            return
        if typed.strip().lower() != f["name"].strip().lower():
            QMessageBox.information(self, "Delete property", "The name didn't match, so nothing was deleted.")
            return
        try:
            n = self.portal.delete_farm(f["id"])
        except PortalError as e:
            QMessageBox.warning(self, "Delete property", str(e))
            return
        QMessageBox.information(self, "Delete property", f"Deleted “{f['name']}” ({n} files).")
        self._reload_farms()
        self._load()
        _update_register(self, self.portal)

    def _load(self, *_):
        self.people.clear()
        f = self._farm()
        self.maps.clear()
        for b in (self.open_b, self.edit_b, self.restore_b, self.delmap_b, self.delete_b, self.reset_b,
                  self.remove_b, self.add_b, self.sugg_b):
            b.setEnabled(bool(f))
        self._lock_writes()
        if not f:
            return
        self._show_maps(f)
        self._show_suggestions_count(f)
        try:
            visits = {}
            try:
                visits = self.portal.visits(f["id"])
            except PortalError:
                pass                                   # older database without visit tracking
            total = 0
            for u in self.portal.members(f["id"], detail=True):
                v = visits.get(u["id"])
                if v:
                    total += v["count"]
                    how = ""
                    if v["phone"] and v["computer"]:
                        how = f", {v['phone']} on a phone"
                    elif v["phone"]:
                        how = ", on a phone"
                    when = f"{v['count']} visit{'s' if v['count'] != 1 else ''}, last {_nice_date(v['last'])}{how}"
                elif u.get("last_sign_in_at"):
                    when = "signed in " + _nice_date(u["last_sign_in_at"]) + ", no map visits yet"
                else:
                    when = "hasn't signed in yet"
                it = QListWidgetItem(f"{u['email']}    ({when})")
                it.setData(Qt.UserRole, u["email"])
                it.setToolTip("Visits count each time the map is opened (reopening within 30 minutes counts once). "
                              "RCL staff visits aren't counted.")
                self.people.addItem(it)
        except PortalError as e:
            QMessageBox.warning(self, "Published properties", str(e))

    def _add(self):
        f = self._farm()
        emails = [e for e in re.split(r"[,\s;]+", self.new.text()) if "@" in e]
        if not f or not emails:
            return
        try:
            added = self.portal.share(f["id"], emails)
        except PortalError as e:
            QMessageBox.warning(self, "Published properties", str(e))
            return
        self.new.clear()
        self._load()
        _update_register(self, self.portal)
        show_credentials(self, [a for a in added if a[1]], [a[0] for a in added if not a[1]])

    def _reset(self):
        emails = self._selected()
        if not emails:
            return
        if QMessageBox.question(self, "Reset password",
                                "Give " + ", ".join(emails) + " a new password? The old one stops working straight away.") \
                != QMessageBox.Yes:
            return
        try:
            creds = [(e, self.portal.reset_password(e)) for e in emails]
        except PortalError as e:
            QMessageBox.warning(self, "Published properties", str(e))
            return
        show_credentials(self, creds)

    def _remove(self):
        f, emails = self._farm(), self._selected()
        if not f or not emails:
            return
        if QMessageBox.question(self, "Remove access",
                                f"Stop {', '.join(emails)} seeing “{f['name']}”?") != QMessageBox.Yes:
            return
        try:
            for e in emails:
                self.portal.unshare(f["id"], e)
        except PortalError as e:
            QMessageBox.warning(self, "Published properties", str(e))
        self._load()
        _update_register(self, self.portal)


class PublishDialog(QDialog):
    """Publish a built package as a new map of a property, or as the new version of one of its maps."""

    def __init__(self, portal, package_dir, manifest, parent=None):
        super().__init__(parent)
        self.portal, self.package_dir, self.manifest = portal, package_dir, manifest
        self.setWindowTitle("Publish to the portal")
        self.setMinimumWidth(520)
        lay = QFormLayout(self)
        self.farm = QComboBox()
        self.farm.setEditable(True)
        try:
            self.farms = portal.list_farms()
        except PortalError as e:
            self.farms = []
            QMessageBox.warning(self, "Portal", str(e))
        self.farm.addItems([f["name"] for f in self.farms])
        self.farm.setCurrentText(manifest.get("property") or manifest.get("title") or "")
        lay.addRow("Property / client", self.farm)
        self.map = QComboBox()
        lay.addRow("Publish as", self.map)
        self.map_title = QLineEdit(manifest.get("map_title") or manifest.get("title") or "")
        lay.addRow("Map title", self.map_title)
        about = " · ".join(x for x in (manifest.get("kind"), (manifest.get("description") or "")[:80]) if x)
        if about:
            lab = QLabel(about)
            lab.setWordWrap(True)
            lay.addRow("Type / description", lab)
        self.emails = QPlainTextEdit()
        self.emails.setPlaceholderText("customer@example.co.nz\nfarm.manager@example.co.nz")
        self.emails.setFixedHeight(70)
        lay.addRow("Give access to", self.emails)
        self.current = QLabel("")
        self.current.setWordWrap(True)
        lay.addRow("Already has access", self.current)
        note = QLabel("Everyone with access to the property sees all its maps.")
        note.setStyleSheet("color: palette(mid);")
        lay.addRow(note)
        self.farm.currentTextChanged.connect(self._farm_changed)
        self.map.currentIndexChanged.connect(self._map_changed)
        self._farm_changed(self.farm.currentText())
        bb = QDialogButtonBox()
        self.go = bb.addButton("Publish", QDialogButtonBox.AcceptRole)
        bb.addButton(QDialogButtonBox.Cancel)
        bb.accepted.connect(self._publish)
        bb.rejected.connect(self.reject)
        lay.addRow(bb)

    def _farm_row(self, name):
        return next((f for f in self.farms if f["name"] == name), None)

    def _farm_changed(self, name):
        f = self._farm_row(name)
        self.maps = []
        if f:
            try:
                self.maps = self.portal.list_maps(f["id"])
                m = self.portal.members(f["id"])
                self.current.setText(", ".join(m) if m else "Nobody yet")
            except PortalError as e:
                self.current.setText(str(e))
        else:
            self.current.setText("New property")
        self.map.blockSignals(True)
        self.map.clear()
        self.map.addItem("A new map", None)
        for m in self.maps:
            self.map.addItem(f"New version of “{m['title']}”" + (" (offline now: this brings it back)"
                                                                     if m.get("archived_at") else ""), m)
        want = (self.manifest.get("map_title") or "").strip().lower()
        idx = next((i + 1 for i, m in enumerate(self.maps) if m["title"].strip().lower() == want), 0)
        if not idx and len(self.maps) == 1 and self.maps[0]["slug"] == "map":
            idx = 1                                     # properties published before maps existed
        self.map.setCurrentIndex(idx)
        self.map.blockSignals(False)
        self._map_changed()

    def _map_changed(self, *_):
        m = self.map.currentData()
        self.map_title.setText(m["title"] if m and not self.manifest.get("map_title") else
                               self.manifest.get("map_title") or (m or {}).get("title") or self.manifest.get("title") or "")

    def _publish(self):
        name = self.farm.currentText().strip()
        title = self.map_title.text().strip()
        if not name or not title:
            QMessageBox.information(self, "Publish", "Give the property and the map a name.")
            return
        existing = self._farm_row(name)
        farm_slug = existing["slug"] if existing else slug(name)
        m = self.map.currentData()
        if m:
            map_slug = m["slug"]
        else:
            used = {x["slug"] for x in self.maps}
            map_slug = slug(title, used)
        version = QDate.currentDate().toString("yyyy-MM-dd") + "-" + os.urandom(3).hex()
        prog = QProgressDialog("Uploading…", None, 0, 1000, self)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(0)

        def tick(done, total):
            prog.setValue(int(1000 * done / max(total, 1)))
            prog.setLabelText(f"Uploading {done / 1e6:.1f} of {total / 1e6:.1f} MB")
            QApplication.processEvents()

        try:
            farm = self.portal.publish(self.package_dir, name, farm_slug, version, tick, map_slug=map_slug,
                                       map_title=title, description=self.manifest.get("description"),
                                       kind=self.manifest.get("kind"))
            emails = [e for e in re.split(r"[,\s;]+", self.emails.toPlainText()) if "@" in e]
            added = self.portal.share(farm["id"], emails) if emails else []
        except PortalError as e:
            prog.close()
            QMessageBox.warning(self, "Publish", str(e))
            return
        prog.close()
        reg = _update_register(self, self.portal, quiet=True)
        msg = f"Published “{title}” for {name}."
        if farm.get("reused_bytes"):
            msg += (f"\n\n{farm['reused_bytes'] / 1e6:.0f} MB of it was identical to files already on the portal "
                    "(e.g. unchanged imagery), so only the rest was uploaded.")
        if reg:
            msg += f"\n\nRegister updated: {reg}"
        QMessageBox.information(self, "Publish", msg)
        show_credentials(self, [a for a in added if a[1]], [a[0] for a in added if not a[1]])
        self.accept()


MAP_KINDS = ["Waterway risk", "Farm Environment Plan", "Drone survey", "Consent", "Land use capability",
             "Nutrient management", "Other"]

SHOW_LABELS = [("vector", "As styled in QGIS, drawn by the web map (sharp, quick to build)"),
               ("qgis", "As styled in QGIS, as map images (exact look, slower to build)"),
               ("direction", "Dots with a direction arrow (e.g. photos)"),
               ("dots", "Simple dots")]


def web_summary(layer, opt):
    if layer.type() != QgsMapLayer.VectorLayer:
        return ""
    if opt["show"] == "direction":
        t = "Direction dots"
    elif opt["show"] == "dots":
        t = "Dots"
    elif opt["show"] == "vector":
        t = "Drawn on the web"
    else:
        t = "Map images"
    if abs(float(opt.get("size") or 1) - 1) > 1e-6:
        t += f", {float(opt['size']):g}× size"
    if opt.get("fields") is not None:
        t += f", {len(opt['fields'])} fields"
    if opt.get("labels"):
        t += f", {len(opt['labels'])} renamed"
    if opt.get("title_expr") is not None:
        t += ", own title"
    return t


class LayerOptionsDialog(QDialog):
    """How one layer looks and what customers can read about it on the web."""

    def __init__(self, layer, opt, parent=None):
        super().__init__(parent)
        self.layer = layer
        self.setWindowTitle(f"Layer options: {layer.name()}")
        self.setMinimumWidth(520)
        lay = QFormLayout(self)
        is_pt = pkg.is_point_layer(layer)
        self.show_as = QComboBox()
        from .core.vectorstyle import web_style
        can_vector = web_style(layer) is not None
        for k, lbl in SHOW_LABELS:
            if (k == "vector" and not can_vector) or (k in ("direction", "dots") and not is_pt):
                continue
            self.show_as.addItem(lbl, k)
        if not can_vector:
            self.show_as.setToolTip("This layer's QGIS style uses things only map images can show (e.g. SVG icons, "
                                    "hatching, marker lines, effects), so it's drawn as map images.")
        self.show_as.setCurrentIndex(max(0, self.show_as.findData(opt["show"])))
        self.show_as.setEnabled(self.show_as.count() > 1)
        lay.addRow("Show on the web", self.show_as)
        self.dir = QgsFieldExpressionWidget()
        self.dir.setLayer(layer)
        self.dir.setExpression(opt.get("dir_expr") or guess_direction(layer))
        lay.addRow("Direction (degrees from north)", self.dir)
        self.size = QDoubleSpinBox()
        self.size.setRange(0.5, 4.0)
        self.size.setSingleStep(0.25)
        self.size.setDecimals(2)
        self.size.setSuffix(" ×")
        self.size.setValue(float(opt.get("size") or 1.0))
        self.size.setToolTip("Makes points (and line widths) bigger on the web only. Your QGIS style isn't changed.")
        lay.addRow("Symbol size on the web", self.size)
        self.title_e = QgsFieldExpressionWidget()
        self.title_e.setLayer(layer)
        self.title_e.setExpression(opt["title_expr"] if opt.get("title_expr") is not None else layer.displayExpression())
        self.title_e.setToolTip("The heading customers see when they click a feature: a field, or an expression such as\n"
                                "'Drone photo, ' || format_date(\"Date\", 'd MMM yyyy')\n"
                                "Leave it empty to show the feature's category (or the layer name) instead.")
        lay.addRow("Title when clicked", self.title_e)
        self.fields = QTreeWidget()
        self.fields.setHeaderLabels(["Field", "Name customers see"])
        self.fields.setRootIsDecorated(False)
        self.fields.setMinimumHeight(220)
        self.fields.header().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.fields.header().setSectionResizeMode(1, QHeaderView.Stretch)
        self.fields.setEditTriggers(QAbstractItemView.NoEditTriggers)
        chosen, labels = opt.get("fields"), opt.get("labels") or {}
        default = {f["name"] for f in default_fields(layer)}
        self.aliases = {}
        for f in visible_fields(layer):
            self.aliases[f["name"]] = f["alias"]
            it = QTreeWidgetItem([f["name"], labels.get(f["name"]) or f["alias"]])
            it.setData(0, Qt.UserRole, f["name"])
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEditable)
            on = (f["name"] in chosen) if chosen is not None else (f["name"] in default)
            it.setCheckState(0, Qt.Checked if on else Qt.Unchecked)
            it.setToolTip(1, "Click to change what customers see, e.g. InherentVu → Inherent vulnerability")
            if f["name"] not in default:
                it.setToolTip(0, "Holds file paths or HTML. These values are never sent to the web.")
            self.fields.addTopLevelItem(it)
        # only the name column is editable: click (or F2) to type a new name
        self.fields.itemClicked.connect(lambda it, col: col == 1 and self.fields.editItem(it, 1))
        lay.addRow("Fields customers see", self.fields)
        note = QLabel("Title when clicked starts as the layer's QGIS display name; photo file names show as "
                      "\"Photo 0043\" unless you choose something else. "
                      "Tick the fields customers see and click a name to change it (e.g. InherentVu → Inherent "
                      "vulnerability). Names start as the field's QGIS alias, so aliases set in the layer's "
                      "properties are used automatically. Fields hidden in the attribute table aren't listed; file "
                      "paths and HTML are always removed; photos linked from a field still show as the photo.")
        note.setWordWrap(True)
        note.setStyleSheet("color: palette(mid);")
        lay.addRow(note)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel | QDialogButtonBox.RestoreDefaults)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        bb.button(QDialogButtonBox.RestoreDefaults).clicked.connect(self._defaults)
        lay.addRow(bb)
        self.show_as.currentIndexChanged.connect(self._sync)
        self._sync()

    def _sync(self, *_):
        self.dir.setEnabled(self.show_as.currentData() == "direction")

    def _defaults(self):
        d = pkg.default_web_options(self.layer)
        self.show_as.setCurrentIndex(max(0, self.show_as.findData(d["show"])))
        self.dir.setExpression(d["dir_expr"] or guess_direction(self.layer))
        self.size.setValue(d["size"])
        self.title_e.setExpression(self.layer.displayExpression())
        default = {f["name"] for f in default_fields(self.layer)}
        for i in range(self.fields.topLevelItemCount()):
            it = self.fields.topLevelItem(i)
            name = it.data(0, Qt.UserRole)
            it.setCheckState(0, Qt.Checked if name in default else Qt.Unchecked)
            it.setText(1, self.aliases[name])

    def options(self):
        items = [self.fields.topLevelItem(i) for i in range(self.fields.topLevelItemCount())]
        names = [it.data(0, Qt.UserRole) for it in items if it.checkState(0) == Qt.Checked]
        default = [f["name"] for f in default_fields(self.layer)]
        labels = {}
        for it in items:
            name, text = it.data(0, Qt.UserRole), it.text(1).strip()
            if text and text != self.aliases[name]:
                labels[name] = text
        return {"show": self.show_as.currentData(), "chosen": True, "size": round(self.size.value(), 2),
                "dir_expr": self.dir.expression().strip(),
                "fields": None if names == default else names, "labels": labels,
                "title_expr": None if self.title_e.expression().strip() == (self.layer.displayExpression() or "").strip()
                else self.title_e.expression().strip()}


class WebPackageDialog(QDialog):
    COL_NAME, COL_TITLE, COL_CLICK, COL_WEB, COL_START, COL_LABELS, COL_ONE = 0, 1, 2, 3, 4, 5, 6

    def __init__(self, iface, parent=None):
        super().__init__(parent or (iface.mainWindow() if iface else None))
        self.iface = iface
        self.project = QgsProject.instance()
        self.boundary = None
        self.rubber = None
        self.last_dir = None
        self.setWindowTitle("RCL Web Package")
        self.setMinimumWidth(860)
        self.setWindowFlag(Qt.WindowStaysOnTopHint, False)
        root = QVBoxLayout(self)

        # 1 property
        g1 = QGroupBox("1. Property")
        f1 = QFormLayout(g1)
        self.blayer = QgsMapLayerComboBox()
        self.blayer.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.sel_label = QLabel("")
        row = QHBoxLayout()
        row.addWidget(self.blayer, 1)
        row.addWidget(self.sel_label)
        f1.addRow("Titles / parcels layer", row)
        f1.addRow(self._note("Select the property's titles on the map. Hold Shift to pick several."))
        self.gap = QDoubleSpinBox()
        self.gap.setRange(0, 200)
        self.gap.setValue(25)
        self.gap.setSuffix(" m")
        self.gap.setToolTip("Roads, paper roads and reserves narrower than this between titles become part of the property.")
        self.margin = QDoubleSpinBox()
        self.margin.setRange(0, 500)
        self.margin.setSuffix(" m")
        self.margin.setToolTip("Extra strip around the property to include.")
        r2 = QHBoxLayout()
        r2.addWidget(QLabel("Fill road gaps up to"))
        r2.addWidget(self.gap)
        r2.addSpacing(16)
        r2.addWidget(QLabel("Extra margin"))
        r2.addWidget(self.margin)
        r2.addStretch(1)
        f1.addRow(r2)
        self.show_b = QPushButton("Show boundary")
        self.b_label = QLabel("")
        r3 = QHBoxLayout()
        r3.addWidget(self.show_b)
        r3.addWidget(self.b_label, 1)
        f1.addRow(r3)
        root.addWidget(g1)

        # 2 layers
        g2 = QGroupBox("2. Layers to include")
        v2 = QVBoxLayout(g2)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["QGIS layer", "Name on the web", "Clickable", "On the web", "Starts on", "Labels",
                                   "One at a time"])
        self.tree.headerItem().setToolTip(self.COL_ONE, "Layers that would clash if shown together, e.g. LUC and soils. "
                                          "Ticked layers in the same group can't be on together on the web: switching "
                                          "one on switches the others off. Leave layers like paddocks unticked so they "
                                          "can go on with anything. Starts ticked in QGIS mutually exclusive groups.")
        self.tree.headerItem().setToolTip(self.COL_LABELS, "Write the layer's QGIS labels on the web map (crisp, kept in "
                                          "view as customers zoom in). Starts ticked for layers labelled in QGIS.")
        self.tree.headerItem().setToolTip(self.COL_START, "Whether the layer is switched on when a customer opens the "
                                          "map (they can switch it on or off). Starts the same as its QGIS checkbox.")
        self.tree.header().setSectionResizeMode(0, QHeaderView.Interactive)
        self.tree.header().setSectionResizeMode(1, QHeaderView.Stretch)
        self.tree.header().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(5, QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(6, QHeaderView.ResizeToContents)
        self.tree.setColumnWidth(0, 240)
        self.tree.setMinimumHeight(240)
        self.tree.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tree.itemDoubleClicked.connect(self._tree_double_clicked)
        v2.addWidget(self.tree)
        r_opt = QHBoxLayout()
        r_opt.addWidget(self._note("Double-click a web name to change it, or \"On the web\" for layer options: symbol size, "
                                   "photo direction dots, which fields customers see. Layers are clipped to the property; "
                                   "orthomosaics in the same group become one layer; online basemaps are left out."), 1)
        self.opt_b = QPushButton("Layer options…")
        self.opt_b.clicked.connect(lambda: self._layer_options(self.tree.currentItem()))
        r_opt.addWidget(self.opt_b)
        v2.addLayout(r_opt)
        root.addWidget(g2)

        # 3 output
        g3 = QGroupBox("3. Package")
        f3 = QFormLayout(g3)
        self.title = QLineEdit()
        self.title.setPlaceholderText("Farm or client, e.g. McCone Farm")
        self.title.setToolTip("Who the map is for. Everyone you give access to this property sees all its maps.")
        f3.addRow("Property / client", self.title)
        self.map_title = QLineEdit()
        self.map_title.setPlaceholderText("What the map is, e.g. Waterway risk assessment")
        self.kind = QComboBox()
        self.kind.setEditable(True)
        self.kind.addItems(MAP_KINDS)
        self.kind.setCurrentText("")
        self.kind.lineEdit().setPlaceholderText("Type (optional)")
        rmt = QHBoxLayout()
        rmt.addWidget(self.map_title, 2)
        rmt.addWidget(self.kind, 1)
        f3.addRow("Map title", rmt)
        self.description = QPlainTextEdit()
        self.description.setPlaceholderText("Optional: what this map shows and how to use it. Customers see this under the title.")
        self.description.setFixedHeight(56)
        f3.addRow("Description", self.description)
        self.date_on = QCheckBox("Survey date")
        self.date = QDateEdit(QDate.currentDate())
        self.date.setCalendarPopup(True)
        self.date_on.setChecked(True)
        self._date_touched = False
        self.date.dateChanged.connect(lambda *_: setattr(self, "_date_touched", True))
        f3.addRow(self.date_on, self.date)
        self.mask_on = QCheckBox("Shade outside the property")
        self.mask_on.setToolTip("Darkens the land around the property on the web map so the farm stands out. Drawn by the "
                                "web map from the boundary: no mask layer needed. Customers can switch it off.")
        self.mask_pct = QSpinBox()
        self.mask_pct.setRange(10, 90)
        self.mask_pct.setSingleStep(10)
        self.mask_pct.setSuffix(" % darker")
        self.mask_pct.setValue(50)
        rmask = QHBoxLayout()
        rmask.addWidget(self.mask_pct)
        rmask.addStretch(1)
        self.mask_on.toggled.connect(self.mask_pct.setEnabled)
        f3.addRow(self.mask_on, rmask)
        self.imz = QComboBox()
        self.imz.addItems(["Auto (from imagery resolution)"] + [str(z) for z in range(16, 23)])
        self.omz = QComboBox()
        self.omz.addItems([str(z) for z in range(17, 22)])
        self.omz.setCurrentText("20")
        r4 = QHBoxLayout()
        r4.addWidget(QLabel("Imagery detail"))
        r4.addWidget(self.imz)
        r4.addSpacing(12)
        r4.addWidget(QLabel("Overlay detail"))
        r4.addWidget(self.omz)
        r4.addStretch(1)
        f3.addRow(r4)
        self.out = QgsFileWidget()
        self.out.setStorageMode(QgsFileWidget.GetDirectory)
        self.out.setFilePath(out_root())
        f3.addRow("Save packages in", self.out)
        self.reuse = QCheckBox("Reuse unchanged layers from the last build (much faster with orthomosaics)")
        self.reuse.setToolTip("A layer is only drawn again if its data, QGIS style, the boundary or the detail level "
                              "changed. Untick to draw everything from scratch.")
        self.reuse.setChecked(_settings().value(f"{SETTINGS}/reuse", True, type=bool))
        self.reuse.toggled.connect(lambda on: _settings().setValue(f"{SETTINGS}/reuse", on))
        f3.addRow(self.reuse)
        self.estimate = QLabel("")
        self.estimate.setWordWrap(True)
        f3.addRow(self.estimate)
        root.addWidget(g3)

        # buttons
        br = QHBoxLayout()
        self.build_b = QPushButton("Build package")
        self.build_b.setDefault(True)
        self.preview_b = QPushButton("Preview")
        self.publish_b = QPushButton("Publish to portal…")
        self.settings_b = QPushButton("Sign in…")
        self.settings_b.setToolTip("Sign in to the RCL portal (email, password and 6-digit code), and settings")
        self.access_b = QPushButton("Published properties…")
        self.access_b.setToolTip("Who can see each property, reset passwords, go back a version, delete a property")
        self.inbox_b = QPushButton("Suggestions…")
        self.inbox_b.setToolTip("Customers' suggested changes for every property: status, replies, notes")
        for b in (self.build_b, self.preview_b, self.publish_b):
            br.addWidget(b)
        br.addStretch(1)
        br.addWidget(self.inbox_b)
        br.addWidget(self.access_b)
        br.addWidget(self.settings_b)
        root.addLayout(br)
        self.preview_b.setToolTip("Preview the package just built, or choose a saved one")
        self.publish_b.setToolTip("Publish the package just built, or choose a saved one")

        self.blayer.layerChanged.connect(self._layer_changed)
        self.show_b.clicked.connect(self._show_boundary)
        self.build_b.clicked.connect(self._build)
        self.preview_b.clicked.connect(self._preview)
        self.publish_b.clicked.connect(self._publish)
        self.settings_b.clicked.connect(self._sign_in)
        self.access_b.clicked.connect(self._access)
        self.inbox_b.clicked.connect(self._inbox)
        self.gap.valueChanged.connect(self._invalidate)
        self.margin.valueChanged.connect(self._invalidate)
        self._watched = None
        self._restore()
        self._populate()
        self._layer_changed(self.blayer.currentLayer())
        QTimer.singleShot(400, self._check_suggestions)

    def _sign_in(self):
        PortalSettingsDialog(self).exec_()
        self._show_signed_in()
        self._check_suggestions()

    def _show_signed_in(self):
        p = _SESSION.get("portal")
        self.settings_b.setText(f"Signed in: {p.email.split('@')[0]}…" if p else "Sign in…")

    def _check_suggestions(self):
        portal = load_portal()                    # only if already signed in; never prompts
        self._show_signed_in()
        if portal is None:
            return
        try:
            counts = portal.new_suggestion_counts()
        except PortalError:
            return
        n = sum(counts.values())
        self.inbox_b.setText(f"Suggestions… ({n} new)" if n else "Suggestions…")

    def _inbox(self):
        open_inbox(self.iface, self)
        self._check_suggestions()

    @staticmethod
    def _note(text):
        lab = QLabel(text)
        lab.setWordWrap(True)
        lab.setStyleSheet("color: palette(mid);")
        return lab

    # ------------------------------------------------------------- state
    def _restore(self):
        saved, ok = self.project.readEntry(SCOPE, "boundary_layer", "")
        if saved and self.project.mapLayer(saved):
            self.blayer.setLayer(self.project.mapLayer(saved))
        self.gap.setValue(self.project.readDoubleEntry(SCOPE, "gap", 25)[0])
        self.margin.setValue(self.project.readDoubleEntry(SCOPE, "margin", 0)[0])
        raw, ok = self.project.readEntry(SCOPE, "layers", "")
        self._saved_layers = json.loads(raw) if raw else {}
        self.title.setText(self.project.readEntry(SCOPE, "property", "")[0])
        self.map_title.setText(self.project.readEntry(SCOPE, "map_title", "")[0])
        self.kind.setCurrentText(self.project.readEntry(SCOPE, "kind", "")[0])
        self.description.setPlainText(self.project.readEntry(SCOPE, "description", "")[0])
        self.mask_on.setChecked(self.project.readBoolEntry(SCOPE, "mask_on", False)[0])
        self.mask_pct.setValue(self.project.readNumEntry(SCOPE, "mask_pct", 50)[0])
        self.mask_pct.setEnabled(self.mask_on.isChecked())

    def _save_state(self):
        if self.blayer.currentLayer():
            self.project.writeEntry(SCOPE, "boundary_layer", self.blayer.currentLayer().id())
        self.project.writeEntryDouble(SCOPE, "gap", self.gap.value())
        self.project.writeEntryDouble(SCOPE, "margin", self.margin.value())
        state = {}
        for it in self._layer_items():
            lyr = it.data(0, Qt.UserRole)
            state[lyr.id()] = {"on": it.checkState(self.COL_NAME) == Qt.Checked, "title": it.text(self.COL_TITLE),
                               "click": it.checkState(self.COL_CLICK) == Qt.Checked if lyr.type() == QgsMapLayer.VectorLayer else False,
                               "web": it.data(self.COL_WEB, Qt.UserRole),
                               "start": it.checkState(self.COL_START) == Qt.Checked,
                               "labels": it.checkState(self.COL_LABELS) == Qt.Checked,
                               "one": it.checkState(self.COL_ONE) == Qt.Checked}
        self.project.writeEntry(SCOPE, "layers", json.dumps(state))
        self.project.writeEntry(SCOPE, "property", self.title.text().strip())
        self.project.writeEntry(SCOPE, "map_title", self.map_title.text().strip())
        self.project.writeEntry(SCOPE, "kind", self.kind.currentText().strip())
        self.project.writeEntry(SCOPE, "description", self.description.toPlainText().strip())
        self.project.writeEntryBool(SCOPE, "mask_on", self.mask_on.isChecked())
        self.project.writeEntry(SCOPE, "mask_pct", self.mask_pct.value())
        _settings().setValue(f"{SETTINGS}/out_root", self.out.filePath())

    # ------------------------------------------------------------- layers
    def _populate(self):
        self.tree.clear()

        def add(node, parent):
            for ch in node.children():
                if isinstance(ch, QgsLayerTreeGroup):
                    gi = QTreeWidgetItem(parent, [ch.name()])
                    gi.setFlags(gi.flags() | Qt.ItemIsAutoTristate | Qt.ItemIsUserCheckable)
                    gi.setCheckState(self.COL_NAME, Qt.Unchecked)
                    gi.setData(self.COL_CLICK, Qt.CheckStateRole, None)
                    gi.setData(self.COL_START, Qt.CheckStateRole, None)
                    gi.setData(self.COL_LABELS, Qt.CheckStateRole, None)
                    gi.setData(self.COL_ONE, Qt.CheckStateRole, None)
                    gi.setData(0, Qt.UserRole + 1, ch.name())
                    gi.setData(0, Qt.UserRole + 2, ch.isMutuallyExclusive())
                    add(ch, gi)
                    gi.setExpanded(ch.isExpanded())
                elif isinstance(ch, QgsLayerTreeLayer) and ch.layer() is not None:
                    lyr = ch.layer()
                    is_bnd = lyr is self.blayer.currentLayer()
                    web = pkg.is_web_basemap(lyr)
                    saved = self._saved_layers.get(lyr.id(), {})
                    default_on = ch.isVisible() and not web and not is_bnd and lyr.isValid()
                    it = QTreeWidgetItem(parent, [lyr.name(), saved.get("title") or pkg.nice_title(lyr.name()), ""])
                    it.setData(0, Qt.UserRole, lyr)
                    flags = it.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEditable
                    if web or not lyr.isValid():
                        flags &= ~Qt.ItemIsEnabled
                        it.setToolTip(0, "Online basemap: the portal provides its own" if web else "Layer data not found")
                    it.setFlags(flags)
                    it.setCheckState(self.COL_NAME, Qt.Checked if saved.get("on", default_on) and not web else Qt.Unchecked)
                    it.setCheckState(self.COL_START, Qt.Checked if saved.get("start", ch.itemVisibilityChecked())
                                     else Qt.Unchecked)
                    grp = ch.parent()
                    in_ex = isinstance(grp, QgsLayerTreeGroup) and grp.isMutuallyExclusive()
                    it.setCheckState(self.COL_ONE, Qt.Checked if saved.get("one", in_ex) else Qt.Unchecked)
                    if lyr.type() == QgsMapLayer.VectorLayer:
                        it.setCheckState(self.COL_CLICK, Qt.Checked if saved.get("click", True) else Qt.Unchecked)
                        has_labels = lyr.labelsEnabled() and lyr.labeling() is not None
                        it.setCheckState(self.COL_LABELS, Qt.Checked if saved.get("labels", has_labels) else Qt.Unchecked)
                        if not has_labels:
                            it.setToolTip(self.COL_LABELS, "This layer has no labels set up in QGIS (Layer Properties > "
                                                           "Labels). Set them there; the web map uses the same text.")
                        opt = pkg.web_options(lyr, saved.get("web"))
                        it.setData(self.COL_WEB, Qt.UserRole, opt)
                        it.setText(self.COL_WEB, web_summary(lyr, opt))
                        it.setToolTip(self.COL_WEB, "Double-click for layer options")
        add(self.project.layerTreeRoot(), self.tree.invisibleRootItem())
        self.tree.itemChanged.connect(lambda *_: self._update_estimate())

    def _layer_items(self):
        out = []

        def walk(item):
            for i in range(item.childCount()):
                c = item.child(i)
                if c.data(0, Qt.UserRole) is not None:
                    out.append(c)
                walk(c)
        walk(self.tree.invisibleRootItem())
        return out

    def _specs(self):
        specs = []
        for it in self._layer_items():
            if it.checkState(self.COL_NAME) != Qt.Checked or not (it.flags() & Qt.ItemIsEnabled):
                continue
            lyr = it.data(0, Qt.UserRole)
            parent = it.parent()
            group = parent.text(0) if parent is not None else ""
            specs.append({"layer": lyr, "title": it.text(self.COL_TITLE).strip() or lyr.name(), "group": group,
                          "visible": it.checkState(self.COL_START) == Qt.Checked,
                          "exclusive": it.checkState(self.COL_ONE) == Qt.Checked,
                          "features": it.checkState(self.COL_CLICK) == Qt.Checked,
                          "labels": lyr.type() == QgsMapLayer.VectorLayer and it.checkState(self.COL_LABELS) == Qt.Checked
                          and lyr.labelsEnabled() and lyr.labeling() is not None,
                          "web": it.data(self.COL_WEB, Qt.UserRole)})
        return specs

    def _tree_double_clicked(self, it, col):
        if it is None or it.data(0, Qt.UserRole) is None:
            return
        if col == self.COL_TITLE:
            self.tree.editItem(it, col)
        elif col in (self.COL_WEB, self.COL_NAME):
            self._layer_options(it)

    def _layer_options(self, it):
        lyr = it.data(0, Qt.UserRole) if it is not None else None
        if lyr is None or lyr.type() != QgsMapLayer.VectorLayer:
            QMessageBox.information(self, "Layer options", "Pick a vector layer in the list first.")
            return
        d = LayerOptionsDialog(lyr, it.data(self.COL_WEB, Qt.UserRole) or pkg.web_options(lyr), self)
        if d.exec_() == QDialog.Accepted:
            opt = d.options()
            it.setData(self.COL_WEB, Qt.UserRole, opt)
            it.setText(self.COL_WEB, web_summary(lyr, opt))
            self._save_state()
            self._update_estimate()

    # ------------------------------------------------------------- boundary
    def _layer_changed(self, lyr):
        if self._watched is not None:
            try:
                self._watched.selectionChanged.disconnect(self._sel_changed)
            except (TypeError, RuntimeError):
                pass
        self._watched = lyr
        if lyr is not None:
            lyr.selectionChanged.connect(self._sel_changed)
            for it in self._layer_items():
                if it.data(0, Qt.UserRole) is lyr:
                    it.setCheckState(self.COL_NAME, Qt.Unchecked)
        self._sel_changed()

    def _sel_changed(self, *args):
        lyr = self.blayer.currentLayer()
        n = lyr.selectedFeatureCount() if lyr else 0
        self.sel_label.setText(f"{n} selected")
        self._invalidate()

    def _invalidate(self, *args):
        self.boundary = None
        self.b_label.setText("")
        self.estimate.setText("")
        if self.rubber:
            self.rubber.reset(QgsWkbTypes.PolygonGeometry)

    def _make_boundary(self):
        lyr = self.blayer.currentLayer()
        if lyr is None or lyr.selectedFeatureCount() == 0:
            raise ValueError("Select the property's titles in the titles / parcels layer first.")
        geom, crs = bnd.build_boundary(lyr, lyr.selectedFeatureIds(), self.gap.value(), self.margin.value(), self.project)
        self.boundary = (geom, crs)
        if not self.title.text().strip():
            for field in ("owners", "owner", "Owner", "name", "Name"):
                if field in lyr.fields().names():
                    v = next(lyr.getSelectedFeatures())[field]
                    if v:
                        self.title.setText(str(v).split(",")[0].strip())
                    break
        return geom, crs

    def _show_boundary(self):
        try:
            geom, crs = self._make_boundary()
        except ValueError as e:
            QMessageBox.information(self, "Boundary", str(e))
            return
        canvas = self.iface.mapCanvas() if self.iface else None
        if canvas is not None:
            if self.rubber is None:
                self.rubber = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
                self.rubber.setColor(QColor(255, 140, 0, 200))
                self.rubber.setFillColor(QColor(255, 140, 0, 40))
                self.rubber.setWidth(3)
            self.rubber.setToGeometry(geom, crs)
            r = bnd.to_crs(geom, crs, canvas.mapSettings().destinationCrs(), self.project).boundingBox()
            r.grow(r.width() * 0.1)
            canvas.setExtent(r)
            canvas.refresh()
        self.b_label.setText(f"{bnd.area_ha(geom):,.1f} ha")
        self._guess_date()
        self._update_estimate()

    def _guess_date(self):
        if self._date_touched or not self.boundary:
            return
        d = pkg.guess_survey_date(self._specs(), *self.boundary, project=self.project)
        if d:
            qd = QDate.fromString(d, "yyyy-MM-dd")
            if qd.isValid():
                self.date.blockSignals(True)
                self.date.setDate(qd)
                self.date.blockSignals(False)
                self.date.setToolTip("Taken from the photo dates inside the property. Change it if needed.")

    def _zoom_options(self):
        imz = None if self.imz.currentIndex() == 0 else int(self.imz.currentText())
        return imz, int(self.omz.currentText())

    def _update_estimate(self):
        if not self.boundary:
            return
        imz, omz = self._zoom_options()
        plan = pkg.plan(self._specs(), *self.boundary, project=self.project, imagery_maxzoom=imz, overlay_maxzoom=omz)
        tiles = sum(w["estimate"] for w in plan)
        mins = tiles / 6000
        when = "under a minute" if mins < 1 else f"about {round(mins)} min"
        self.estimate.setText(f"{len(plan)} web layers, up to {tiles:,} tiles: {when} for local data "
                              f"(online layers and ECW take longer).")

    # ------------------------------------------------------------- actions
    def _build(self):
        try:
            geom, crs = self.boundary or self._make_boundary()
        except ValueError as e:
            QMessageBox.information(self, "Build", str(e))
            return
        name = self.title.text().strip()
        if not name:
            QMessageBox.information(self, "Build", "Give the property a name first.")
            return
        specs = self._specs()
        if not specs:
            QMessageBox.information(self, "Build", "Tick at least one layer.")
            return
        self._save_state()
        self._guess_date()
        out_dir = pkg.package_folder(self.out.filePath(), name, self.map_title.text().strip() or None)
        reuse_from = None
        if self.reuse.isChecked():
            map_dir = os.path.dirname(out_dir)
            reuse_from = (pkg.latest_build(map_dir, depth=1) if os.path.isdir(map_dir) else None) or \
                (pkg.latest_build(os.path.dirname(map_dir), depth=1) if self.map_title.text().strip() else None)
        imz, omz = self._zoom_options()
        prog = QProgressDialog("Preparing…", "Cancel", 0, 1000, self)
        prog.setWindowTitle("Building web package")
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(0)

        def progress(done, total, msg):
            prog.setValue(int(1000 * done / max(total, 1)))
            prog.setLabelText(msg)
            QApplication.processEvents()
            if prog.wasCanceled():
                raise Cancelled()

        t0 = time.time()
        try:
            m = pkg.build(specs, geom, crs, out_dir, title=name,
                          survey_date=self.date.date().toString("yyyy-MM-dd") if self.date_on.isChecked() else None,
                          map_title=self.map_title.text().strip() or None,
                          description=self.description.toPlainText().strip(), kind=self.kind.currentText().strip(),
                          mask=self.mask_pct.value() / 100 if self.mask_on.isChecked() else None,
                          project=self.project,
                          imagery_maxzoom=imz, overlay_maxzoom=omz, progress=progress, reuse_from=reuse_from)
        except Cancelled:
            prog.close()
            return
        except Exception as e:  # noqa: show any failure to the user
            prog.close()
            import traceback
            tb = traceback.format_exc()
            where = next((l.strip() for l in reversed(tb.splitlines()) if l.strip().startswith("File ")), "")
            box = QMessageBox(QMessageBox.Warning, "Build",
                              f"The package could not be built:\n{e}\n\nIt stopped at: {prog.labelText()}", parent=self)
            box.setInformativeText("Click Show Details for the technical detail (copy it if you need help).")
            box.setDetailedText(f"{type(e).__name__}: {e}\nDuring: {prog.labelText()}\n{where}\n\n{tb}")
            box.exec_()
            try:
                from qgis.core import QgsMessageLog
                QgsMessageLog.logMessage(tb, "RCL Web Package", Qgis.Critical)
            except Exception:  # noqa
                pass
            return
        prog.close()
        self.last_dir = out_dir
        self.preview_b.setEnabled(True)
        self.publish_b.setEnabled(True)
        empty = m.get("left_out", [])
        msg = f"Built “{name}”: {len(m['layers'])} layers, {m['bytes'] / 1e6:.1f} MB.\n\nSaved in {out_dir}"
        if m.get("reused"):
            msg += ("\n\nUnchanged since the last build, so copied across: " + ", ".join(m["reused"]) +
                    ". (If one of these should have changed, untick “Reuse unchanged layers” and build again.)")
        if m.get("drawn"):
            why = ("changed, or new since the last build" if m.get("reused_from")
                   else "no earlier build of this map to reuse" if self.reuse.isChecked() else "reuse is turned off")
            msg += f"\n\nDrawn ({why}): " + ", ".join(m["drawn"])
        msg += f"\n\nTook {self._took(t0)}."
        if empty:
            msg += "\n\nNothing from these layers falls inside the property, so they were left out:\n" + ", ".join(empty)
        self.iface and self.iface.messageBar().pushMessage("RCL Web Package", f"Built {name}", Qgis.Success, 6)
        QMessageBox.information(self, "Build", msg)

    @staticmethod
    def _took(t0):
        s = int(time.time() - t0)
        return f"{s // 60} min {s % 60} s" if s >= 60 else f"{s} s"

    def _package_dir(self, verb):
        """The package built in this session, or one the user picks from disk."""
        if self.last_dir and os.path.isfile(os.path.join(self.last_dir, "manifest.json")):
            with open(os.path.join(self.last_dir, "manifest.json"), encoding="utf-8") as fh:
                return self.last_dir, json.load(fh)
        d = QFileDialog.getExistingDirectory(
            self, f"Choose a built package to {verb}", self.out.filePath() or os.path.expanduser("~"))
        if not d:
            return None, None
        d = pkg.latest_build(d) or d                 # a property or map folder: use its latest build
        try:
            with open(os.path.join(d, "manifest.json"), encoding="utf-8") as fh:
                m = json.load(fh)
            if not str(m.get("format", "")).startswith("rcl-web-package/"):
                raise ValueError
        except (OSError, ValueError):
            QMessageBox.warning(self, "RCL Web Package",
                                "That folder isn't a built package. Choose a property's folder in your packages folder "
                                "(its latest build is used), or one of its dated build folders.")
            return None, None
        return d, m

    def _preview(self):
        d, _ = self._package_dir("preview")
        if d:
            webbrowser.open(preview_server.serve(d) + "index.html")

    def _publish(self):
        d, manifest = self._package_dir("publish")
        if not d:
            return
        portal = get_portal(self, publish=True)
        if portal:
            PublishDialog(portal, d, manifest, self).exec_()

    def _access(self):
        portal = get_portal(self)
        if portal:
            AccessDialog(portal, self.title.text().strip(), self).exec_()

    def closeEvent(self, e):
        if self.rubber:
            self.rubber.reset(QgsWkbTypes.PolygonGeometry)
        super().closeEvent(e)
