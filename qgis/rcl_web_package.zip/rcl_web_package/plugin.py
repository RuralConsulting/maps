import os

from qgis.PyQt.QtCore import QTimer
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QPushButton


class RclWebPackagePlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.inbox_action = None
        self.dlg = None
        self._task = None
        self._timer = None
        self._bar_items = []

    def initGui(self):
        here = os.path.dirname(__file__)
        icon = QIcon(os.path.join(here, "icon.svg"))
        self.action = QAction(icon, "RCL Web Package", self.iface.mainWindow())
        self.action.setToolTip("Package a property's map for the RCL customer portal")
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToWebMenu("RCL", self.action)
        self.inbox_action = QAction(QIcon(os.path.join(here, "inbox.svg")), "RCL suggestions inbox", self.iface.mainWindow())
        self.inbox_action.setToolTip("Customers' suggested changes from the RCL map portal")
        self.inbox_action.triggered.connect(self.inbox)
        self.iface.addToolBarIcon(self.inbox_action)
        self.iface.addPluginToWebMenu("RCL", self.inbox_action)
        self.show_for_mode()
        # once QGIS has settled, check quietly for new suggestions (in the background, never asks for the key)
        self._timer = QTimer(self.iface.mainWindow())     # owned, so it can be stopped if QGIS closes first
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.check_new)
        self._timer.start(8000)

    def unload(self):
        # QGIS is closing (or the plugin is being reloaded): stop and let go of everything first, so nothing calls back
        # into objects QGIS has already deleted ("Access violation - no RTTI data")
        if self._timer is not None:
            self._timer.stop()
            try:
                self._timer.timeout.disconnect()
            except (TypeError, RuntimeError):
                pass
            self._timer.deleteLater()
            self._timer = None
        if self._task is not None:
            try:
                self._task.cancel()
            except RuntimeError:
                pass
            self._task = None
        for bar, item in self._bar_items:
            try:
                bar.popWidget(item)
            except RuntimeError:
                pass
        self._bar_items = []
        if self.dlg is not None:
            try:
                self.dlg.finished.disconnect()
            except (TypeError, RuntimeError):
                pass
            building = bool(getattr(self.dlg, "_building", False))
            try:
                if building:
                    # a build is still running further up the call stack (QGIS closed while it processed events):
                    # ask it to stop at its next step, and don't delete the window under it
                    self.dlg.request_cancel()
                    self.dlg.cleanup()
                else:
                    self.dlg.cleanup()
                    self.dlg.close()
                    self.dlg.deleteLater()
            except (RuntimeError, AttributeError):
                pass
            self.dlg = None
        for a in (self.action, self.inbox_action):
            if a:
                self.iface.removeToolBarIcon(a)
                self.iface.removePluginWebMenu("RCL", a)
        try:
            from .core import preview_server
            preview_server.stop_all()
        except Exception:  # noqa
            pass

    def run(self):
        from .dialog import WebPackageDialog
        if self.dlg is None:
            self.dlg = WebPackageDialog(self.iface)
            self.dlg.mode_changed.connect(lambda *_: self.show_for_mode())
            self.dlg.finished.connect(self._closed)
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()

    @staticmethod
    def platform_mode():
        from qgis.core import QgsSettings
        return QgsSettings().value("rcl_web_package/publish_to", "portal") == "platform"

    def show_for_mode(self):
        """Suggestions belong to the map portal: no inbox button while publishing to the platform."""
        if self.inbox_action:
            self.inbox_action.setVisible(not self.platform_mode())

    def _closed(self, *_):
        if self.dlg is not None:
            try:
                self.dlg.cleanup()
                if not getattr(self.dlg, "_building", False):   # mid-build it deletes itself when the build stops
                    self.dlg.deleteLater()
            except (RuntimeError, AttributeError):
                pass
        self.dlg = None

    def inbox(self):
        from .dialog import open_inbox
        open_inbox(self.iface)
        self.check_new()

    # ---------------------------------------------------------------- new-suggestion notice
    def check_new(self):
        if self.platform_mode():
            return
        try:
            from qgis.core import QgsApplication, QgsTask
            from .dialog import load_portal
            portal = load_portal()
        except Exception:  # noqa
            return
        if portal is None or self._task is not None:
            return

        from .dialog import idle_months, _settings, SETTINGS
        import datetime as dt
        months = idle_months()
        last = _settings().value(f"{SETTINGS}/idle_checked", "")
        check_idle = months and portal.can_publish and last < (dt.date.today() - dt.timedelta(days=7)).isoformat()

        def work(task):
            counts = portal.new_suggestion_counts()
            idle = None
            if check_idle:                                  # at most once a week
                try:
                    from .core.register import idle_maps
                    rep = portal.storage_report()
                    idle = (rep, idle_maps(rep, months))
                except Exception:  # noqa: never bother anyone about a failed check
                    idle = None
            return counts, idle

        def done(exception, result=None):
            self._task = None
            if exception is not None or result is None:
                return
            counts, idle = result
            self.show_count(sum(counts.values()))
            if idle is not None:
                _settings().setValue(f"{SETTINGS}/idle_checked", dt.date.today().isoformat())
                if idle[1]:
                    self.show_idle(idle[0], idle[1], months)

        self._task = QgsTask.fromFunction("Checking for new suggestions", work, on_finished=done)
        QgsApplication.taskManager().addTask(self._task)

    def show_idle(self, report, idle, months):
        from qgis.core import Qgis
        mb = sum(r["online_bytes"] or 0 for r in idle) / 1e6
        bar = self.iface.messageBar()
        item = bar.createMessage("RCL portal", f"{len(idle)} map{'s' if len(idle) != 1 else ''} not opened by customers "
                                               f"for {months}+ months ({mb:,.0f} MB online).")
        b = QPushButton("Review")

        def review():
            bar.popWidget(item)
            from .dialog import CleanupDialog, get_portal
            portal = get_portal(self.iface.mainWindow())
            if portal:
                CleanupDialog(portal, self.iface.mainWindow(), report=report).exec_()
        b.clicked.connect(review)
        item.layout().addWidget(b)
        bar.pushWidget(item, Qgis.Info, 0)
        self._bar_items.append((bar, item))

    def show_count(self, n):
        if not self.inbox_action:
            return
        self.inbox_action.setText(f"RCL suggestions inbox ({n} new)" if n else "RCL suggestions inbox")
        self.inbox_action.setToolTip(f"{n} new suggestion{'s' if n != 1 else ''} from customers" if n
                                     else "Customers' suggested changes from the RCL map portal")
        if n and not getattr(self, "_told", False):
            self._told = True                      # once per QGIS session
            from qgis.core import Qgis
            bar = self.iface.messageBar()
            item = bar.createMessage("RCL portal", f"{n} new suggestion{'s' if n != 1 else ''} from customers.")
            b = QPushButton("Open the inbox")
            b.clicked.connect(lambda: (bar.popWidget(item), self.inbox()))
            item.layout().addWidget(b)
            bar.pushWidget(item, Qgis.Info, 0)
            self._bar_items.append((bar, item))
