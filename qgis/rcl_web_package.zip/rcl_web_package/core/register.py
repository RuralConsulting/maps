"""A register of customers and maps on the portal, written as an Excel file.

Built from the portal itself (so it's right whoever published), with one row per map and one per person.
No Excel library is needed: an .xlsx is a zip of a few XML files.
"""
import datetime as dt
import os
import zipfile
from xml.sax.saxutils import escape

from .features import slug


def _col(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def _cell(ref, v, style=0):
    st = f' s="{style}"' if style else ""
    if v is None or v == "":
        return f'<c r="{ref}"{st}/>'
    if isinstance(v, bool):
        v = "Yes" if v else ""
    if isinstance(v, (int, float)):
        return f'<c r="{ref}"{st}><v>{v}</v></c>'
    if isinstance(v, tuple) and v and v[0] == "link":             # ("link", url, text)
        url, text = v[1].replace('"', '""'), v[2].replace('"', '""')
        formula = escape('HYPERLINK("' + url + '","' + text + '")')
        return f'<c r="{ref}" s="3" t="str"><f>{formula}</f><v>{escape(v[2])}</v></c>'
    return f'<c r="{ref}"{st} t="inlineStr"><is><t xml:space="preserve">{escape(str(v))}</t></is></c>'


def _sheet(headers, rows, widths, autofilter=True):
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
           '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
           '</sheetView></sheetViews><cols>']
    out += [f'<col min="{i}" max="{i}" width="{w}" customWidth="1"/>' for i, w in enumerate(widths, 1)]
    out.append("</cols><sheetData>")
    out.append('<row r="1">' + "".join(_cell(f"{_col(i)}1", h, 1) for i, h in enumerate(headers, 1)) + "</row>")
    for r, row in enumerate(rows, 2):
        out.append(f'<row r="{r}">' + "".join(_cell(f"{_col(i)}{r}", v, 2) for i, v in enumerate(row, 1)) + "</row>")
    out.append("</sheetData>")
    if rows and autofilter:
        out.append(f'<autoFilter ref="A1:{_col(len(headers))}{len(rows) + 1}"/>')
    out.append("</worksheet>")
    return "".join(out)


def write_xlsx(path, sheets):
    """sheets: [(name, headers, rows, widths)]"""
    n = len(sheets)
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
          + "".join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                    for i in range(1, n + 1)) + "</Types>")
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            "</Relationships>")
    wb = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
          + "".join(f'<sheet name="{escape(s[0])}" sheetId="{i}" r:id="rId{i}"/>' for i, s in enumerate(sheets, 1))
          + "</sheets></workbook>")
    wbrels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
              + "".join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>'
                        for i in range(1, n + 1))
              + f'<Relationship Id="rId{n + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
              "</Relationships>")
    styles = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
              '<fonts count="3"><font><sz val="11"/><name val="Calibri"/></font>'
              '<font><b/><sz val="11"/><color rgb="FF231F20"/><name val="Calibri"/></font>'
              '<font><u/><sz val="11"/><color rgb="FF0563C1"/><name val="Calibri"/></font></fonts>'
              '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="FFFEC956"/><bgColor indexed="64"/></patternFill></fill></fills>'
              '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
              '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
              '<cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
              '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>'
              '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
              '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="top"/></xf>'
              '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
              '</styleSheet>')
    tmp = path + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", rels)
        z.writestr("xl/workbook.xml", wb)
        z.writestr("xl/_rels/workbook.xml.rels", wbrels)
        z.writestr("xl/styles.xml", styles)
        for i, (name, headers, rows, widths) in enumerate(sheets, 1):
            z.writestr(f"xl/worksheets/sheet{i}.xml", _sheet(headers, rows, widths, name not in ("Storage", "About")))
    os.replace(tmp, path)          # raises PermissionError if the register is open in Excel


def _d(iso):
    return str(iso)[:10] if iso else ""


def _mb(n):
    return round((n or 0) / 1e6, 1)


def folder_size(path):
    """(bytes, number of dated builds) of a local packages folder; (None, 0) if it isn't there."""
    if not path or not os.path.isdir(path):
        return None, 0
    total, builds = 0, 0
    for root, dirs, files in os.walk(path):
        if "manifest.json" in files:
            builds += 1
        for n in files:
            try:
                total += os.path.getsize(os.path.join(root, n))
            except OSError:
                pass
    return total, builds


def local_folder(packages_root, farm, m):
    if not packages_root:
        return ""
    p = os.path.join(packages_root, slug(farm["name"]), slug(m["title"]))
    if not os.path.isdir(p) and m["slug"] != "map":
        p = os.path.join(packages_root, slug(farm["name"]), m["slug"])
    if not os.path.isdir(p) and m["slug"] == "map":
        p = os.path.join(packages_root, slug(farm["name"]))
    return p if os.path.isdir(p) else ""


def months_since(iso, now=None):
    if not iso:
        return None
    try:
        t = dt.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
    except ValueError:
        return None
    now = now or dt.datetime.now(dt.timezone.utc)
    if t.tzinfo is None:
        t = t.replace(tzinfo=dt.timezone.utc)
    return (now - t).days / 30.44


def idle_maps(report, months):
    """Maps on the portal that customers haven't opened for `months` (and that were published before that)."""
    out = []
    for r in report["maps"]:
        if r["archived_at"] or not r["published_at"]:
            continue
        seen = months_since(r["last_visit"]) if r["last_visit"] else None
        pub = months_since(r["published_at"])
        if (seen is None or seen >= months) and (pub or 0) >= months:
            out.append(r)
    return out


def build_register(portal, path, site_url, packages_root=None, idle_months=12):
    """Gather everything from the portal and write the register. Returns the number of maps."""
    staff = {r["user_id"] for r in portal.rest("GET", "staff?select=user_id") or []}
    users = {u["id"]: u for u in portal._all_users()}
    report = portal.storage_report()
    idle = {r["map"]["id"] for r in idle_maps(report, idle_months)} if idle_months else set()
    map_rows, people_rows, store_rows = [], [], []
    tot_online, tot_local = 0, 0
    by_farm = {}
    for r in report["maps"]:
        by_farm.setdefault(r["farm"]["id"], []).append(r)
    for fid, rows in sorted(by_farm.items(), key=lambda kv: kv[1][0]["farm"]["name"].lower()):
        f = rows[0]["farm"]
        members = portal.members(f["id"], detail=True)
        emails = ", ".join(u["email"] for u in members)
        try:
            views = portal.rest("GET", f"map_views?select=user_id,map_id,viewed_at,device&farm_id=eq.{f['id']}"
                                       f"&order=viewed_at.desc&limit=20000") or []
        except Exception:  # noqa: older database
            views = []
        views = [v for v in views if v.get("user_id") not in staff]
        try:
            sugg = portal.suggestions(f["id"])
        except Exception:  # noqa
            sugg = []
        farm_local = 0
        for r in rows:
            m = r["map"]
            info = portal.map_info(m["id"])
            cur = next((x for x in info if x["is_current"]), None)
            mv = [v for v in views if v.get("map_id") == m["id"]]
            ms = [s for s in sugg if s.get("map_id") == m["id"]]
            local = local_folder(packages_root, f, m)
            lbytes, builds = folder_size(local)
            farm_local += lbytes or 0
            if r["archived_at"]:
                status = "Offline since " + _d(r["archived_at"])
            elif not cur:
                status = "Not published"
            elif m["id"] in idle:
                status = f"Online, not opened by customers for {idle_months}+ months"
            else:
                status = "Online"
            map_rows.append([
                f["name"], m["title"], m.get("kind") or "", status, m.get("description") or "",
                _d(cur and cur.get("survey_date")), _d(cur and cur.get("published_at")) or "",
                "Yes" if r["versions"] > 1 else "", emails, len(mv), _d(mv[0]["viewed_at"]) if mv else "",
                sum(1 for s in ms if s["status"] == "new"), len(ms),
                _mb(r["online_bytes"]), _mb(lbytes) if lbytes is not None else "not found", builds or "",
                ("link", f"{site_url.rstrip('/')}/#{f['slug']}/{m['slug']}", "Open") if cur else "", local])
        online = report["farms"].get(fid, 0)
        tot_online += online
        tot_local += farm_local
        store_rows.append([f["name"], sum(1 for r in rows if not r["archived_at"]), sum(1 for r in rows if r["archived_at"]),
                           _mb(online), _mb(farm_local)])
        for u in members:
            uv = [v for v in views if v.get("user_id") == u["id"]]
            people_rows.append([f["name"], u["email"], _d(u.get("last_sign_in_at")) or "never", len(uv),
                                _d(uv[0]["viewed_at"]) if uv else "", sum(1 for v in uv if v.get("device") == "phone")])
    store_rows.append(["All properties", sum(x[1] for x in store_rows), sum(x[2] for x in store_rows),
                       _mb(tot_online), _mb(tot_local)])
    root_bytes, _ = folder_size(packages_root) if packages_root else (None, 0)
    staff_rows = [[users[s]["email"]] for s in staff if s in users]
    now = dt.datetime.now().strftime("%d %b %Y %H:%M")
    about = [["Updated", now], ["Portal", site_url],
             ["Online storage", f"{tot_online / 1e9:.2f} GB of maps + {report['photos'] / 1e9:.2f} GB of suggestion "
                                f"photos = {(tot_online + report['photos']) / 1e9:.2f} GB (the Supabase Pro plan "
                                "includes 100 GB; see Supabase > Usage for the exact figure)"],
             ["On this computer", f"{tot_local / 1e9:.2f} GB in the published maps' folders"
                                  + (f"; {root_bytes / 1e9:.2f} GB in the whole packages folder ({packages_root})"
                                     if root_bytes is not None else "")],
             ["Not opened", f"{len(idle)} map(s) online but not opened by customers for {idle_months}+ months: "
                            "Published properties > Clean up... can take them offline (the copy on this computer is kept)."
                            if idle_months else "Reminders are off"],
             ["Made by", "RCL Web Package tool in QGIS, from the portal. It is rewritten after each publish or access "
                         "change, so edits made here are lost: keep your own notes in a separate file."]]
    write_xlsx(path, [
        ("Maps", ["Property / client", "Map", "Type", "Status", "Description", "Surveyed", "Published",
                  "Earlier version kept", "People with access", "Visits", "Last visit", "New suggestions",
                  "All suggestions", "Online (MB)", "This computer (MB)", "Builds kept", "Portal", "Packages folder"],
         map_rows, [26, 30, 16, 26, 36, 12, 12, 12, 36, 8, 12, 10, 10, 11, 13, 8, 9, 50]),
        ("Storage", ["Property / client", "Maps online", "Maps offline", "Online (MB)", "This computer (MB)"],
         store_rows, [30, 12, 12, 14, 18]),
        ("People", ["Property / client", "Email", "Last signed in", "Map visits", "Last visit", "Visits on a phone"],
         people_rows, [26, 34, 14, 11, 12, 12]),
        ("RCL staff", ["Email"], sorted(staff_rows), [36]),
        ("About", ["", ""], about, [18, 110]),
    ])
    return len(map_rows)
