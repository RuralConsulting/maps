"""Build a farm boundary from selected property titles / parcels.

The selected polygons are merged, gaps narrower than `gap_fill_m` (roads, paper
roads, stream reserves between titles) are closed, and an optional margin added.
"""
import math

from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsGeometry,
    QgsProject,
    QgsUnitTypes,
)


def metric_crs(layer_crs, project=None, sample_point=None):
    """A projected CRS in metres to do buffering in."""
    project = project or QgsProject.instance()
    for crs in (layer_crs, project.crs()):
        if crs.isValid() and not crs.isGeographic() and crs.mapUnits() == QgsUnitTypes.DistanceMeters:
            return crs
    if sample_point is not None:  # UTM zone of the boundary
        lon, lat = sample_point.x(), sample_point.y()
        zone = int((lon + 180) // 6) + 1
        return QgsCoordinateReferenceSystem(f"EPSG:{32700 + zone if lat < 0 else 32600 + zone}")
    return QgsCoordinateReferenceSystem("EPSG:3857")


def _buffer(geom, dist):
    try:
        return geom.buffer(dist, 8, Qgis.EndCapStyle.Flat, Qgis.JoinStyle.Miter, 3.0)
    except (AttributeError, TypeError):  # older QGIS enums
        return geom.buffer(dist, 8)


def build_boundary(layer, feature_ids, gap_fill_m=20.0, margin_m=0.0, project=None):
    """Return (geometry, crs) of the merged boundary in a metric CRS."""
    project = project or QgsProject.instance()
    feats = list(layer.getFeatures(QgsFeatureRequest().setFilterFids(list(feature_ids))))
    if not feats:
        raise ValueError("No features selected in the boundary layer.")
    geoms = [QgsGeometry(f.geometry()) for f in feats if f.hasGeometry()]
    if layer.crs().isGeographic():
        to_wgs = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"), project)
        c = QgsGeometry(geoms[0]).centroid()
        c.transform(to_wgs)
        work = metric_crs(layer.crs(), project, c.asPoint())
    else:
        work = metric_crs(layer.crs(), project)
    xf = QgsCoordinateTransform(layer.crs(), work, project)
    for g in geoms:
        g.transform(xf)
    geom = QgsGeometry.unaryUnion(geoms)
    if gap_fill_m and gap_fill_m > 0:
        d = gap_fill_m / 2.0
        geom = _buffer(_buffer(geom, d), -d)
        geom = QgsGeometry.unaryUnion([geom] + geoms)   # never lose any of the original titles
    if margin_m and margin_m > 0:
        geom = _buffer(geom, margin_m)
    geom = geom.makeValid()
    if geom.isEmpty():
        raise ValueError("The boundary came out empty.")
    return geom, work


def area_ha(geom):
    return geom.area() / 10000.0


def lonlat_bounds(geom, crs, project=None):
    project = project or QgsProject.instance()
    g = QgsGeometry(geom)
    g.transform(QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem("EPSG:4326"), project))
    r = g.boundingBox()
    return [r.xMinimum(), r.yMinimum(), r.xMaximum(), r.yMaximum()]


def to_crs(geom, src, dst, project=None):
    project = project or QgsProject.instance()
    g = QgsGeometry(geom)
    g.transform(QgsCoordinateTransform(src, dst, project))
    return g


def ground_resolution(z, lat):
    """Metres per pixel of a 256 px web-mercator tile at zoom z."""
    return 156543.03392804097 * math.cos(math.radians(lat)) / (2 ** z)
