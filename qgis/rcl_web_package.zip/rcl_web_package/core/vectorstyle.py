"""Translate simple QGIS styles into instructions the web map can draw itself (no map images needed).

Covers what most farm layers use: single symbol, categorised and graduated renderers made of simple fills, outlines,
simple lines (solid or dashed) and circle markers. Anything else (SVG or font markers, hatched or pattern fills,
marker lines, arrows, geometry generators, effects, data-defined styling) returns None, and that layer is drawn into
map images as before, so it always looks exactly as in QGIS.

The result is {"geom": "fill"|"line"|"circle", "layers": [...]}, bottom to top. Each layer is
{"type": "fill"|"line"|"circle", "by": {class: props}} where class is the legend index ("_cls" on each feature) or
"*" for a single symbol, and props are colours (#rrggbb), opacity (0-1) and sizes in screen pixels, or {"m": metres}
for sizes in map units.
"""
from qgis.core import QgsMapLayer, QgsUnitTypes, QgsWkbTypes
from qgis.PyQt.QtCore import Qt

PX_PER_MM = 96 / 25.4

# Qt dash patterns, in multiples of the line width (the same convention MapLibre uses)
QT_DASHES = {Qt.DashLine: [4, 2], Qt.DotLine: [1, 2], Qt.DashDotLine: [4, 2, 1, 2], Qt.DashDotDotLine: [4, 2, 1, 2, 1, 2]}


def _unit_value(unit):
    return unit.value if hasattr(unit, "value") else int(unit)


def _size(value, unit, factor=1.0):
    """A size in screen pixels, {"m": metres} for map units, or None if the unit can't be shown on the web."""
    u = _unit_value(unit)
    mm, mapu, px, pt = (_unit_value(QgsUnitTypes.RenderMillimeters), _unit_value(QgsUnitTypes.RenderMapUnits),
                        _unit_value(QgsUnitTypes.RenderPixels), _unit_value(QgsUnitTypes.RenderPoints))
    if u == mm:
        return round(value * PX_PER_MM * factor, 2)
    if u == px:
        return round(value * factor, 2)
    if u == pt:
        return round(value * 96 / 72 * factor, 2)
    if u == mapu:
        return {"m": round(value * factor, 3)}
    return None


def _color(c, opacity):
    return c.name(), round(c.alphaF() * opacity, 3)


def _dash(sl, width_mm):
    if hasattr(sl, "useCustomDashPattern") and sl.useCustomDashPattern():
        pat = sl.customDashVector()
        if not pat or width_mm <= 0:
            return None
        return [round(max(0.1, d / width_mm), 2) for d in pat]
    return QT_DASHES.get(sl.penStyle() if hasattr(sl, "penStyle") else sl.strokeStyle())


def _plain(sl):
    """No data-defined properties and no effects: what's set is what's drawn."""
    try:
        if sl.dataDefinedProperties().hasActiveProperties():
            return False
    except AttributeError:
        pass
    eff = sl.paintEffect() if hasattr(sl, "paintEffect") else None
    if eff is not None and eff.enabled():
        try:
            from qgis.core import QgsDrawSourceEffect
            if not isinstance(eff, QgsDrawSourceEffect):
                return False
        except ImportError:
            return False
    return sl.enabled() if hasattr(sl, "enabled") else True


def _line_props(color, opacity, width, dash):
    p = {"color": color, "opacity": opacity, "width": width}
    if dash:
        p["dash"] = dash
    return p


def _symbol_parts(sym, factor, layer_opacity):
    """[(type, props)] bottom to top for one symbol, or None if any part can't be drawn on the web."""
    if sym is None:
        return []
    try:
        if sym.dataDefinedProperties().hasActiveProperties():
            return None
    except AttributeError:
        pass
    op = sym.opacity() * layer_opacity
    parts = []
    for sl in sym.symbolLayers():
        if not _plain(sl):
            return None
        kind = sl.layerType()
        if kind == "SimpleFill":
            if sl.brushStyle() == Qt.SolidPattern:
                color, o = _color(sl.fillColor() if hasattr(sl, "fillColor") else sl.color(), op)
                if o > 0:
                    parts.append(("fill", {"color": color, "opacity": o}))
            elif sl.brushStyle() != Qt.NoBrush:
                return None                                   # hatching etc.
            if sl.strokeStyle() != Qt.NoPen and sl.strokeColor().alpha() > 0:
                w = _size(sl.strokeWidth(), sl.strokeWidthUnit(), factor) if sl.strokeWidth() > 0 else 1.0  # 0 = hairline
                if w is None:
                    return None
                color, o = _color(sl.strokeColor(), op)
                parts.append(("line", _line_props(color, o, w, QT_DASHES.get(sl.strokeStyle()))))
            if hasattr(sl, "offset") and (sl.offset().x() or sl.offset().y()):
                return None
        elif kind == "SimpleLine":
            if sl.penStyle() == Qt.NoPen or sl.color().alpha() == 0:
                continue
            if sl.offset():
                return None
            w = _size(sl.width(), sl.widthUnit(), factor) if sl.width() > 0 else 1.0
            if w is None:
                return None
            color, o = _color(sl.color(), op)
            width_mm = sl.width() if _unit_value(sl.widthUnit()) == _unit_value(QgsUnitTypes.RenderMillimeters) else 0
            dash = _dash(sl, width_mm) if width_mm else QT_DASHES.get(sl.penStyle())
            parts.append(("line", _line_props(color, o, w, dash)))
        elif kind == "SimpleMarker":
            from qgis.core import Qgis
            shape = sl.shape()
            circle = getattr(Qgis.MarkerShape, "Circle", None) if hasattr(Qgis, "MarkerShape") else None
            if circle is None:
                from qgis.core import QgsSimpleMarkerSymbolLayerBase
                circle = QgsSimpleMarkerSymbolLayerBase.Circle
            if shape != circle or sl.offset().x() or sl.offset().y():
                return None
            r = _size(sl.size() / 2, sl.sizeUnit(), factor)
            if r is None or isinstance(r, dict):
                return None
            color, o = _color(sl.color(), op)
            p = {"color": color, "opacity": o, "radius": r}
            if sl.strokeStyle() != Qt.NoPen and sl.strokeColor().alpha() > 0:
                sw = _size(sl.strokeWidth(), sl.strokeWidthUnit(), factor) if sl.strokeWidth() > 0 else 1.0
                if sw is None or isinstance(sw, dict):
                    return None
                p.update({"stroke": sl.strokeColor().name(), "stroke_width": sw,
                          "stroke_opacity": round(sl.strokeColor().alphaF() * op, 3)})
            parts.append(("circle", p))
        else:
            return None                                       # SVG/font markers, patterns, marker lines...
    return parts


def web_style(layer, size_factor=1.0):
    """The layer's QGIS style as web map instructions, or None if it should be drawn as map images instead."""
    if layer is None or layer.type() != QgsMapLayer.VectorLayer or layer.renderer() is None:
        return None
    try:
        from qgis.PyQt.QtGui import QPainter
        if layer.blendMode() != QPainter.CompositionMode_SourceOver or layer.featureBlendMode() != QPainter.CompositionMode_SourceOver:
            return None
    except Exception:  # noqa
        pass
    r = layer.renderer()
    t = r.type()
    if t == "singleSymbol":
        classes = [("*", r.symbol(), True)]
    elif t == "categorizedSymbol":
        keep = r.categories()                                 # the symbols belong to these copies: keep them alive
        classes = [(i, c.symbol(), c.renderState()) for i, c in enumerate(keep)]
    elif t == "graduatedSymbol":
        keep = r.ranges()
        classes = [(i, rg.symbol(), rg.renderState()) for i, rg in enumerate(keep)]
    else:
        return None                                           # rule-based, heatmap, point clusters...
    gtype = QgsWkbTypes.geometryType(layer.wkbType())
    geom = {QgsWkbTypes.PolygonGeometry: "fill", QgsWkbTypes.LineGeometry: "line",
            QgsWkbTypes.PointGeometry: "circle"}.get(gtype)
    if geom is None:
        return None
    slots = []                                                # [(slot index, type)] in drawing order
    by_slot = {}
    for cls, sym, on in classes:
        parts = _symbol_parts(sym, size_factor, layer.opacity())
        if parts is None:
            return None
        if not on:
            continue                                          # unticked category: not drawn, as in QGIS
        for j, (typ, props) in enumerate(parts):
            if typ == "fill" and geom != "fill" or typ == "circle" and geom != "circle":
                return None
            key = (j, typ)
            if key not in by_slot:
                by_slot[key] = {}
                slots.append(key)
            by_slot[key][str(cls)] = props
    if not slots:
        return None
    slots.sort()
    return {"geom": geom, "layers": [{"type": typ, "by": by_slot[(j, typ)]} for j, typ in slots]}


def zoom_range(layer):
    """(minzoom, maxzoom) from the layer's QGIS scale limits, or (None, None)."""
    if not layer.hasScaleBasedVisibility():
        return None, None
    import math
    z = lambda s: round(math.log2(559082264.028 / s), 2) if s and s > 0 else None
    return z(layer.minimumScale()), z(layer.maximumScale())
