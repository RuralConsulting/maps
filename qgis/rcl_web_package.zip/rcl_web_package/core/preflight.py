"""Checks before a build: what it will take and what's worth changing first. Plain data in, plain data out
(the web layers from package.plan), so it can be tested without QGIS.

preflight(web_layers, imagery_maxzoom=None, overlay_maxzoom=None) ->
    {"tiles": int, "bytes": int, "seconds": float, "pieces": int,
     "items": [{"level": "warn" | "info", "layer": title or "", "text": str}]}
"""
import math

PART_BYTES = 900 * 1024 * 1024        # same as tiler.PART_BYTES (kept here so this module needs no QGIS)
BIG_BYTES = 5 * 1000 ** 3


def fmt_time(seconds):
    s = max(0.0, float(seconds or 0))
    if s < 60:
        return "under a minute"
    m = int(round(s / 60))
    if m < 60:
        return f"{m} min"
    h, m = divmod(m, 60)
    return f"{h} h {m} min" if m else f"{h} h"


def fmt_bytes(n):
    n = float(n or 0)
    if n >= 1e9:
        return f"{n / 1e9:.1f} GB"
    if n >= 1e6:
        return f"{n / 1e6:.0f} MB"
    return f"{max(1, round(n / 1e3))} KB" if n else "0 MB"


def pixel_cm(z, lat):
    return 156543.03392804097 * math.cos(math.radians(lat or 0)) / (2 ** z) * 100


def _per_tile(w):
    n = w.get("estimate") or 0
    return ((w.get("est_seconds") or 0) / n, (w.get("est_bytes") or 0) / n) if n else (0.0, 0.0)


def preflight(web_layers, imagery_maxzoom=None, overlay_maxzoom=None):
    tiled = [w for w in web_layers if not w.get("drawn_on_web")]
    tiles = sum(w.get("estimate") or 0 for w in tiled)
    nbytes = sum(w.get("est_bytes") or 0 for w in tiled)
    seconds = sum(w.get("est_seconds") or 0 for w in tiled)
    pieces = sum(max(1, math.ceil((w.get("est_bytes") or 0) / PART_BYTES)) for w in tiled if (w.get("estimate") or 0) > 0)
    items = [{"level": "info", "layer": "",
              "text": f"About {tiles:,} map tiles, {fmt_bytes(nbytes)}, roughly {fmt_time(seconds)} to build."}]

    for w in web_layers:
        title = w.get("title") or ""
        if w.get("inside") is False:
            items.append({"level": "warn", "layer": title,
                          "text": f"Nothing of {title} falls inside the property: it will be left out."})
            continue
        req = int(w.get("around_requested") or 0)
        if req > 0 and not w.get("drawn_on_web") and w.get("kind") == "overlay":
            items.append({"level": "warn", "layer": title,
                          "text": f"{title} is set to reach {req / 1000:g} km beyond the property, but it's drawn as map "
                                  f"images, which only cover the property. Choose 'Drawn on the web' in Layer options "
                                  f"to show it beyond."})
        for src in w.get("no_pyramids") or []:
            items.append({"level": "warn", "layer": title,
                          "text": f"{src} has no pyramids (overviews), so it draws slowly at lower zooms. In QGIS: "
                                  f"Raster > Miscellaneous > Build Overviews (Pyramids). It's done once and reused."})
        z = w.get("maxzoom") or 0
        byz = {int(k): v for k, v in (w.get("estimate_by_zoom") or {}).items()}
        if w.get("kind") == "imagery" and z >= 21 and not w.get("drawn_on_web"):
            spt, bpt = _per_tile(w)
            steps = []
            for target in range(z - 1, 19, -1):
                cut = sum(v for k, v in byz.items() if k > target)
                steps.append(f"zoom {target} (about {pixel_cm(target, w.get('lat')):.0f} cm) saves about "
                             f"{fmt_time(cut * spt)} and {fmt_bytes(cut * bpt)}")
            items.append({"level": "warn", "layer": title,
                          "text": f"{title} is set to imagery detail zoom {z} (about {pixel_cm(z, w.get('lat')):.0f} cm "
                                  f"per pixel). Each step down cuts this layer's work about four times: "
                                  + "; ".join(steps) + "."})
        if w.get("footprint") == "extent" and w.get("kind") == "imagery":
            items.append({"level": "info", "layer": title,
                          "text": f"{title}: the estimate uses each image's outline, because the images are large and "
                                  f"have no pyramids. The build itself only draws where the images have pixels."})
    if nbytes > BIG_BYTES:
        big = max(tiled, key=lambda w: w.get("est_bytes") or 0)
        items.append({"level": "warn", "layer": big.get("title") or "",
                      "text": f"This package is about {fmt_bytes(nbytes)} (mostly {big.get('title')}). Publishing and "
                              f"customers' loading will be slow; consider a lower imagery detail."})
    tiled_n = sum(1 for w in tiled if (w.get("estimate") or 0) > 0)
    if pieces > tiled_n:
        items.append({"level": "info", "layer": "",
                      "text": f"Large layers will be saved in {pieces} files (each under 1 GB) so shared and Egnyte "
                              f"drives accept them; the web map shows them as one."})
    order = {"warn": 0, "info": 1}
    items = items[:1] + sorted(items[1:], key=lambda it: order[it["level"]])
    return {"tiles": tiles, "bytes": int(nbytes), "seconds": seconds, "pieces": pieces, "items": items}
