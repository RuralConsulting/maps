"""Build a web package for one property: tiles, clickable features, photos, legend, manifest."""
import datetime as dt
import hashlib
import json
import math
import os
import re
import shutil

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsGeometry,
    QgsMapLayer,
    QgsProject,
    QgsRasterDataProvider,
)

from . import boundary as bnd
from .features import (default_fields, export_features, guess_direction, guess_pitch_field, label_info, legend_entries, legend_wrap_strings, slug,
                       symbol_colors)
from .vectorstyle import web_style, zoom_range
from .tiler import EPSG3857, estimate_tiles, render_to_pmtiles, scaled_layer
from . import cache as tcache
from . import coverage as cov
from .preflight import preflight  # noqa: F401  (pkg.preflight(plan) for the dialog)

FORMAT = "rcl-web-package/1"
TILE_KEY_VERSION = 1      # bump when the tiler's output changes, so tiles from older builds aren't reused
SHARED_FORMAT = "rcl-shared-layer/1"
VIEWER_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "viewer")
WEB_PROVIDERS = {"wms", "xyz", "arcgismapserver", "wcs", "vectortile"}


def is_web_basemap(layer):
    return layer.type() == QgsMapLayer.RasterLayer and layer.providerType() in WEB_PROVIDERS


def is_plain_imagery(layer):
    """RGB(A) photography (orthomosaics) as opposed to classified / styled rasters."""
    if layer.type() != QgsMapLayer.RasterLayer or is_web_basemap(layer):
        return False
    r = layer.renderer()
    return r is not None and r.type() in ("multibandcolor", "singlebandcolordata")


def raster_resolution_m(layer, project):
    """Approximate ground pixel size of a raster in metres."""
    px = layer.rasterUnitsPerPixelX()
    if layer.crs().isGeographic():
        c = layer.extent().center()
        px = px * 111320.0 * math.cos(math.radians(c.y()))
    return px


def auto_max_zoom(res_m, lat):
    z = math.log2(156543.03392804097 * math.cos(math.radians(lat)) / max(res_m, 0.005))
    return int(max(14, min(22, round(z))))


def _imagery_clone(layer):
    c = layer.clone()
    dp = c.dataProvider()
    try:
        dp.enableProviderResampling(True)
        dp.setZoomedOutResamplingMethod(QgsRasterDataProvider.ResamplingMethod.Average)
        dp.setZoomedInResamplingMethod(QgsRasterDataProvider.ResamplingMethod.Bilinear)
    except Exception:  # noqa: providers without resampling support
        pass
    return c


def is_point_layer(layer):
    from qgis.core import QgsWkbTypes
    return layer.type() == QgsMapLayer.VectorLayer and \
        QgsWkbTypes.geometryType(layer.wkbType()) == QgsWkbTypes.PointGeometry


def default_web_options(layer):
    """How a layer appears on the web unless changed in Layer options."""
    o = {"show": "qgis", "size": 1.0, "dir_expr": "", "fields": None, "labels": {}, "title_expr": None, "chosen": False,
         "title_auto": False, "around_m": 0}
    if is_point_layer(layer):
        o["size"] = 2.0
        d = guess_direction(layer)
        if d:
            # photo-style layers (view cones etc.) read better as a dot with a direction arrow
            o["show"], o["dir_expr"] = "direction", d
            o["title_auto"] = True     # where and when each photo was taken, rather than its file name
            return o
    if web_style(layer, o["size"]) is not None:
        o["show"] = "vector"           # simple styles: the web map draws them itself (sharp, quick to build)
    return o


def web_options(layer, saved=None):
    o = default_web_options(layer)
    saved = dict(saved or {})
    if saved.get("show") == "qgis" and not saved.get("chosen"):
        saved.pop("show")              # saved before 0.7.2, when map images were the only way: use the new default
    o.update({k: v for k, v in saved.items() if k in o})
    if o["show"] in ("direction", "dots") and not is_point_layer(layer):
        o["show"] = "qgis"
    if o["show"] == "vector" and web_style(layer, float(o.get("size") or 1.0)) is None:
        o["show"] = "qgis"             # style changed to something only map images can show
    if o["show"] == "qgis":
        o["around_m"] = 0              # map images are only drawn for the property itself
    try:
        o["around_m"] = max(0, min(20000, int(float(o.get("around_m") or 0))))
    except (TypeError, ValueError):
        o["around_m"] = 0
    return o


def guess_survey_date(layer_specs, boundary, boundary_crs, project=None):
    """Most common date among date/timestamp values of features inside the property (drone photos)."""
    from collections import Counter
    from qgis.core import QgsFeatureRequest
    project = project or QgsProject.instance()
    counts = Counter()
    for spec in layer_specs:
        lyr = spec["layer"]
        if lyr.type() != QgsMapLayer.VectorLayer:
            continue
        names = [f.name() for f in lyr.fields() if any(k in f.name().lower() for k in ("date", "time", "taken"))]
        if not names:
            continue
        b = QgsGeometry(boundary)
        b.transform(QgsCoordinateTransform(boundary_crs, lyr.crs(), project))
        req = QgsFeatureRequest().setFilterRect(b.boundingBox()).setLimit(2000)
        for f in lyr.getFeatures(req):
            for n in names:
                v = f[n]
                txt = v.toString("yyyy-MM-dd") if hasattr(v, "toString") and not isinstance(v, str) else str(v or "")
                txt = txt.replace(":", "-", 2) if len(txt) >= 10 and txt[4] == ":" else txt   # EXIF 2026:06:10
                if len(txt) >= 10 and txt[:4].isdigit() and txt[4] == "-" and txt[7] == "-":
                    counts[txt[:10]] += 1
                    break
    return counts.most_common(1)[0][0] if counts else None


def package_folder(root, property_name, map_title=None, date=None):
    """Each build goes in its own dated folder: <root>/<property>/<map>/<yyyy-mm-dd>."""
    parts = [root, slug(property_name)] + ([slug(map_title)] if map_title else [])
    return os.path.join(*parts, (date or dt.date.today()).isoformat())


def latest_build(folder, depth=3):
    """The newest built package in folder or below it (property folder, map folder or a build itself)."""
    if os.path.isfile(os.path.join(folder, "manifest.json")):
        return folder
    found = []
    for root, dirs, files in os.walk(folder):
        if root[len(folder):].count(os.sep) >= depth:
            dirs[:] = []
        if "manifest.json" in files:
            found.append((os.path.getmtime(os.path.join(root, "manifest.json")), root))
            dirs[:] = []
    return max(found)[1] if found else None


def _overlaps(layer, boundary, boundary_crs, project):
    """Does the layer's extent overlap the property at all?"""
    try:
        ext = QgsCoordinateTransform(layer.crs(), boundary_crs, project).transformBoundingBox(layer.extent())
        return QgsGeometry.fromRect(ext).intersects(boundary)
    except Exception:  # noqa: odd CRS: assume it does
        return True


# ---------------------------------------------------------------- layers published once and shared by many maps (platform only)
def shared_key(name):
    """The key a shared layer goes by: lower-case letters, digits and dashes, as the platform's registers require."""
    return slug(name)[:80] or "layer"


def layer_in_folder(layer, folder):
    """Is the layer's data stored in this folder? Used for RCL's general GIS folder; with no folder set, never."""
    if not folder:
        return False
    src = layer.source().split("|")[0].split("?")[0]
    if src.lower().startswith("file:///"):
        src = src[8:] if os.name == "nt" else src[7:]
    if not src or not os.path.isabs(src):
        return False
    try:
        root = os.path.normcase(os.path.normpath(folder))
        return os.path.commonpath([root, os.path.normcase(os.path.normpath(src))]) == root
    except ValueError:
        return False                           # different drives


def shared_reference(spec, position):
    """The manifest's reference to a layer published elsewhere: the viewer finds it by tier and key, nothing is copied."""
    shared = spec["shared"]
    ref = {"tier": shared["tier"], "key": shared["key"], "title": spec.get("title") or shared["key"],
           "group": spec.get("group") or "", "visible": bool(spec.get("visible", True)), "exclusive": bool(spec.get("exclusive")),
           "position": position}
    if shared["tier"] == "group":
        ref["org_id"] = shared["org_id"]
    return ref


def layer_extent_3857(layer, project=None):
    project = project or QgsProject.instance()
    rect = QgsCoordinateTransform(layer.crs(), EPSG3857, project).transformBoundingBox(layer.extent())
    return QgsGeometry.fromRect(rect)


def estimate_shared_tiles(layer, minzoom, maxzoom, project=None):
    return estimate_tiles(layer_extent_3857(layer, project), minzoom, maxzoom)


def build_shared_layer(layer, out_dir, *, key, title, project=None, minzoom=8, maxzoom=14, progress=None):
    """Draw one layer as styled in QGIS, across everything it covers (not cut to any property), into out_dir, ready to be
    published once to core/… or a group's shared folder. Returns {"dir", "key", "title", "tiles", "files", "style"}."""
    from qgis.core import QgsMapLayerStyle
    project = project or QgsProject.instance()
    os.makedirs(out_dir, exist_ok=True)
    tile_path = os.path.join(out_dir, key + ".pmtiles")
    res = render_to_pmtiles([layer], layer_extent_3857(layer, project), tile_path, minzoom, maxzoom, scale=2,
                            quality=90, labels=True, project=project, progress=progress, name=title)
    if not res.get("path"):
        raise ValueError(f"Nothing to draw for {title}: the layer is empty at these zoom levels.")
    legend = []
    if layer.type() == QgsMapLayer.VectorLayer:
        legend = legend_entries(layer, os.path.join(out_dir, "legend"), key, legend_wrap_strings(project))
    style_doc = QgsMapLayerStyle()
    style_doc.readFromLayer(layer)
    entry = {"kind": "overlay" if layer.type() == QgsMapLayer.VectorLayer else "imagery", "minzoom": minzoom, "maxzoom": maxzoom,
             "tile_scale": 2, "tile_format": res.get("format"), "tile_count": res.get("tiles", 0),
             "visible_from": res.get("first_zoom") or minzoom, "opacity": 1.0, "legend": legend, "clickable": False}
    files = [os.path.basename(tile_path)]
    if res.get("parts"):                       # big layers are saved in pieces under 1 GB, as packages are
        entry["tile_parts"] = [{"tiles": os.path.basename(pt["path"]), "minzoom": pt["minzoom"], "maxzoom": pt["maxzoom"],
                                "bounds": pt["bounds"]} for pt in res["parts"]]
        files = sorted({os.path.basename(pt["path"]) for pt in res["parts"]} | set(files))
    files += [e["icon"] for e in legend if e.get("icon")]
    return {"dir": out_dir, "key": key, "title": title, "tiles": os.path.basename(tile_path), "files": files,
            "style": {"format": SHARED_FORMAT, "qml": style_doc.xmlData(), "layer": entry}}


def _num(v):
    try:
        return max(0, int(float(v or 0)))
    except (TypeError, ValueError):
        return 0


def nice_title(name):
    t = name.replace("_", " ").strip()
    return t[:1].upper() + t[1:] if t else name


def plan(layer_specs, boundary, boundary_crs, *, project=None, imagery_maxzoom=None, overlay_maxzoom=20, minzoom=12,
         footprints="auto", shared_out=None):
    """Group the chosen layers into web layers and estimate the work. Returns list of web-layer dicts.

    Each has "estimate" (tiles really to draw: only inside the boundary, and for imagery only where the images have
    pixels), "estimate_by_zoom", "est_bytes" and "est_seconds" (from rates learned on this computer), and for the
    build "coverage" / "extents" to skip empty ground. footprints: "auto" (an image's outline instead of its pixels
    when it's huge with no pyramids, to keep the dialog quick), True (always the pixels: the build), False.

    A layer referred to by key (a spec with "shared") is not part of the package: it adds nothing here. shared_out, if given,
    collects those references in order, each with where it goes in the list of web layers (top first)."""
    project = project or QgsProject.instance()
    b3857 = bnd.to_crs(boundary, boundary_crs, EPSG3857, project)
    lat = (bnd.lonlat_bounds(boundary, boundary_crs, project)[1] + bnd.lonlat_bounds(boundary, boundary_crs, project)[3]) / 2
    used, web, imagery_groups = set(), [], {}
    for spec in layer_specs:
        lyr = spec["layer"]
        if is_web_basemap(lyr):
            continue
        if spec.get("shared"):
            if shared_out is not None:
                shared_out.append(shared_reference(spec, len(web)))
            continue
        if is_plain_imagery(lyr) and spec.get("merge_imagery", True):
            key = spec.get("group") or "Imagery"
            g = imagery_groups.get(key)
            if g is None:
                g = {"kind": "imagery", "title": spec.get("group") or spec.get("title") or lyr.name(),
                     "group": "Imagery", "layers": [], "visible": spec.get("visible", True), "res": 99.0,
                     "exclusive": spec.get("exclusive", False)}
                imagery_groups[key] = g
                web.append(g)
            g["layers"].append(lyr)
            g.setdefault("sources", []).append((lyr, spec.get("title") or lyr.name()))
            g["res"] = min(g["res"], raster_resolution_m(lyr, project))
        elif lyr.type() == QgsMapLayer.RasterLayer:
            web.append({"kind": "imagery", "title": spec.get("title") or lyr.name(), "group": spec.get("group") or "",
                        "layers": [lyr], "visible": spec.get("visible", True), "exclusive": spec.get("exclusive", False),
                        "sources": [(lyr, spec.get("title") or nice_title(lyr.name()))], "res": raster_resolution_m(lyr, project),
                        "sources": [(lyr, spec.get("title") or lyr.name())],
                        "styled": True})
        else:
            opt = web_options(lyr, spec.get("web"))
            raw = spec.get("web") or {}
            web.append({"kind": "overlay", "title": spec.get("title") or nice_title(lyr.name()), "group": spec.get("group") or "",
                        "around_requested": _num(raw.get("around_m")),
                        "layers": [lyr], "visible": spec.get("visible", True), "exclusive": spec.get("exclusive", False),
                        "features": spec.get("features", True) or opt["show"] != "qgis" or bool(spec.get("labels")),
                        "clickable": spec.get("features", True) or opt["show"] in ("direction", "dots"),
                        "labels": bool(spec.get("labels")), "web": opt})
    for w in web:
        w["id"] = slug(w["title"], used)
        if w["kind"] == "imagery":
            w["minzoom"] = minzoom
            w["maxzoom"] = imagery_maxzoom or auto_max_zoom(w["res"], lat)
            w["scale"] = 1
        else:
            w["minzoom"] = minzoom
            w["maxzoom"] = overlay_maxzoom
            w["scale"] = 2
        drawn_on_web = w.get("web", {}).get("show", "qgis") != "qgis"
        w["drawn_on_web"] = drawn_on_web
        w["lat"] = lat
        w["inside"] = any(_overlaps(l, boundary, boundary_crs, project) for l in w["layers"])
        if w["kind"] == "imagery":
            w["no_pyramids"] = [t for l, t in w.get("sources", []) if cov.has_pyramids(l) is False
                                and cov.raster_pixels(l) > 25_000_000]
        _estimate(w, b3857, project, footprints)
    return web


def _estimate(w, b3857, project, footprints):
    """Fill in the estimate, and coverage/extents for the build. Falls back to the old box count if anything fails."""
    w["coverage"], w["extents"], w["footprint"] = None, None, "bbox"
    w["estimate_by_zoom"] = {}
    if w["drawn_on_web"]:
        w["estimate"] = 0
    else:
        try:
            bgrid = cov.boundary_grid(b3857)
            if w["kind"] == "imagery":
                files_of = _local_files
                grid, how = cov.imagery_coverage(bgrid, w["layers"], project,
                                                 render=True if footprints is True else (False if footprints is False else "auto"),
                                                 files_of=files_of)
                w["coverage"] = grid
                w["footprint"] = how
                area = grid & bgrid
            else:
                ext = cov.extent_grid(bgrid, w["layers"], project)
                # a little extra so symbols drawn just outside a layer's extent (big markers) aren't cut off
                w["extents"] = [(r[0] - 200, r[1] - 200, r[2] + 200, r[3] + 200)
                                for r in (cov.layer_rect_3857(l, project) for l in w["layers"])]
                w["footprint"] = "extent"
                area = ext & bgrid
            w["estimate_by_zoom"] = area.counts(w["minzoom"], w["maxzoom"])
            w["estimate"] = sum(w["estimate_by_zoom"].values())
        except Exception:  # noqa: anything odd (no numpy, unusual layer): count the whole box as before
            w["coverage"], w["extents"], w["footprint"] = None, None, "bbox"
            w["estimate"] = estimate_tiles(b3857, w["minzoom"], w["maxzoom"])
    w["est_seconds"] = w["estimate"] * cov.rate(w["kind"], "seconds")
    w["est_bytes"] = int(w["estimate"] * cov.rate(w["kind"], "bytes"))


# ---------------------------------------------------------------- reusing tiles from an earlier build
def _local_files(layer):
    """The files a raster layer's pixels come from (with ECW/TIFF side files), or None if it isn't plain files on
    disk (online services etc.), in which case its tiles are always redrawn."""
    src = layer.source().split("|")[0].split("?")[0]
    if src.lower().startswith("file:///"):
        src = src[8:] if os.name == "nt" else src[7:]
    if not os.path.isfile(src):
        return None
    folder, base = os.path.dirname(src) or ".", os.path.basename(src).lower()
    stem = os.path.splitext(base)[0]
    try:
        side = [os.path.join(folder, n) for n in os.listdir(folder)
                if (os.path.splitext(n)[0].lower() == stem or n.lower().startswith(base))
                and not n.lower().endswith((".aux.xml", "-shm", ".lock"))]   # GDAL/SQLite write these while reading
    except OSError:
        side = []
    return sorted(set([src] + [f for f in side if os.path.isfile(f)]))


def _vector_digest(layer, b3857):
    """Fingerprint of the features a vector layer draws inside the property (geometry and every attribute),
    so edits are noticed whatever the layer is stored in."""
    from qgis.core import QgsFeatureRequest
    h = hashlib.sha256()
    try:
        rect = QgsCoordinateTransform(EPSG3857, layer.crs(), QgsProject.instance()).transformBoundingBox(
            b3857.boundingBox())
        req = QgsFeatureRequest().setFilterRect(rect)
    except Exception:  # noqa: odd CRS: read everything
        req = QgsFeatureRequest()
    h.update(layer.subsetString().encode())
    for f in sorted(layer.getFeatures(req), key=lambda f: f.id()):
        h.update(str(f.id()).encode())
        h.update(repr(f.attributes()).encode())
        g = f.geometry()
        h.update(bytes(g.asWkb()) if g and not g.isNull() else b"-")
    return h.hexdigest()


def tile_key(w, b3857, opt=None):
    """See tile_keys; the current fingerprint."""
    return tile_keys(w, b3857, opt)[0]


def tile_keys(w, b3857, opt=None):
    """Fingerprint of everything that decides how a web layer's tiles look: its data (raster files' size and
    time; vector features inside the property), its QGIS style (symbols, labels, opacity, scale limits), the
    boundary and the zoom levels. Same fingerprint = same tiles, so they can be copied from an earlier build."""
    from qgis.core import QgsMapLayerStyle
    opt = opt or {}
    key = {"v": TILE_KEY_VERSION, "kind": w["kind"], "z": [w["minzoom"], w["maxzoom"]], "scale": w["scale"],
           "styled": bool(w.get("styled")), "size": float(opt.get("size") or 1.0) if w["kind"] == "overlay" else 1.0,
           "boundary": b3857.asWkt(2), "layers": []}
    if w["kind"] == "overlay":
        key["nosel"] = 1          # overlays drawn before 0.6.8 could show QGIS selections in yellow: draw those again
        if any(getattr(l, "labelsEnabled", lambda: False)() for l in w["layers"]):
            key["nolabels"] = 1   # labels are written by the web map since 0.7.1: tiles drawn with QGIS labels are redrawn
    raw = []                                       # 0.6.2/0.6.3 fingerprints kept symbol ids in; still matched
    for lyr in w["layers"]:
        if lyr.type() == QgsMapLayer.VectorLayer:
            data = _vector_digest(lyr, b3857)
        else:
            files = _local_files(lyr)
            if files is None:
                return None, None
            data = [[os.path.basename(f), os.path.getsize(f), int(os.path.getmtime(f))] for f in files]
        style = QgsMapLayerStyle()
        style.readFromLayer(lyr)
        # symbol layer ids are random in projects last saved by older QGIS versions (new ones each time the project
        # opens); they don't change how anything looks, so leave them out
        xml = re.sub(r'\s(?:id|uuid)="\{?[0-9a-fA-F-]{36}\}?"', "", style.xmlData())
        key["layers"].append({
            "source": lyr.source(), "provider": lyr.providerType(), "crs": lyr.crs().authid() or lyr.crs().toWkt(),
            "data": data, "style": xml, "opacity": lyr.opacity(),
            "scales": [lyr.hasScaleBasedVisibility(), lyr.minimumScale(), lyr.maximumScale()]})
        raw.append(style.xmlData())
    h = lambda k: hashlib.sha256(json.dumps(k, sort_keys=True).encode()).hexdigest()[:32]
    old = json.loads(json.dumps(key))
    for entry, x in zip(old["layers"], raw):
        entry["style"] = x
    return h(key), h(old)


def _previous(reuse_from, out_dir):
    """Tiles of an earlier build to reuse: (tiles folder, its manifest, folder to delete afterwards)."""
    if not reuse_from or not os.path.isfile(os.path.join(reuse_from, "manifest.json")):
        return None, None, None
    try:
        with open(os.path.join(reuse_from, "manifest.json"), encoding="utf-8") as fh:
            man = json.load(fh)
    except (OSError, ValueError):
        return None, None, None
    tiles = os.path.join(reuse_from, "tiles")
    if os.path.normcase(os.path.abspath(reuse_from)) == os.path.normcase(os.path.abspath(out_dir)):
        # rebuilding into the same (today's) folder: keep the old tiles aside while the new ones are made
        aside = os.path.join(out_dir, "tiles.previous")
        try:
            if os.path.isdir(aside):
                shutil.rmtree(aside)
            if os.path.isdir(tiles):
                os.replace(tiles, aside)
        except OSError:
            return None, None, None            # can't set the old tiles aside (e.g. a file is open): draw everything
        return aside, man, aside
    return tiles, man, None


def _same_boundary(prev_dir, b4326_json):
    try:
        with open(os.path.join(prev_dir, "boundary.geojson")) as fh:
            old = json.load(fh)["features"][0]["geometry"]
        return json.dumps(old, sort_keys=True) == json.dumps(b4326_json, sort_keys=True)
    except (OSError, ValueError, KeyError, IndexError):
        return False


def _legacy_imagery_match(w, entry, prev_man, prev_root, b4326_json):
    """Builds made before fingerprints existed: plain orthomosaic tiles can still be reused when it's the same
    map, the same imagery layer and zoom levels, the same boundary, and no source file changed since that build."""
    if not entry or entry.get("tile_key") or w["kind"] != "imagery" or w.get("styled"):
        return False
    if entry.get("kind") != "imagery" or [entry.get("minzoom"), entry.get("maxzoom")] != [w["minzoom"], w["maxzoom"]]:
        return False
    try:
        built = dt.datetime.fromisoformat(prev_man["created"]).timestamp()
    except (KeyError, ValueError):
        return False
    for lyr in w["layers"]:
        files = _local_files(lyr)
        if files is None or any(int(os.path.getmtime(f)) > built for f in files):   # created is to the second
            return False
    return _same_boundary(prev_root, b4326_json)


def _link_or_copy(src, dst):
    """Copy an earlier build's tile file. Returns False if it couldn't be copied (the layer is then drawn)."""
    try:
        os.link(src, dst)                     # instant, no extra disk space (same drive, where allowed)
        return True
    except OSError:
        pass
    try:
        # plain byte copy: network drives can refuse copying file dates/permissions (copy2), which isn't needed
        with open(src, "rb") as a, open(dst, "wb") as b:
            shutil.copyfileobj(a, b, 1024 * 1024)
        return os.path.getsize(dst) == os.path.getsize(src)
    except OSError:
        try:
            os.remove(dst)
        except OSError:
            pass
        return False


def build(layer_specs, boundary, boundary_crs, out_dir, *, title, survey_date=None, notes="",
          project=None, imagery_maxzoom=None, overlay_maxzoom=20, minzoom=12, progress=None,
          map_title=None, description=None, kind=None, reuse_from=None, mask=None, places=None, log=None):
    """title is the property (farm / client); map_title what this map is, e.g. "Waterway risk assessment"."""
    """Build the package into out_dir. Returns the manifest dict.

    reuse_from: an earlier build; any layer whose data, style, boundary and zooms are unchanged gets its tiles
    copied from there instead of drawn again (orthomosaics take by far the longest)."""
    project = project or QgsProject.instance()
    try:
        tcache.clean_up(log)               # old temporary build folders and drawn tiles nobody came back for
    except Exception:  # noqa
        pass
    os.makedirs(out_dir, exist_ok=True)
    prev_tiles, prev_man, aside = _previous(reuse_from, out_dir)
    try:
        return _build(layer_specs, boundary, boundary_crs, out_dir, title=title, survey_date=survey_date, notes=notes,
                      project=project, imagery_maxzoom=imagery_maxzoom, overlay_maxzoom=overlay_maxzoom,
                      minzoom=minzoom, progress=progress, map_title=map_title, description=description, kind=kind,
                      prev_tiles=prev_tiles, prev_man=prev_man, prev_root=reuse_from, mask=mask, places=places, log=log)
    except BaseException:
        if aside and os.path.isdir(aside):     # failed or cancelled: put the old tiles back for next time
            if os.path.isdir(os.path.join(out_dir, "tiles")):
                shutil.rmtree(os.path.join(out_dir, "tiles"), ignore_errors=True)
            os.replace(aside, os.path.join(out_dir, "tiles"))
            aside = None
        raise
    finally:
        if aside and os.path.isdir(aside):
            shutil.rmtree(aside, ignore_errors=True)


def _build(layer_specs, boundary, boundary_crs, out_dir, *, title, survey_date, notes, project, imagery_maxzoom,
           overlay_maxzoom, minzoom, progress, map_title, description, kind, prev_tiles, prev_man, prev_root, mask=None,
           places=None, log=None):
    for sub in ("tiles", "data", "legend", "photos"):
        p = os.path.join(out_dir, sub)
        if os.path.isdir(p):
            shutil.rmtree(p)
        os.makedirs(p)
    shared = []                                # layers referred to by key: not exported into this package
    if progress:
        progress(0, 1, "Working out where the layers have something to draw")
    web = plan(layer_specs, boundary, boundary_crs, project=project, imagery_maxzoom=imagery_maxzoom,
               overlay_maxzoom=overlay_maxzoom, minzoom=minzoom, footprints=True, shared_out=shared)
    if log is not None:
        for w in web:
            if not w["drawn_on_web"]:
                log.write(f"plan: {w['title']} ({w['kind']}, zoom {w['minzoom']}-{w['maxzoom']}): about {w['estimate']:,} "
                          f"tiles, {w['est_bytes'] / 1e6:.0f} MB, {w['est_seconds'] / 60:.0f} min; area from {w['footprint']}")
    wraps = legend_wrap_strings(project)
    b3857 = bnd.to_crs(boundary, boundary_crs, EPSG3857, project)
    b4326 = bnd.to_crs(boundary, boundary_crs, QgsCoordinateReferenceSystem("EPSG:4326"), project)
    b4326_json = json.loads(b4326.asJson(7))
    prev_layers = {e.get("tile_key"): e for e in (prev_man or {}).get("layers", []) if e.get("tile_key") and e.get("tiles")}
    prev_by_id = {e["id"]: e for e in (prev_man or {}).get("layers", []) if e.get("tiles")}
    same_map = prev_man is not None and (not prev_man.get("map_title")      # built before maps had titles
                                         or prev_man.get("map_title") == (map_title or title))
    reused, drawn = [], []
    with open(os.path.join(out_dir, "boundary.geojson"), "w") as fh:
        json.dump({"type": "FeatureCollection", "features": [
            {"type": "Feature", "properties": {"area_ha": round(bnd.area_ha(boundary), 2)},
             "geometry": b4326_json}]}, fh)

    total = sum(w["estimate"] for w in web) or 1
    done_before = 0
    out_layers, left_out = [], []
    for w in web:
        def prog(i, n, msg, _w=w, _base=done_before):
            if progress:
                progress(_base + (i / max(n, 1)) * _w["estimate"], total, msg)
        opt = w.get("web") or {}
        key, res = None, None
        if opt.get("show", "qgis") != "qgis":
            res = {}                                   # drawn by the web map itself from the features
        else:
            try:
                key, old_key = tile_keys(w, b3857, opt)
            except Exception:  # noqa: anything odd about the layer: just draw it
                key, old_key = None, None
            tile_path = os.path.join(out_dir, "tiles", w["id"] + ".pmtiles")
            hit = (prev_layers.get(key) or prev_layers.get(old_key)) if key else None
            if hit is None and same_map and _legacy_imagery_match(w, prev_by_id.get(w["id"]), prev_man, prev_root, b4326_json):
                hit = prev_by_id[w["id"]]
            src = os.path.join(prev_tiles, os.path.basename(hit["tiles"])) if hit and prev_tiles else None
            if src and os.path.isfile(src):
                prog(0, 1, f"{w['title']}: unchanged, reusing the last build's tiles")
            if src and os.path.isfile(src) and _link_or_copy(src, tile_path):
                res = {"path": tile_path, "format": hit.get("tile_format"), "tiles": hit.get("tile_count", 0),
                       "first_zoom": hit.get("visible_from")}
                extra = hit.get("tile_parts") or []
                copied = []
                for part in extra[1:]:                     # a big layer saved in pieces: copy every piece
                    psrc = os.path.join(prev_tiles, os.path.basename(part["tiles"]))
                    pdst = os.path.join(out_dir, "tiles", os.path.basename(part["tiles"]).replace(
                        os.path.basename(hit["tiles"])[:-8], w["id"], 1))
                    if not (os.path.isfile(psrc) and _link_or_copy(psrc, pdst)):
                        res = None                         # a piece is missing: draw the layer again
                        break
                    copied.append(dict(part, path=pdst))
                if res is not None:
                    if extra:
                        res["parts"] = [dict(extra[0], path=tile_path)] + copied
                    reused.append(w["title"])
        if res is None:
            drawn.append(w["title"])
            if w["kind"] == "imagery" and not w.get("styled"):
                layers = [_imagery_clone(l) for l in w["layers"]]
            else:
                layers = [scaled_layer(l, float(opt.get("size") or 1.0)) for l in w["layers"]]
            res = render_to_pmtiles(layers, b3857, tile_path, w["minzoom"], w["maxzoom"], scale=w["scale"],
                                    quality=80 if w["kind"] == "imagery" else 90,
                                    labels=False, project=project, progress=prog, name=w["title"],   # the web map writes labels
                                    coverage=w.get("coverage"), extents=w.get("extents"), cache_key=key)
            if log is not None:
                log.write(f"drew {w['title']}: {res.get('jobs', 0)} parts ({res.get('resumed_jobs', 0)} carried on from "
                          f"an earlier try), {res.get('tiles', 0):,} tiles kept, {res.get('seconds', 0):.0f} s")
            cov.remember_rate(w["kind"], seconds=res.get("seconds"), tiles=res.get("drawn_tiles", 0))
            cov.remember_rate(w["kind"], bytes_=res.get("bytes"), tiles=res.get("attempted_tiles", 0))
        done_before += w["estimate"]
        entry = {"id": w["id"], "title": w["title"], "group": w["group"], "kind": w["kind"],
                 "visible": bool(w["visible"]), "opacity": 1.0, "exclusive": bool(w.get("exclusive")),
                 "minzoom": w["minzoom"], "maxzoom": w["maxzoom"], "tile_scale": w["scale"],
                 "tiles": ("tiles/" + w["id"] + ".pmtiles") if res.get("path") else None,
                 "tile_format": res.get("format"), "tile_count": res.get("tiles", 0), "legend": [],
                 "tile_key": key if res.get("path") else None,
                 "visible_from": res.get("first_zoom") or w["minzoom"]}
        if res.get("parts"):                    # saved in pieces (big imagery): the viewer draws them all
            entry["tile_parts"] = [{"tiles": "tiles/" + os.path.basename(pt["path"]), "minzoom": pt["minzoom"],
                                    "maxzoom": pt["maxzoom"], "bounds": pt["bounds"]} for pt in res["parts"]]
        if w["kind"] == "overlay":
            lyr = w["layers"][0]
            entry["legend"] = legend_entries(lyr, os.path.join(out_dir, "legend"), w["id"], wraps)
            linfo = label_info(lyr) if w.get("labels") else None
            if w.get("features", True):
                if progress:
                    progress(done_before, total, f"{w['title']}: features and photos")
                around = int(opt.get("around_m") or 0) if opt.get("show", "qgis") != "qgis" else 0
                info = export_features(lyr, boundary, boundary_crs, os.path.join(out_dir, "data", w["id"] + ".geojson"),
                                       project=project, photo_dir=os.path.join(out_dir, "photos"), layer_slug=w["id"],
                                       field_names=opt.get("fields"), labels=opt.get("labels"),
                                       title_expr=opt.get("title_expr"),
                                       title_auto=bool(opt.get("title_auto")) and opt.get("show") in ("direction", "dots"),
                                       places=places,
                                       label_expr=(linfo or {}).get("expr"),
                                       # roads and rivers kilometres beyond the property: a little coarser keeps them quick
                                       simplify_m=(max(0.2, around / 2000) if around else 0.2) if opt.get("show") == "vector" else 0.0,
                                       precision=6 if opt.get("show") == "vector" else 7,
                                       around_m=around,
                                       pitch_field=guess_pitch_field(lyr) if opt.get("show") == "direction" else None,
                                       dir_expr=opt.get("dir_expr", "") if opt.get("show") == "direction" else "")
                if around and info["count"]:
                    entry["around_m"] = around
                if linfo:
                    entry["labels"] = {k: v for k, v in linfo.items() if k != "expr" and v is not None}
                if not w.get("clickable", True):
                    entry["clickable"] = False
                entry.update({"features": "data/" + w["id"] + ".geojson", "feature_count": info["count"],
                              "geometry": info["geometry"], "fields": info["fields"], "photos": info["photos"],
                              "classes": info["classes"]})
            if opt.get("show") in ("direction", "dots"):
                entry["draw"] = {"type": opt["show"], "size": float(opt.get("size") or 1.0),
                                 "colors": symbol_colors(lyr)}
                entry["visible_from"] = w["minzoom"]
            elif opt.get("show") == "vector":
                entry["vector"] = web_style(lyr, float(opt.get("size") or 1.0))
                zmin, zmax = zoom_range(lyr)
                entry["visible_from"] = zmin or 0          # no map images, so no lower limit unless QGIS sets one
                if zmax:
                    entry["visible_to"] = zmax
        elif w.get("styled"):
            entry["legend"] = legend_entries(w["layers"][0], os.path.join(out_dir, "legend"), w["id"], wraps)
        if entry["tiles"] is None and not entry.get("feature_count"):
            left_out += [t for _, t in w.get("sources", [])]
            continue  # nothing of this layer falls inside the boundary
        if len(w.get("sources", [])) > 1:          # merged orthomosaics: check each one covers part of the property
            for lyr, t in w["sources"]:
                if not _overlaps(lyr, boundary, boundary_crs, project):
                    left_out.append(t)
        out_layers.append(entry)

    manifest = {
        "format": FORMAT,
        "viewer": 3,
        "property": title,
        "title": map_title or title,
        "map_title": map_title or title,
        "description": (description or notes or "").strip(),
        "kind": (kind or "").strip(),
        "survey_date": survey_date,
        "notes": notes,
        "prepared_by": "Rural Consulting Limited",
        "created": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "area_ha": round(bnd.area_ha(boundary), 2),
        "bounds": bnd.lonlat_bounds(boundary, boundary_crs, project),
        # the furthest any layer reaches beyond the boundary (roads, rivers), so the map lets you look that far
        "around_m": max([e.get("around_m", 0) for e in out_layers] or [0]),
        "boundary": "boundary.geojson",
        # shade everything outside the boundary on the web map (drawn by the viewer, so nothing is clipped)
        "mask": {"color": "#000000", "opacity": round(float(mask), 2)} if mask else None,
        "layers": out_layers,
    }
    if shared:                                 # platform only; an additive field the viewer and the app read
        manifest["shared_layers"] = shared
    files = []
    for root, _, names in os.walk(out_dir):
        for n in names:
            rel = os.path.relpath(os.path.join(root, n), out_dir).replace("\\", "/")
            if rel.split("/")[0] in ("tiles", "data", "legend", "photos") or rel == "boundary.geojson":
                files.append(rel)
    manifest["files"] = sorted(files)
    manifest["bytes"] = sum(os.path.getsize(os.path.join(out_dir, f)) for f in files)
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=1, ensure_ascii=False)
    # local preview copy of the viewer
    shutil.copytree(VIEWER_DIR, out_dir, dirs_exist_ok=True)
    if progress:
        progress(total, total, "Done")
    # left_out and reused are for the person building; not saved or published
    return dict(manifest, left_out=left_out, reused=reused, drawn=drawn,
                reused_from=(prev_man or {}).get("created") if prev_man else None)
