"""Keep the portal sign-in (a refresh token, never a password) in Windows Credential Manager
(encrypted per Windows user).

Used when the QGIS password store is disabled or has no master password. On other
systems, or if anything goes wrong, available() is False and callers fall back.
"""
import ctypes
import sys

TARGET = "RCL map portal sign-in"
PLATFORM_TARGET = "RCL platform sign-in"      # publish to the platform: its own sign-in, kept separately
OLD_TARGET = "RCL map portal service key"     # the secret key older versions kept; removed on sign-in
CRED_TYPE_GENERIC = 1
CRED_PERSIST_LOCAL_MACHINE = 2

_api = None
if sys.platform == "win32":
    try:
        from ctypes import wintypes

        class CREDENTIAL(ctypes.Structure):
            _fields_ = [
                ("Flags", wintypes.DWORD),
                ("Type", wintypes.DWORD),
                ("TargetName", wintypes.LPWSTR),
                ("Comment", wintypes.LPWSTR),
                ("LastWritten", wintypes.FILETIME),
                ("CredentialBlobSize", wintypes.DWORD),
                ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
                ("Persist", wintypes.DWORD),
                ("AttributeCount", wintypes.DWORD),
                ("Attributes", ctypes.c_void_p),
                ("TargetAlias", wintypes.LPWSTR),
                ("UserName", wintypes.LPWSTR),
            ]

        PCREDENTIAL = ctypes.POINTER(CREDENTIAL)
        _adv = ctypes.WinDLL("advapi32", use_last_error=True)
        _adv.CredWriteW.argtypes = [PCREDENTIAL, wintypes.DWORD]
        _adv.CredWriteW.restype = wintypes.BOOL
        _adv.CredReadW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(PCREDENTIAL)]
        _adv.CredReadW.restype = wintypes.BOOL
        _adv.CredDeleteW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD]
        _adv.CredDeleteW.restype = wintypes.BOOL
        _adv.CredFree.argtypes = [ctypes.c_void_p]
        _adv.CredFree.restype = None
        _api = _adv
    except Exception:  # noqa
        _api = None


def available():
    return _api is not None


def save(secret, target=TARGET):
    if _api is None:
        return False
    try:
        blob = secret.encode("utf-8")
        buf = (ctypes.c_ubyte * len(blob)).from_buffer_copy(blob)
        c = CREDENTIAL()
        c.Type = CRED_TYPE_GENERIC
        c.TargetName = target
        c.Comment = "Keeps you signed in to the RCL map portal in the RCL Web Package QGIS tool"
        c.CredentialBlobSize = len(blob)
        c.CredentialBlob = ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte))
        c.Persist = CRED_PERSIST_LOCAL_MACHINE
        c.UserName = "sign-in"
        return bool(_api.CredWriteW(ctypes.byref(c), 0)) and load(target) == secret
    except Exception:  # noqa
        return False


def load(target=TARGET):
    if _api is None:
        return None
    p = PCREDENTIAL()
    try:
        if not _api.CredReadW(target, CRED_TYPE_GENERIC, 0, ctypes.byref(p)):
            return None
        c = p.contents
        return ctypes.string_at(c.CredentialBlob, c.CredentialBlobSize).decode("utf-8") or None
    except Exception:  # noqa
        return None
    finally:
        if p:
            _api.CredFree(p)


def delete(target=TARGET):
    if _api is not None:
        try:
            _api.CredDeleteW(target, CRED_TYPE_GENERIC, 0)
        except Exception:  # noqa
            pass
