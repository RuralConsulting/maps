"""Tiny local web server with HTTP range support (needed by PMTiles) for previewing a package."""
import functools
import http.server
import os
import re
import socket
import threading

_servers = {}


class RangeHandler(http.server.SimpleHTTPRequestHandler):
    def list_directory(self, path):      # no folder listings
        self.send_error(404, "Not found")
        return None

    def log_message(self, *args):  # keep the QGIS log quiet
        pass

    def end_headers(self):
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def send_head(self):
        # only the browser on this computer, by this exact address: a web page that points its own name at
        # 127.0.0.1 (DNS rebinding) is refused, so other sites can't read the package being previewed
        host = (self.headers.get("Host") or "").strip().lower()
        if host not in (f"127.0.0.1:{self.server.server_address[1]}", f"localhost:{self.server.server_address[1]}"):
            self.send_error(403, "Preview only")
            return None
        rng = self.headers.get("Range")
        path = self.translate_path(self.path)
        if not rng or not os.path.isfile(path):
            return super().send_head()
        m = re.match(r"bytes=(\d*)-(\d*)", rng)
        size = os.path.getsize(path)
        if not m:
            return super().send_head()
        start = int(m.group(1)) if m.group(1) else max(0, size - int(m.group(2) or 0))
        end = int(m.group(2)) if m.group(1) and m.group(2) else size - 1
        end = min(end, size - 1)
        if start > end:
            self.send_error(416)
            return None
        f = open(path, "rb")
        f.seek(start)
        self.send_response(206)
        self.send_header("Content-Type", self.guess_type(path))
        self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Content-Length", str(end - start + 1))
        self.end_headers()
        self._range_left = end - start + 1
        return f

    def copyfile(self, source, outputfile):
        left = getattr(self, "_range_left", None)
        if left is None:
            return super().copyfile(source, outputfile)
        while left > 0:
            chunk = source.read(min(65536, left))
            if not chunk:
                break
            outputfile.write(chunk)
            left -= len(chunk)


def serve(directory):
    """Serve `directory` on a free local port (once per folder). Returns the base URL."""
    directory = os.path.abspath(directory)
    if directory in _servers:
        return _servers[directory][1]
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    handler = functools.partial(RangeHandler, directory=directory)
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", port), handler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    url = f"http://127.0.0.1:{port}/"
    _servers[directory] = (httpd, url)
    return url


def stop_all():
    for httpd, _ in _servers.values():
        httpd.shutdown()
    _servers.clear()
