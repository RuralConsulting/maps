"""Export a vector layer's features (clipped to the boundary) for clicking on the web map,
copy linked photos, and build legend images."""
import json
import os
import re

from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils,
    QgsGraduatedSymbolRenderer,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsGeometry,
    QgsMapLayer,
    QgsMarkerSymbol,
    QgsProject,
    QgsRenderContext,
    QgsSymbolLayer,
    QgsSymbolLayerUtils,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QDate, QDateTime, QSize, Qt, QTime
from qgis.PyQt.QtGui import QColor, QImage, QImageReader, QPainter, QPixmap

EPSG4326 = QgsCoordinateReferenceSystem("EPSG:4326")
IMG_RE = re.compile(r"\.(jpe?g|png|tif?f|webp)$", re.I)
SKIP_FIELDS = {"fid", "ogc_fid", "objectid", "gid"}
HTML_RE = re.compile(r"<\s*/?\s*[a-z][a-z0-9]*\b[^<>]*>|<!--|&lt;\s*/?\s*[a-z]", re.I)          # any HTML tag
# file and server paths anywhere in the text, and internal document links (SharePoint, OneDrive)
PATH_RE = re.compile(r"(file:|(?<![a-z])[a-z]:[\\/]|\\\\[^\\\s]|(?<![:\w])//[a-z0-9_.-]+/|(^|\s)\.{1,2}[\\/]|(^|\s)~/|(^|\s)/(home|users|mnt|media|volumes|srv|var|data|shared)/|sharepoint\.com|1drv\.ms|onedrive\.live)", re.I)
DIR_NAMES = ("gimbalyawdegree", "gimbal_yaw", "gyd", "fyd", "flightyawdegree", "azimuth", "direction",
             "heading", "bearing", "yaw", "camerayaw", "photo_dir", "img_dir")


def is_private_value(v):
    """HTML snippets and file/server paths: internal detail that must not reach customers."""
    if not isinstance(v, str):
        return False
    t = v.strip()
    if HTML_RE.search(t) or PATH_RE.search(t):
        return True
    return ("\\" in t or "/" in t) and bool(IMG_RE.search(t))


def slug(text, used=None):
    s = re.sub(r"[^a-z0-9]+", "-", (text or "layer").lower()).strip("-")[:48] or "layer"
    if used is not None:
        base, n = s, 2
        while s in used:
            s = f"{base}-{n}"
            n += 1
        used.add(s)
    return s


def _value(v):
    if v is None:
        return None
    try:
        from qgis.PyQt.QtCore import QVariant
        if isinstance(v, QVariant):
            return None if v.isNull() else _value(v.value())
    except ImportError:
        pass
    if isinstance(v, QDateTime):
        return v.toString(Qt.ISODate) if v.isValid() else None
    if isinstance(v, QDate):
        return v.toString(Qt.ISODate) if v.isValid() else None
    if isinstance(v, QTime):
        return v.toString(Qt.ISODate) if v.isValid() else None
    if isinstance(v, (int, float, bool, str)):
        if isinstance(v, float) and v != v:
            return None
        return v
    return str(v)


def visible_fields(layer):
    """Fields shown in the layer's attribute table (hidden columns and id fields are left out)."""
    hidden = set()
    try:
        for col in layer.attributeTableConfig().columns():
            if col.hidden and col.name:
                hidden.add(col.name)
    except Exception:  # noqa
        pass
    out = []
    for i, f in enumerate(layer.fields()):
        if f.name() in hidden or f.name().lower() in SKIP_FIELDS:
            continue
        try:
            if layer.editorWidgetSetup(i).type() == "Hidden":
                continue
        except Exception:  # noqa
            pass
        out.append({"name": f.name(), "alias": layer.attributeDisplayName(i)})
    return out


def default_fields(layer, sample=50):
    """Visible fields, minus any whose values look like HTML or file paths."""
    fields = visible_fields(layer)
    names = [f["name"] for f in fields]
    bad = set()
    for i, f in enumerate(layer.getFeatures(QgsFeatureRequest().setLimit(sample))):
        for n in names:
            try:
                if is_private_value(_value(f[n])):
                    bad.add(n)
            except KeyError:
                pass
    return [f for f in fields if f["name"] not in bad]


def guess_direction(layer):
    """Expression giving the direction a photo faces (degrees clockwise from north), from the layer's
    style (wedge_buffer azimuth, marker rotation) or a likely field name. '' if none."""
    r = layer.renderer() if hasattr(layer, "renderer") else None
    if r is not None:
        try:
            syms = r.symbols(QgsRenderContext())
        except Exception:  # noqa
            syms = []
        angle_key = getattr(QgsSymbolLayer, "PropertyAngle", None)
        for sym in syms:
            for sl in sym.symbolLayers():
                if sl.layerType() == "GeometryGenerator":
                    t = sl.geometryExpression() or ""
                    m = re.search(r"azimuth\s*:=\s*([^,)]+)", t) or \
                        re.search(r"wedge_buffer\s*\(\s*[^,]+,\s*([^,)]+)", t)
                    if m:
                        return m.group(1).strip()
                if angle_key is not None:
                    try:
                        prop = sl.dataDefinedProperties().property(angle_key)
                        if prop and prop.isActive():
                            return prop.asExpression()
                    except Exception:  # noqa
                        pass
            if isinstance(sym, QgsMarkerSymbol):
                try:
                    dd = sym.dataDefinedAngle()
                    if dd and dd.isActive():
                        return dd.asExpression()
                except Exception:  # noqa
                    pass
    by_lower = {f.name().lower(): f.name() for f in layer.fields()}
    for cand in DIR_NAMES:
        if cand in by_lower:
            return '"%s"' % by_lower[cand]
    return ""


def symbol_colors(layer):
    """Hex colour of each legend class (index matches the legend), for drawing points on the web."""
    out = []
    r = layer.renderer()
    if r is None:
        return out
    for it in r.legendSymbolItems():
        sym = it.symbol()
        if sym is None:
            continue
        c = None
        for sl in sym.symbolLayers():          # the marker itself, not a geometry-generator cone
            if sl.layerType() != "GeometryGenerator" and sl.color().isValid() and sl.color().alpha() > 0:
                c = sl.color()
                break
        c = c or sym.color()
        out.append(c.name() if c.isValid() else "#e8590c")
    return out


def renderer_classes(layer):
    """How features map to legend entries: {field, kind, values|ranges}. Index matches legend order."""
    r = layer.renderer()
    if isinstance(r, QgsCategorizedSymbolRenderer):
        vals = []
        for c in r.categories():
            v = c.value()
            vals.append([_value(v) if not isinstance(v, list) else [_value(x) for x in v], c.label()])
        return {"field": r.classAttribute(), "kind": "categories", "values": vals}
    if isinstance(r, QgsGraduatedSymbolRenderer):
        return {"field": r.classAttribute(), "kind": "ranges",
                "ranges": [[rg.lowerValue(), rg.upperValue(), rg.label()] for rg in r.ranges()]}
    return None


def _class_index(classes, props, feature):
    if not classes:
        return None
    field = classes["field"]
    try:
        v = _value(feature[field])
    except KeyError:
        return None
    if classes["kind"] == "categories":
        other = None
        for i, (cv, _lbl) in enumerate(classes["values"]):
            if cv in (None, "") and other is None:
                other = i
            if isinstance(cv, list) and v in cv or cv == v or (cv is not None and v is not None and str(cv) == str(v)):
                return i
        return other
    try:
        fv = float(v)
    except (TypeError, ValueError):
        return None
    for i, (lo, hi, _lbl) in enumerate(classes["ranges"]):
        if lo <= fv <= hi:
            return i
    return None


def _resolve_image(value, layer, project):
    if not isinstance(value, str) or not IMG_RE.search(value.strip()):
        return None
    v = value.strip().replace("\\", "/")
    if v.lower().startswith("file:///"):
        v = v[8:]
    cands = [v]
    home = project.homePath()
    if home:
        cands.append(os.path.join(home, v))
    src = layer.source().split("|")[0]
    if os.path.exists(src):
        cands.append(os.path.join(os.path.dirname(src), v))
    for c in cands:
        if os.path.isfile(c):
            return os.path.normpath(c)
    return None


def _save_photo(src, dst, max_px):
    reader = QImageReader(src)
    reader.setAutoTransform(True)             # honour camera EXIF orientation
    img = reader.read()
    if img.isNull():
        return False
    if max(img.width(), img.height()) > max_px:
        img = img.scaled(max_px, max_px, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    return img.save(dst, "JPEG", 82)


def _zoom_for_scale(scale):
    """Web map zoom level shown at a QGIS scale denominator (1:scale)."""
    import math
    return round(math.log2(559082264.028 / scale), 2) if scale and scale > 0 else None


def label_info(layer):
    """How the layer is labelled in QGIS, for the web map to draw the labels itself:
    {"expr", "color", "size", "halo", "bold", "minzoom", "maxzoom"}, or None if it has no labels."""
    try:
        lab = layer.labeling()
        if lab is None:
            return None
        if hasattr(lab, "settings") and lab.type() == "simple":
            st = lab.settings()
        else:                                            # rule-based: the first rule with settings
            rules = [r for r in lab.rootRule().descendants() if r.settings()] if hasattr(lab, "rootRule") else []
            if not rules:
                return None
            st = rules[0].settings()
        expr = st.fieldName if st.isExpression else QgsExpression.quotedColumnRef(st.fieldName)
        if not st.fieldName:
            return None
        fmt = st.format()
        size = fmt.size()
        unit = int(fmt.sizeUnit()) if not hasattr(fmt.sizeUnit(), "value") else fmt.sizeUnit().value
        px = size * 1.333 if unit in (4,) else size if unit in (2,) else size * 3.78 if unit in (0,) else size * 1.333
        buf = fmt.buffer()
        info = {"expr": expr, "color": fmt.color().name(), "size": round(max(10.0, min(20.0, px)), 1),
                "halo": buf.color().name() if buf.enabled() else None,
                "bold": bool(fmt.font().bold()) or fmt.forcedBold() if hasattr(fmt, "forcedBold") else bool(fmt.font().bold())}
        if st.scaleVisibility:
            info["minzoom"] = _zoom_for_scale(st.minimumScale)     # most zoomed out it shows at
            info["maxzoom"] = _zoom_for_scale(st.maximumScale)
        return info
    except Exception:  # noqa: unusual labelling: fall back to the display name
        return None


PHOTO_NAME = re.compile(r"\.(jpe?g|png|tiff?|heic|webp|dng)$", re.I)


def tidy_title(text):
    """A feature title that is just a photo's file name (DJI_0043.JPG, Farm_Survey_0043.jpg) reads as "Photo 0043"."""
    text = str(text).strip()
    if PHOTO_NAME.search(text) and " " not in text:
        n = re.findall(r"\d+", PHOTO_NAME.sub("", text))
        return "Photo " + n[-1] if n else "Photo"
    return text


def export_features(layer, boundary, boundary_crs, out_path, *, project=None, photo_dir=None,
                    photo_url_prefix="photos/", layer_slug="layer", progress=None, field_names=None, dir_expr="",
                    labels=None, title_expr=None, label_expr=None, simplify_m=0.0, precision=7):
    """Write clipped features as GeoJSON (EPSG:4326). Returns info dict.

    field_names: fields to include (None = default_fields). HTML and file paths are always removed.
    labels: {field name: name customers see}, overriding the QGIS alias.
    title_expr: expression for the title shown when a feature is clicked; None = the layer's QGIS display name,
    "" = no title (the category or layer name is shown instead).
    label_expr: expression for the text the web map writes on each feature (_lbl); None = no labels.
    simplify_m / precision: for layers the web map draws itself, drop vertices closer than this to the line (in
    metres, projected layers only) and round coordinates to this many decimals, to keep the download small."""
    project = project or QgsProject.instance()
    b = QgsGeometry(boundary)
    b.transform(QgsCoordinateTransform(boundary_crs, layer.crs(), project))
    engine = QgsGeometry.createGeometryEngine(b.constGet())
    engine.prepareGeometry()
    to_out = QgsCoordinateTransform(layer.crs(), EPSG4326, project)
    if field_names is None:
        fields = default_fields(layer)
    else:
        allf = {f["name"]: f for f in visible_fields(layer)}
        fields = [allf.get(n) or {"name": n, "alias": n} for n in field_names if n in layer.fields().names()]
    labels = {k: str(v).strip() for k, v in (labels or {}).items() if str(v or "").strip()}
    fields = [dict(f, alias=labels.get(f["name"], f["alias"])) for f in fields]
    names = [f["name"] for f in fields]
    used_names = set()
    gtype = QgsWkbTypes.geometryType(layer.wkbType())
    is_point = gtype == QgsWkbTypes.PointGeometry
    photo_fields = None
    feats, n_photos = [], 0
    classes = renderer_classes(layer)
    custom_title = title_expr is not None
    disp = QgsExpression(layer.displayExpression() or "" if title_expr is None else title_expr)
    ctx = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
    if disp.expression():
        disp.prepare(ctx)
    lexp = QgsExpression(label_expr) if label_expr else None
    if lexp is not None:
        lexp.prepare(ctx)
    dexp = QgsExpression(dir_expr) if dir_expr else None
    if dexp is not None:
        dexp.prepare(ctx)
    req = QgsFeatureRequest().setFilterRect(b.boundingBox())
    for f in layer.getFeatures(req):
        g = f.geometry()
        if g is None or g.isNull() or g.isEmpty():
            continue
        if not engine.intersects(g.constGet()):
            continue
        if not is_point:
            if simplify_m and not layer.crs().isGeographic():
                s = g.simplify(simplify_m)
                if s is not None and not s.isNull() and not s.isEmpty():
                    g = s
            g = g.intersection(b)
            if g.isEmpty():
                continue
            if QgsWkbTypes.geometryType(g.wkbType()) != gtype:
                # cutting along the area's own edge (LUC mapped to the title line) also returns zero-width edge lines
                # or points: keep only pieces of the layer's own kind
                parts = [p for p in g.asGeometryCollection() if QgsWkbTypes.geometryType(p.wkbType()) == gtype]
                if not parts:
                    continue
                g = parts[0] if len(parts) == 1 else QgsGeometry.collectGeometry(parts)
        g.transform(to_out)
        props = {}
        for n in names:
            v = _value(f[n])
            if v in (None, "") or is_private_value(v):
                continue
            props[n] = v
            used_names.add(n)
        if dexp is not None:
            ctx.setFeature(f)
            try:
                d = float(_value(dexp.evaluate(ctx)))
                if d == d:
                    props["_dir"] = round(d % 360, 1)
            except (TypeError, ValueError):
                pass
        if lexp is not None:
            ctx.setFeature(f)
            t = _value(lexp.evaluate(ctx))
            if t not in (None, "") and not is_private_value(str(t)):
                props["_lbl"] = str(t)[:80]
        ci = _class_index(classes, props, f)
        if ci is not None:
            props["_cls"] = ci
        if disp.expression():
            ctx.setFeature(f)
            lbl = _value(disp.evaluate(ctx))
            if lbl not in (None, "") and not is_private_value(str(lbl)):
                props["_label"] = str(lbl) if custom_title else tidy_title(lbl)
        # photos: any attribute that points at an image file
        if photo_dir is not None:
            if photo_fields is None:
                photo_fields = [fl.name() for fl in layer.fields()]
            for fn in photo_fields:
                path = _resolve_image(_value(f[fn]), layer, project)
                if path:
                    os.makedirs(photo_dir, exist_ok=True)
                    base = f"{layer_slug}-{f.id()}"
                    if _save_photo(path, os.path.join(photo_dir, base + ".jpg"), 1600):
                        _save_photo(path, os.path.join(photo_dir, base + "-t.jpg"), 360)
                        props["_photo"] = photo_url_prefix + base + ".jpg"
                        props["_thumb"] = photo_url_prefix + base + "-t.jpg"
                        n_photos += 1
                    break
        feats.append({"type": "Feature", "id": int(f.id()), "properties": props,
                      "geometry": json.loads(g.asJson(precision))})
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump({"type": "FeatureCollection", "features": feats}, fh, ensure_ascii=False, separators=(",", ":"))
    fields = [f for f in fields if f["name"] in used_names]
    return {"count": len(feats), "photos": n_photos, "fields": fields, "classes": classes,
            "geometry": {0: "point", 1: "line", 2: "polygon"}.get(int(gtype), "unknown")}


def _save_pixmap(pix, path):
    return pix.save(path, "PNG")


def legend_wrap_strings(project):
    """The "wrap text on" characters set on legends in the project's print layouts (often "*"), so legend text written
    with them for printing reads normally on the web."""
    out = set()
    try:
        from qgis.core import QgsLayoutItemLegend
        for lay in project.layoutManager().layouts() if project is not None else []:
            for item in lay.items():
                if isinstance(item, QgsLayoutItemLegend) and item.wrapString():
                    out.add(item.wrapString())
    except Exception:  # noqa: layouts are only a hint
        pass
    return sorted(out, key=len, reverse=True)


def tidy_legend_label(label, wraps=()):
    """Legend text for the web: print-layout wrap characters become spaces ("moisture*deficient" -> "moisture deficient")."""
    for w in wraps:
        if w.strip():
            label = label.replace(w, " ")
    label = re.sub(r"(?<=\w)\*(?=\w)", " ", label)        # "*" between words is a wrap marker, layout or not
    return re.sub(r"[ \t]{2,}", " ", label).strip()


def legend_entries(layer, out_dir, layer_slug, wraps=()):
    """Legend swatches rendered by QGIS itself. Returns [{label, icon}]."""
    os.makedirs(out_dir, exist_ok=True)
    entries = []
    if layer.type() == QgsMapLayer.VectorLayer and layer.renderer() is not None:
        items = layer.renderer().legendSymbolItems()
        for i, it in enumerate(items):
            sym = it.symbol()
            label = tidy_legend_label(it.label() or "", wraps)
            if sym is None:
                continue
            if len(items) > 1 and not label.strip():
                label = "Other"
            pix = QgsSymbolLayerUtils.symbolPreviewPixmap(sym, QSize(40, 40), 2)
            name = f"{layer_slug}-{i}.png"
            _save_pixmap(pix, os.path.join(out_dir, name))
            entries.append({"label": label, "icon": "legend/" + name})
    elif layer.type() == QgsMapLayer.RasterLayer and layer.renderer() is not None:
        try:
            items = layer.renderer().legendSymbologyItems()
        except Exception:  # noqa
            items = []
        if len(items) > 1:  # styled rasters (classified, pseudocolour); plain imagery has no legend
            for i, (label, color) in enumerate(items[:24]):
                img = QImage(40, 40, QImage.Format_ARGB32)
                img.fill(QColor(0, 0, 0, 0))
                p = QPainter(img)
                p.fillRect(6, 6, 28, 28, color)
                p.end()
                name = f"{layer_slug}-{i}.png"
                img.save(os.path.join(out_dir, name), "PNG")
                entries.append({"label": tidy_legend_label(str(label), wraps), "icon": "legend/" + name})
    return entries
