"""Where a layer really has something to draw, so builds and estimates skip empty ground.

A Grid is a coarse yes/no raster in web mercator (EPSG:3857) over the property's bounding box: one cell per
`cell` metres (3857 units), at most MAX_SIDE cells a side. It's made from QGIS renders (imagery: the
image's own pixels, so thin drone strips across a big property only cover the strips), from rectangles (layer
extents), and from the boundary itself. Grids are used two ways:
  - hits(rect): could this metatile have anything in it? (dilated by a cell, so it never wrongly says no)
  - count_tiles(z): about how many tiles at zoom z hold something (for the estimate)

Everything here except the render_* helpers is plain Python/numpy, so it can be tested without QGIS.
"""
import hashlib
import math

ORIGIN = 20037508.342789244
MAX_SIDE = 2048
_cache = {}                   # coverage grids already rendered this QGIS session


def tile_size(z):
    return 2 * ORIGIN / (2 ** z)


def tile_bounds(z, x, y):
    s = tile_size(z)
    minx = -ORIGIN + x * s
    maxy = ORIGIN - y * s
    return (minx, maxy - s, minx + s, maxy)


def tile_range(z, xmin, ymin, xmax, ymax):
    s = tile_size(z)
    n = 2 ** z
    x0 = max(0, int(math.floor((xmin + ORIGIN) / s)))
    x1 = min(n - 1, int(math.floor((xmax + ORIGIN) / s)))
    y0 = max(0, int(math.floor((ORIGIN - ymax) / s)))
    y1 = min(n - 1, int(math.floor((ORIGIN - ymin) / s)))
    return x0, x1, y0, y1


def rects_meet(a, b):
    return a[0] <= b[2] and b[0] <= a[2] and a[1] <= b[3] and b[1] <= a[3]


def metatile_jobs(bbox, minz, maxz, meta, hits_boundary, keep=None):
    """Metatiles to draw: [(z, tx0, ty0, tx1, ty1, (xmin, ymin, xmax, ymax))], in zoom order.
    hits_boundary(rect) and keep(rect) say whether a metatile can have anything in it; keep (cheap) is asked first."""
    jobs = []
    for z in range(minz, maxz + 1):
        x0, x1, y0, y1 = tile_range(z, *bbox)
        for mx in range(x0 // meta, x1 // meta + 1):
            for my in range(y0 // meta, y1 // meta + 1):
                tx0, ty0 = max(mx * meta, x0), max(my * meta, y0)
                tx1, ty1 = min(mx * meta + meta - 1, x1), min(my * meta + meta - 1, y1)
                a, b = tile_bounds(z, tx0, ty0), tile_bounds(z, tx1, ty1)
                r = (a[0], b[1], b[2], a[3])
                if keep is not None and not keep(r):
                    continue
                if hits_boundary(r):
                    jobs.append((z, tx0, ty0, tx1, ty1, r))
    return jobs


def job_id(z, tx0, ty0):
    """A stable number for a metatile (for remembering which are done)."""
    return (z << 50) | (tx0 << 25) | ty0


def job_tiles(job):
    z, tx0, ty0, tx1, ty1, _ = job
    return (tx1 - tx0 + 1) * (ty1 - ty0 + 1)


class Grid:
    """Yes/no cells over (x0, y0, x1, y1) in EPSG:3857, row 0 at the top."""

    def __init__(self, x0, y1, cell, rows, cols):
        import numpy as np
        self.x0, self.y1, self.cell = float(x0), float(y1), float(cell)
        self.mask = np.zeros((rows, cols), dtype=bool)
        self._dil = None

    @classmethod
    def over(cls, bbox, max_side=MAX_SIDE):
        xmin, ymin, xmax, ymax = bbox
        cell = max(xmax - xmin, ymax - ymin, 1.0) / max_side
        cols = max(1, int(math.ceil((xmax - xmin) / cell)))
        rows = max(1, int(math.ceil((ymax - ymin) / cell)))
        return cls(xmin, ymax, cell, rows, cols)

    def like(self):
        return Grid(self.x0, self.y1, self.cell, *self.mask.shape)

    @property
    def shape(self):
        return self.mask.shape

    def window(self, rect):
        """(row0, row1, col0, col1) cells a rectangle covers (clipped to the grid; may be empty)."""
        rows, cols = self.mask.shape
        c0 = max(0, int(math.floor((rect[0] - self.x0) / self.cell)))
        c1 = min(cols, int(math.ceil((rect[2] - self.x0) / self.cell)))
        r0 = max(0, int(math.floor((self.y1 - rect[3]) / self.cell)))
        r1 = min(rows, int(math.ceil((self.y1 - rect[1]) / self.cell)))
        return r0, r1, c0, c1

    def cell_rect(self, r0, r1, c0, c1):
        """The ground the cells [r0:r1, c0:c1] cover (what to render to fill them one pixel per cell)."""
        return (self.x0 + c0 * self.cell, self.y1 - r1 * self.cell, self.x0 + c1 * self.cell, self.y1 - r0 * self.cell)

    def fill_rect(self, rect):
        r0, r1, c0, c1 = self.window(rect)
        if r1 > r0 and c1 > c0:
            self.mask[r0:r1, c0:c1] = True
            self._dil = None

    def paint(self, r0, c0, alpha):
        """Mark cells from a rendered yes/no array whose top-left cell is (r0, c0)."""
        h, w = alpha.shape
        rows, cols = self.mask.shape
        h, w = min(h, rows - r0), min(w, cols - c0)
        if h > 0 and w > 0:
            self.mask[r0:r0 + h, c0:c0 + w] |= alpha[:h, :w]
            self._dil = None

    def __and__(self, other):
        g = self.like()
        g.mask = self.mask & other.mask
        return g

    def __or__(self, other):
        g = self.like()
        g.mask = self.mask | other.mask
        return g

    def any(self):
        return bool(self.mask.any())

    def dilated(self):
        """One cell grown in every direction: a cell that touches anything counts (never wrongly says no)."""
        if self._dil is None:
            import numpy as np
            m = self.mask
            d = m.copy()
            d[1:, :] |= m[:-1, :]
            d[:-1, :] |= m[1:, :]
            e = d.copy()
            e[:, 1:] |= d[:, :-1]
            e[:, :-1] |= d[:, 1:]
            self._dil = np.asarray(e)
        return self._dil

    def hits(self, rect):
        """Could anything be inside this rectangle? Outside the grid: no."""
        r0, r1, c0, c1 = self.window(rect)
        if r1 <= r0 or c1 <= c0:
            return False
        return bool(self.dilated()[r0:r1, c0:c1].any())

    def count_tiles(self, z):
        """About how many zoom-z tiles touch a marked cell."""
        import numpy as np
        t = tile_size(z)
        rows, cols = np.nonzero(self.mask)
        if rows.size == 0:
            return 0
        if t < self.cell:                      # tiles smaller than cells: area-based
            return int(round(rows.size * (self.cell / t) ** 2))
        xs = self.x0 + (cols + 0.5) * self.cell
        ys = self.y1 - (rows + 0.5) * self.cell
        tx = np.floor((xs + ORIGIN) / t).astype(np.int64)
        ty = np.floor((ORIGIN - ys) / t).astype(np.int64)
        return int(np.unique(tx * (2 ** z) + ty).size)

    def counts(self, minz, maxz):
        return {z: self.count_tiles(z) for z in range(minz, maxz + 1)}


# ---------------------------------------------------------------- QGIS renders into grids
def _alpha(img, w, h):
    import numpy as np
    ptr = img.constBits()
    ptr.setsize(img.sizeInBytes() if hasattr(img, "sizeInBytes") else img.byteCount())
    arr = np.frombuffer(ptr, np.uint8).reshape(img.height(), img.bytesPerLine())
    return arr[:h, 3: w * 4: 4] > 0               # ARGB32 is BGRA in memory on little-endian


def render_into(grid, layers, rect, project):
    """Draw `layers` over `rect` at one pixel per grid cell, and mark every cell with anything drawn in it."""
    from qgis.core import QgsCoordinateReferenceSystem, QgsMapRendererCustomPainterJob, QgsMapSettings, QgsRectangle
    from qgis.PyQt.QtCore import QSize
    from qgis.PyQt.QtGui import QColor, QImage, QPainter
    r0, r1, c0, c1 = grid.window(rect)
    if r1 <= r0 or c1 <= c0:
        return
    x0, y0, x1, y1 = grid.cell_rect(r0, r1, c0, c1)
    w, h = c1 - c0, r1 - r0
    ms = QgsMapSettings()
    ms.setLayers(list(layers))
    ms.setDestinationCrs(QgsCoordinateReferenceSystem("EPSG:3857"))
    if project is not None:
        ms.setTransformContext(project.transformContext())
    ms.setBackgroundColor(QColor(0, 0, 0, 0))
    ms.setOutputDpi(96)
    ms.setOutputSize(QSize(w, h))
    ms.setExtent(QgsRectangle(x0, y0, x1, y1))
    img = QImage(w, h, QImage.Format_ARGB32_Premultiplied)
    img.fill(0)
    p = QPainter(img)
    job = QgsMapRendererCustomPainterJob(ms, p)
    job.renderSynchronously()
    p.end()
    grid.paint(r0, c0, _alpha(img, w, h))


def boundary_grid(b3857, max_side=MAX_SIDE):
    """The property itself as a grid (its outline counts, so thin parts aren't lost)."""
    from qgis.core import QgsFeature, QgsFillSymbol, QgsVectorLayer
    bb = b3857.boundingBox()
    bbox = (bb.xMinimum(), bb.yMinimum(), bb.xMaximum(), bb.yMaximum())
    key = ("boundary", b3857.asWkt(1), max_side)
    if key in _cache:
        return _cache[key]
    grid = Grid.over(bbox, max_side)
    vl = QgsVectorLayer("Polygon?crs=EPSG:3857", "boundary", "memory")
    f = QgsFeature()
    f.setGeometry(b3857)
    vl.dataProvider().addFeatures([f])
    vl.updateExtents()
    vl.renderer().setSymbol(QgsFillSymbol.createSimple({
        "color": "0,0,0,255", "outline_color": "0,0,0,255", "outline_width": "1", "outline_width_unit": "Pixel"}))
    render_into(grid, [vl], bbox, None)
    if not grid.any():
        grid.fill_rect(bbox)                   # something odd: don't let it hide everything
    _cache[key] = grid
    return grid


def layer_rect_3857(layer, project):
    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform
    ext = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:3857"),
                                 project).transformBoundingBox(layer.extent())
    return (ext.xMinimum(), ext.yMinimum(), ext.xMaximum(), ext.yMaximum())


def extent_grid(like, layers, project):
    """Cells inside any layer's extent rectangle."""
    g = like.like()
    for lyr in layers:
        g.fill_rect(layer_rect_3857(lyr, project))
    return g


def raster_pixels(layer):
    try:
        return int(layer.width()) * int(layer.height())
    except Exception:  # noqa
        return 0


def has_pyramids(layer):
    """Does a raster have overviews (pyramids)? None if it can't tell (online layers etc.)."""
    try:
        dp = layer.dataProvider()
        if dp is None:
            return None
        if hasattr(dp, "hasPyramids") and dp.hasPyramids():
            return True
        pl = dp.buildPyramidList() if hasattr(dp, "buildPyramidList") else []
        if pl:
            return any(getattr(p, "getExists", lambda: getattr(p, "exists", False))() for p in pl)
        return None
    except Exception:  # noqa
        return None


SLOW_RENDER_PX = 64_000_000     # bigger than this with no pyramids: reading it all just for an estimate takes a while


def _layer_fingerprint(layer, files):
    from qgis.core import QgsMapLayerStyle
    st = QgsMapLayerStyle()
    st.readFromLayer(layer)
    return (layer.id(), layer.source(), tuple(files or ()), hashlib.sha1(st.xmlData().encode()).hexdigest())


def imagery_coverage(like, layers, project, *, render=True, files_of=None):
    """Where the imagery has pixels. render=False (or a huge raster with no pyramids when render="auto") uses each
    image's extent rectangle instead. Returns (grid, how) where how is "rendered" or "extent"."""
    g = like.like()
    how = "rendered"
    for lyr in layers:
        rect = layer_rect_3857(lyr, project)
        slow = has_pyramids(lyr) is False and raster_pixels(lyr) > SLOW_RENDER_PX
        if render is False or (render == "auto" and slow):
            g.fill_rect(rect)
            how = "extent"
            continue
        files = None
        if files_of is not None:
            try:
                f = files_of(lyr)
                import os
                files = [(p, os.path.getsize(p), int(os.path.getmtime(p))) for p in f] if f else None
            except OSError:
                files = None
        key = ("cov", _layer_fingerprint(lyr, files), like.x0, like.y1, like.cell, like.shape)
        part = _cache.get(key)
        if part is None:
            part = like.like()
            render_into(part, [lyr], rect, project)
            _cache[key] = part
        g = g | part
    return g, how


# ---------------------------------------------------------------- how long and how big, learned from earlier builds
DEFAULT_SECONDS = {"imagery": 0.05, "overlay": 0.02}      # per tile drawn
DEFAULT_BYTES = {"imagery": 22000, "overlay": 6000}       # per tile drawn


def learn(old, new, weight=0.5):
    """Blend a new measurement into the stored rate (keeps it steady, follows a faster or slower computer)."""
    if new is None or new <= 0 or not math.isfinite(new):
        return old
    if old is None or old <= 0:
        return new
    return old * (1 - weight) + new * weight


def _settings():
    from qgis.core import QgsSettings
    return QgsSettings()


def rate(kind, what="seconds"):
    default = (DEFAULT_SECONDS if what == "seconds" else DEFAULT_BYTES).get(kind, DEFAULT_SECONDS["overlay"])
    try:
        v = float(_settings().value(f"rcl_web_package/rate_{kind}" + ("" if what == "seconds" else "_bytes"), default))
        return v if v > 0 and math.isfinite(v) else default
    except Exception:  # noqa
        return default


def remember_rate(kind, seconds=None, bytes_=None, tiles=0, min_tiles=200):
    """After a layer is drawn: seconds and bytes for `tiles` tiles drawn. Small layers are too noisy to learn from."""
    if tiles < min_tiles:
        return
    try:
        s = _settings()
        if seconds:
            s.setValue(f"rcl_web_package/rate_{kind}", learn(rate(kind, "seconds"), seconds / tiles))
        if bytes_:
            s.setValue(f"rcl_web_package/rate_{kind}_bytes", learn(rate(kind, "bytes"), bytes_ / tiles))
    except Exception:  # noqa
        pass
