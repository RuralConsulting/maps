"""Upload a package to the RCL portal (Supabase) and manage who can see it.

Works as the signed-in staff member (email, password and two-factor code; see session.py). There is no
secret key on this computer: what each person can do is decided by their staff role in the database
(schema.sql), and customer accounts and passwords are made by the staff-admin function on the server.
"""
import base64
import hashlib
import http.client
import datetime as dt
import json
import mimetypes
import os
import re
import shutil
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import uuid

from .session import SignInError

BUCKET = "farm-maps"
PHOTO_BUCKET = "suggestion-photos"
PLATFORM_BUCKET = "map-packages"
CHUNK = 6 * 1024 * 1024          # Supabase resumable uploads require 6 MB chunks
SMALL = 5 * 1024 * 1024          # files below this go in one request
KEEP_VERSIONS = 2                # current map + the previous one, for going back

mimetypes.add_type("application/vnd.pmtiles", ".pmtiles")
mimetypes.add_type("application/geo+json", ".geojson")


class PortalError(Exception):
    pass


ROLE_NAMES = {"admin": "admin", "publisher": "publisher", "staff": "staff (view and suggestions only)"}


def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:32]


class Portal:
    place = "portal"                              # what messages call it
    platform = False
    bucket = BUCKET

    def __init__(self, session, timeout=120):
        self.session = session
        self.url = session.url
        self.timeout = timeout
        self.role = None                          # admin / publisher / staff, set by check()
        self._people = None
        m = re.match(r"https://([a-z0-9]+)\.supabase\.co", self.url)
        # large uploads go straight to the storage host
        self.storage_url = f"https://{m.group(1)}.storage.supabase.co" if m else self.url

    @property
    def email(self):
        return self.session.email

    @property
    def can_publish(self):
        return self.role in ("admin", "publisher")

    @property
    def is_admin(self):
        return self.role == "admin"

    # ---------------------------------------------------------------- http
    def _token(self):
        try:
            return self.session.token()
        except SignInError as e:
            raise PortalError(str(e)) from None

    def _req(self, method, url, body=None, headers=None, raw=False, _retry=True):
        token = self._token()
        h = {"apikey": self.session.public_key, "Authorization": f"Bearer {token}"}
        h.update(headers or {})
        data = body
        if body is not None and not isinstance(body, (bytes, bytearray)):
            data = json.dumps(body).encode()
            h.setdefault("Content-Type", "application/json")
        req = urllib.request.Request(url, data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                content = r.read()
                if raw:
                    return r.status, dict(r.headers), content
                return json.loads(content) if content else None
        except urllib.error.HTTPError as e:
            detail = e.read().decode(errors="replace")[:400]
            # an access token that ran out (or was replaced) mid-way: renew it once and try again
            expired = e.code == 401 or (e.code in (400, 403) and re.search(r"jwt|token", detail, re.I)
                                        and re.search(r"expired|invalid", detail, re.I))
            if expired and _retry:
                try:
                    self.session.refresh(stale_token=token)
                except SignInError as err:
                    raise PortalError(str(err)) from None
                return self._req(method, url, body, headers, raw, _retry=False)
            if raw:
                return e.code, dict(e.headers), detail.encode()
            refused = self._refused(e.code, detail)
            if refused:
                raise PortalError(refused) from None
            raise PortalError(f"{method} {url.split('?')[0]} failed ({e.code}): {detail}") from None
        except urllib.error.URLError as e:
            raise PortalError(f"Could not reach the {self.place}: {e.reason}") from None

    def _refused(self, code, detail):
        """The plain message for a request the database's security rules turned down, or None if it's something else."""
        if code in (401, 403) and ("row-level security" in detail.lower() or "42501" in detail):
            return "Your staff role doesn't allow this. Ask an admin (portal > Staff)."
        return None

    def _start_upload_refused(self, status, body):
        """Hook: a resumable upload turned down when it starts. The portal keeps its usual message."""

    def rpc(self, name, args=None):
        return self._req("POST", f"{self.url}/rest/v1/rpc/{name}", args or {})

    def admin(self, action, **args):
        """Ask the staff-admin function (it holds the secret key and checks your role)."""
        token = self._token()
        body = json.dumps({"action": action, **args}).encode()
        for attempt in (0, 1):
            req = urllib.request.Request(f"{self.url}/functions/v1/staff-admin", data=body, method="POST", headers={
                "apikey": self.session.public_key, "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    content = r.read()
                    return json.loads(content) if content else {}
            except urllib.error.HTTPError as e:
                detail = e.read().decode(errors="replace")[:400]
                if e.code == 401 and attempt == 0:
                    try:
                        token = self.session.refresh(stale_token=token)
                    except SignInError as err:
                        raise PortalError(str(err)) from None
                    continue
                try:
                    msg = json.loads(detail).get("error") or detail
                except ValueError:
                    msg = detail
                if e.code == 404 and not msg.strip().startswith("No account"):
                    msg = ("The portal's staff-admin function isn't set up yet. Deploy it in Supabase "
                           "(see the setup steps).")
                raise PortalError(msg) from None
            except urllib.error.URLError as e:
                raise PortalError(f"Could not reach the portal: {e.reason}") from None

    def rest(self, method, path, body=None, prefer=None):
        h = {"Prefer": prefer} if prefer else {}
        return self._req(method, f"{self.url}/rest/v1/{path}", body, h)

    # ---------------------------------------------------------------- checks
    def check(self):
        """Confirm the sign-in works, find this person's staff role and that the database is up to date."""
        try:
            role = self.rpc("staff_role")
        except PortalError as e:
            if "staff_role" in str(e) and "404" in str(e):
                raise PortalError("The portal's database needs updating: run the latest schema.sql in Supabase.") from None
            raise
        if not role:
            if self.session.aal != "aal2":
                raise PortalError("Sign in with your two-factor code to use the QGIS tool.")
            raise PortalError(f"{self.email} isn't RCL staff. Ask an admin to add you in the portal (Staff page).")
        self.role = role
        self.people(refresh=True)
        return role

    # ---------------------------------------------------------------- farms
    def list_farms(self):
        return self.rest("GET", "farms?select=id,name,slug&order=name")

    def ensure_farm(self, name, slug):
        rows = self.rest("POST", "farms?on_conflict=slug", [{"name": name, "slug": slug}],
                         prefer="resolution=merge-duplicates,return=representation")
        return rows[0]

    # ---------------------------------------------------------------- files
    def upload_file(self, local, object_name, progress=None):
        size = os.path.getsize(local)
        ctype = mimetypes.guess_type(local)[0] or "application/octet-stream"
        if size <= SMALL:
            with open(local, "rb") as fh:
                data = fh.read()
            self._req("POST", f"{self.url}/storage/v1/object/{self.bucket}/{urllib.parse.quote(object_name)}", data,
                      {"Content-Type": ctype, "x-upsert": "true", "Cache-Control": "max-age=3600"})
            if progress:
                progress(size)
            return
        meta = {"bucketName": self.bucket, "objectName": object_name, "contentType": ctype, "cacheControl": "3600"}
        md = ",".join(f"{k} {base64.b64encode(v.encode()).decode()}" for k, v in meta.items())
        st, hdrs, body = self._req("POST", f"{self.storage_url}/storage/v1/upload/resumable", b"",
                                   {"Tus-Resumable": "1.0.0", "Upload-Length": str(size), "Upload-Metadata": md,
                                    "x-upsert": "true"}, raw=True)
        if st == 413:
            raise PortalError(
                f"{os.path.basename(local)} is {size / 1e6:.0f} MB, which is over Supabase's file size limit.\n\n"
                "The free plan allows 50 MB per file. On the Pro plan, raise it in Supabase: "
                "Storage > Settings > Global file size limit (e.g. 20 GB). Or lower 'Imagery detail' and rebuild.")
        self._start_upload_refused(st, body)
        if st not in (200, 201):
            raise PortalError(f"Could not start upload of {object_name} ({st}): {body[:300]!r}")
        loc = hdrs.get("Location") or hdrs.get("location")
        if loc.startswith("/"):
            loc = self.storage_url + loc
        offset = 0
        with open(local, "rb") as fh:
            while offset < size:
                chunk = fh.read(CHUNK)
                for attempt in range(4):
                    st, hdrs, body = self._req("PATCH", loc, chunk,
                                               {"Tus-Resumable": "1.0.0", "Upload-Offset": str(offset),
                                                "Content-Type": "application/offset+octet-stream"}, raw=True)
                    if st in (200, 204):
                        break
                    if attempt == 3:
                        raise PortalError(f"Upload of {object_name} stopped at {offset} bytes ({st}): {body[:300]!r}")
                offset += len(chunk)
                if progress:
                    progress(len(chunk))

    # ---------------------------------------------------------------- maps
    def list_maps(self, farm_id):
        return self.rest("GET", f"maps?select=*&farm_id=eq.{farm_id}&order=created_at") or []

    def ensure_map(self, farm_id, slug, title, description=None, kind=None):
        row = {"farm_id": farm_id, "slug": slug, "title": title, "description": description or None,
               "kind": kind or None, "archived_at": None}           # publishing brings an offline map back
        try:
            rows = self.rest("POST", "maps?on_conflict=farm_id,slug", [row],
                             prefer="resolution=merge-duplicates,return=representation")
        except PortalError as e:
            if "archived_at" not in str(e):
                raise
            row.pop("archived_at")                                   # database not updated yet
            rows = self.rest("POST", "maps?on_conflict=farm_id,slug", [row],
                             prefer="resolution=merge-duplicates,return=representation")
        return rows[0]

    def update_map(self, map_id, **fields):
        self.rest("PATCH", f"maps?id=eq.{map_id}", {k: (v or None) for k, v in fields.items()})

    def publish(self, package_dir, farm_name, farm_slug, version, progress=None,
                map_slug=None, map_title=None, description=None, kind=None):
        """Upload a built package and make it the current version of one of the property's maps.

        map_slug picks the map (created if new). Files are stored by content (farm/blobs/<hash>), so
        anything already on the portal, such as unchanged drone imagery, isn't uploaded or stored twice."""
        with open(os.path.join(package_dir, "manifest.json"), encoding="utf-8") as fh:
            manifest = json.load(fh)
        farm = self.ensure_farm(farm_name, farm_slug)
        map_title = map_title or manifest.get("map_title") or manifest.get("title") or farm_name
        mp = self.ensure_map(farm["id"], map_slug or "map", map_title,
                             description if description is not None else manifest.get("description"),
                             kind if kind is not None else manifest.get("kind"))
        blob_dir = f"{farm['id']}/blobs"
        files = manifest["files"]
        sizes = {rel: os.path.getsize(os.path.join(package_dir, rel)) for rel in files}
        total = sum(sizes.values()) or 1
        sent = [0]

        def tick(n):
            sent[0] += n
            if progress:
                progress(sent[0], total)

        existing = set(self.list_objects(blob_dir))
        file_map, skipped = {}, 0
        for rel in files:
            local = os.path.join(package_dir, rel)
            name = f"{blob_dir}/{file_hash(local)}{os.path.splitext(rel)[1].lower()}"
            file_map[rel] = name
            if name in existing:
                skipped += sizes[rel]
                tick(sizes[rel])
            else:
                self.upload_file(local, name, tick)
                existing.add(name)
        manifest["file_map"] = file_map
        manifest["property"] = farm_name
        manifest["map_title"] = mp["title"]
        self.rest("PATCH", f"packages?map_id=eq.{mp['id']}&is_current=is.true", {"is_current": False})
        self.rest("POST", "packages", [{
            "farm_id": farm["id"], "map_id": mp["id"], "version": version, "title": mp["title"],
            "survey_date": manifest.get("survey_date") or None, "manifest": manifest,
            "storage_prefix": blob_dir, "is_current": True}], prefer="return=minimal")
        try:
            self.prune_versions(farm["id"], keep=KEEP_VERSIONS)
        except PortalError:
            pass            # tidying up is best-effort; the new map is already live
        farm["map"] = mp
        farm["reused_bytes"], farm["uploaded_bytes"] = skipped, total - skipped
        return farm

    # ---------------------------------------------------------------- housekeeping
    def list_objects(self, prefix, bucket=None):
        """Every file path under prefix (a folder, no trailing slash), recursively."""
        return list(self.object_sizes(prefix, bucket))

    def object_sizes(self, prefix, bucket=None):
        """{path: bytes} for every file under prefix, recursively."""
        bucket = bucket or self.bucket
        out, offset = {}, 0
        while True:
            items = self._req("POST", f"{self.url}/storage/v1/object/list/{bucket}",
                              {"prefix": prefix, "limit": 1000, "offset": offset,
                               "sortBy": {"column": "name", "order": "asc"}}) or []
            for it in items:
                path = f"{prefix}/{it['name']}"
                if it.get("id") is None:          # a folder
                    out.update(self.object_sizes(path, bucket))
                else:
                    out[path] = int((it.get("metadata") or {}).get("size") or 0)
            if len(items) < 1000:
                return out
            offset += 1000

    def delete_objects(self, paths, bucket=None):
        bucket = bucket or self.bucket
        for i in range(0, len(paths), 1000):
            self._req("DELETE", f"{self.url}/storage/v1/object/{bucket}", {"prefixes": paths[i:i + 1000]})

    def map_info(self, map_id):
        return self.rest("GET", f"packages?select=version,title,survey_date,published_at,is_current"
                                f"&map_id=eq.{map_id}&order=published_at.desc") or []

    @staticmethod
    def _package_paths(row):
        m = row.get("manifest") or {}
        fm = m.get("file_map")
        if fm:
            return set(fm.values())
        return {f"{row['storage_prefix']}/{rel}" for rel in m.get("files", [])}

    def prune_versions(self, farm_id, keep=2):
        """For each of the property's maps keep the current version and the newest earlier one(s);
        delete older versions and any files nothing refers to (e.g. half-finished uploads).
        Returns the number of files deleted."""
        pk = self.rest("GET", f"packages?select=id,map_id,storage_prefix,is_current,manifest,published_at"
                              f"&farm_id=eq.{farm_id}&order=published_at.desc") or []
        keep_rows = []
        for mid in {r.get("map_id") for r in pk}:
            rows = [r for r in pk if r.get("map_id") == mid]
            keep_rows += ([r for r in rows if r["is_current"]] + [r for r in rows if not r["is_current"]])[:max(keep, 1)]
        keep_ids = {r["id"] for r in keep_rows}
        needed = set().union(*(self._package_paths(r) for r in keep_rows)) if keep_rows else set()
        files = [f for f in self.list_objects(str(farm_id)) if f not in needed]
        self.delete_objects(files)
        for r in pk:
            if r["id"] not in keep_ids:
                self.rest("DELETE", f"packages?id=eq.{r['id']}")
        return len(files)

    def restore_previous(self, map_id):
        """Make the previous published version of a map current again."""
        pk = self.map_info(map_id)
        prev = next((r for r in pk if not r["is_current"]), None)
        if not prev:
            raise PortalError("There's no earlier version of this map to go back to.")
        self.rest("PATCH", f"packages?map_id=eq.{map_id}&is_current=is.true", {"is_current": False})
        self.rest("PATCH", f"packages?map_id=eq.{map_id}&version=eq.{urllib.parse.quote(prev['version'])}",
                  {"is_current": True})
        return prev

    def take_offline(self, farm_id, map_id):
        """Take a map off the portal to save space: its versions and files go (files other maps still use
        stay), the map itself is kept as "offline" so it shows in the register, and publishing it again
        from the local copy brings it back. Returns bytes freed."""
        before = sum(self.object_sizes(str(farm_id)).values())
        self.rest("DELETE", f"packages?map_id=eq.{map_id}")
        self.prune_versions(farm_id, keep=KEEP_VERSIONS)
        try:
            self.rest("PATCH", f"maps?id=eq.{map_id}",
                      {"archived_at": dt.datetime.now(dt.timezone.utc).isoformat()})
        except PortalError:
            pass                                                     # database not updated yet
        return before - sum(self.object_sizes(str(farm_id)).values())

    def storage_report(self):
        """Every map with its online size, when customers last opened it and when it was published.
        Returns {"maps": [...], "farms": {farm_id: bytes}, "photos": bytes}."""
        staff = {r["user_id"] for r in self.rest("GET", "staff?select=user_id") or []}
        farms = {f["id"]: f for f in self.list_farms()}
        maps = self.rest("GET", "maps?select=*&order=created_at") or []
        last = {}
        try:
            for v in self.rest("GET", "map_views?select=map_id,user_id,viewed_at&order=viewed_at.desc&limit=100000") or []:
                if v.get("user_id") not in staff and v.get("map_id") and v["map_id"] not in last:
                    last[v["map_id"]] = v["viewed_at"]
        except PortalError:
            pass
        out, farm_bytes, photos = [], {}, 0
        for fid, f in farms.items():
            sizes = self.object_sizes(str(fid))
            farm_bytes[fid] = sum(sizes.values())
            try:
                photos += sum(self.object_sizes(str(fid), PHOTO_BUCKET).values())
            except PortalError:
                pass
            pk = self.rest("GET", f"packages?select=map_id,storage_prefix,manifest,is_current,published_at"
                                  f"&farm_id=eq.{fid}") or []
            for m in [m for m in maps if m["farm_id"] == fid]:
                rows = [r for r in pk if r.get("map_id") == m["id"]]
                paths = set().union(*(self._package_paths(r) for r in rows)) if rows else set()
                cur = next((r for r in rows if r["is_current"]), None)
                out.append({"farm": f, "map": m, "online_bytes": sum(sizes.get(p, 0) for p in paths),
                            "versions": len(rows), "published_at": cur and cur.get("published_at"),
                            "last_visit": last.get(m["id"]), "archived_at": m.get("archived_at")})
        return {"maps": out, "farms": farm_bytes, "photos": photos}

    def delete_map(self, farm_id, map_id):
        """Remove one map of a property (its versions and files no other map uses)."""
        self.rest("DELETE", f"maps?id=eq.{map_id}")          # its packages go with it
        return self.prune_versions(farm_id, keep=KEEP_VERSIONS)

    def delete_farm(self, farm_id):
        """Remove a farm completely: its map files, versions and everyone's access to it.
        People's accounts stay (they may have other farms)."""
        files = self.list_objects(str(farm_id))
        self.delete_objects(files)
        try:
            self.delete_objects(self.list_objects(str(farm_id), PHOTO_BUCKET), PHOTO_BUCKET)
        except PortalError:
            pass
        self.rest("DELETE", f"farms?id=eq.{farm_id}")       # packages, access and suggestions go with it
        return len(files)

    # ---------------------------------------------------------------- people
    def people(self, refresh=False):
        """Everyone with access to a property, and staff: [{id, email, last_sign_in_at, created_at, staff_role}]."""
        if refresh or self._people is None:
            self._people = self.rpc("staff_people") or []
        return self._people

    def _find_user(self, email):
        email = email.strip().lower()
        return next((u for u in self.people() if (u.get("email") or "").lower() == email), None)

    def reset_password(self, email):
        """Give an existing account a new random password (made on the server) and return it."""
        return self.admin("reset_password", email=email.strip().lower())["password"]

    def share(self, farm_id, emails):
        """Give these people access. Returns [(email, new_password_or_None)]."""
        emails = [e.strip().lower() for e in emails if e.strip()]
        if not emails:
            return []
        people = self.admin("ensure_customers", emails=emails)["people"]
        self.rest("POST", "farm_members?on_conflict=farm_id,user_id",
                  [{"farm_id": farm_id, "user_id": p["id"]} for p in people],
                  prefer="resolution=ignore-duplicates,return=minimal")
        self._people = None
        return [(p["email"], p.get("password")) for p in people]

    def members(self, farm_id, detail=False):
        """Emails with access to a farm (sorted). detail=True gives [{id, email, last_sign_in_at}]."""
        rows = self.rest("GET", f"farm_members?select=user_id&farm_id=eq.{farm_id}")
        ids = {r["user_id"] for r in rows}
        people = self.people() if ids else []
        if ids - {u["id"] for u in people}:                # someone new since the list was fetched
            people = self.people(refresh=True)
        out = [{"id": u["id"], "email": u["email"], "last_sign_in_at": u.get("last_sign_in_at")}
               for u in people if u["id"] in ids]
        out.sort(key=lambda u: u["email"])
        return out if detail else [u["email"] for u in out]

    # ---------------------------------------------------------------- visits and staff
    def visits(self, farm_id):
        """Map visits per person: {user_id: {"count", "last", "phone", "computer"}} (RCL staff not counted)."""
        staff = {r["user_id"] for r in self.rest("GET", "staff?select=user_id") or []}
        rows = self.rest("GET", f"map_views?select=user_id,viewed_at,device&farm_id=eq.{farm_id}"
                                f"&order=viewed_at.desc&limit=10000") or []
        out = {}
        for r in rows:
            if r["user_id"] in staff or not r["user_id"]:
                continue
            v = out.setdefault(r["user_id"], {"count": 0, "last": r["viewed_at"], "phone": 0, "computer": 0})
            v["count"] += 1
            if r.get("device") in ("phone", "computer"):
                v[r["device"]] += 1
        return out

    def _all_users(self):
        """Customers and staff (the register uses this for emails and sign-in dates)."""
        return self.people(refresh=True)

    def staff(self):
        return sorted(u["email"] for u in self.people() if u.get("staff_role"))

    # ---------------------------------------------------------------- suggestions
    def suggestions(self, farm_id=None, status=None):
        q = "suggestions?select=*&order=created_at.desc"
        if farm_id:
            q += f"&farm_id=eq.{farm_id}"
        if status:
            q += f"&status=eq.{status}"
        return self.rest("GET", q) or []

    def suggestion_events(self, sid):
        """History of a suggestion: created, status changes, replies, notes, emails (oldest first)."""
        return self.rest("GET", f"suggestion_events?select=*&suggestion_id=eq.{sid}&order=at.asc,id.asc") or []

    def add_note(self, sid, body):
        """An internal note on a suggestion (only RCL staff see these)."""
        self.rest("POST", "suggestion_events", [{"suggestion_id": sid, "kind": "note", "body": body.strip()}],
                  prefer="return=minimal")         # who and when are filled in from the sign-in

    def delete_suggestion(self, s):
        """Delete a suggestion, its photos and its history."""
        if s.get("photos"):
            self.delete_objects(list(s["photos"]), bucket=PHOTO_BUCKET)
        self.rest("DELETE", f"suggestions?id=eq.{s['id']}")

    def all_maps(self):
        return self.rest("GET", "maps?select=id,farm_id,title,slug") or []

    def new_suggestion_counts(self, timeout=6):
        """{farm_id: n} of suggestions not dealt with yet (quick check when the panel opens)."""
        old, self.timeout = self.timeout, timeout
        try:
            rows = self.rest("GET", "suggestions?select=farm_id&status=eq.new")
        finally:
            self.timeout = old
        out = {}
        for r in rows or []:
            out[r["farm_id"]] = out.get(r["farm_id"], 0) + 1
        return out

    def update_suggestion(self, sid, status=None, reply=None):
        body = {}
        if status is not None:
            body["status"] = status
        if reply is not None:
            body["reply"] = reply.strip() or None
        if body:
            self.rest("PATCH", f"suggestions?id=eq.{sid}", body)

    def download_photo(self, path, dest):
        st, _, data = self._req("GET", f"{self.url}/storage/v1/object/{PHOTO_BUCKET}/{urllib.parse.quote(path)}",
                                raw=True)
        if st != 200:
            return False
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as fh:
            fh.write(data)
        return True

    def unshare(self, farm_id, email):
        u = self._find_user(email) or self._find_user_fresh(email)
        if u:
            self.rest("DELETE", f"farm_members?farm_id=eq.{farm_id}&user_id=eq.{u['id']}")

    def _find_user_fresh(self, email):
        self.people(refresh=True)
        return self._find_user(email)


# ------------------------------------------------------------------ publishing to the platform
REFUSED = ("The platform refused this. Publishing needs an RCL staff sign-in with your two-factor code: sign out, "
           "sign in again with the code, and try again. If it still happens, check you're staff on the platform.")
TWO_FACTOR_NEEDED = "Sign in with your two-factor code to publish to the platform."
CONTACT_LOST = ("Contact with the platform was lost part-way. Check Published maps to see whether the change "
                "went through before trying again.")
PACKAGE_COLUMNS = ("id", "map_id", "version", "manifest", "storage_prefix", "survey_date", "is_current")
SHARED_KEY = re.compile(r"^[a-z0-9][a-z0-9_-]{0,79}$")


def _not_on_platform(self, *_, **__):
    raise PortalError("That screen is part of the map portal. It isn't used when publishing to the platform.")


def stamp_farm_id(package_dir, manifest, farm_id, out_dir):
    """Copies of the package's clickable-feature files with the farm's id on every feature: {file in package: copy}.
    The package on this computer isn't changed, so it can still go to another farm or to the portal. The viewer lists
    only the fields named in the manifest, so customers don't see the id."""
    copies = {}
    for layer in manifest.get("layers") or []:
        rel = layer.get("features")
        if not rel or rel in copies:
            continue
        with open(os.path.join(package_dir, rel), encoding="utf-8") as fh:
            data = json.load(fh)
        for feature in data.get("features") or []:
            feature["properties"] = dict(feature.get("properties") or {}, farm_id=farm_id)
        copies[rel] = os.path.join(out_dir, f"{len(copies)}{os.path.splitext(rel)[1]}")
        with open(copies[rel], "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, separators=(",", ":"))
    return copies


def _name_key(o):
    return (o["name"].casefold(), o["id"])


def _ancestors(owner, by_id):
    """The visible groups above owner, top first. Stops at a parent this person can't see (or a loop)."""
    out, seen, cur = [], {owner["id"]}, owner
    while cur.get("parent_id") in by_id and cur["parent_id"] not in seen:
        cur = by_id[cur["parent_id"]]
        seen.add(cur["id"])
        out.insert(0, cur)
    return out


def owners_nested(owners):
    """True when the groups carry their parent (the platform has sub-groups); False lists everything flat."""
    return all("parent_id" in o for o in owners if o["kind"] == "group")


def destination(owner, owners):
    """Where a map goes, in full: "Parent › Sub-group (group)" or "Farm (farm)"."""
    if owner is None:
        return ""
    by_id = {o["id"]: o for o in owners if o["kind"] == "group"}
    chain = [a["name"] for a in _ancestors(owner, by_id)] if owner["kind"] == "group" else []
    return " › ".join(chain + [owner["name"]]) + f" ({owner['kind']})"


def owner_rows(owners, query=""):
    """The rows of the farm-or-group picker, in order: [{"row": "heading"|"owner"|"context", "text", "owner", "depth"}].

    A "Groups" section (each top-level group A–Z with its sub-groups indented under it, A–Z), then a "Farms" section A–Z.
    A sub-group whose parent this person can't see is a top-level group. query filters on the name, ignoring case; a
    matching sub-group keeps the groups above it as "context" rows (shown, not choosable) so you can see where it sits.
    Without parents (owners_nested() False) it is the flat A–Z list of labels, filtered the same way."""
    q = (query or "").strip().casefold()

    def hit(o):
        return not q or q in o["name"].casefold()

    if not owners_nested(owners):
        return [{"row": "owner", "text": o["label"], "owner": o, "depth": 0}
                for o in sorted(owners, key=lambda o: (o["label"].casefold(), o["id"])) if hit(o)]
    groups = sorted((o for o in owners if o["kind"] == "group"), key=_name_key)
    farms = sorted((o for o in owners if o["kind"] == "farm"), key=_name_key)
    by_id = {g["id"]: g for g in groups}
    children = {}
    for g in groups:
        if g.get("parent_id") in by_id and g["parent_id"] != g["id"]:
            children.setdefault(g["parent_id"], []).append(g)
    placed, rows = set(), []

    def walk(g, depth):
        """The rows for g and the groups under it; nothing when neither g nor anything under it matches."""
        if g["id"] in placed:
            return []
        placed.add(g["id"])
        below = [r for c in children.get(g["id"], []) for r in walk(c, depth + 1)]
        if not hit(g) and not below:
            return []
        return [{"row": "owner" if hit(g) else "context", "text": "    " * depth + g["name"], "owner": g,
                 "depth": depth}] + below

    tops = [g for g in groups if g.get("parent_id") not in by_id or g["parent_id"] == g["id"]]
    group_rows = [r for g in tops for r in walk(g, 0)]
    group_rows += [r for g in groups if g["id"] not in placed for r in walk(g, 0)]   # only a parent loop gets here
    if group_rows:
        rows += [{"row": "heading", "text": "Groups", "owner": None, "depth": 0}] + group_rows
    farm_rows = [{"row": "owner", "text": f["name"], "owner": f, "depth": 0} for f in farms if hit(f)]
    if farm_rows:
        rows += [{"row": "heading", "text": "Farms", "owner": None, "depth": 0}] + farm_rows
    return rows


class PlatformPortal(Portal):
    """The same publishing against the farm platform's published_maps and map_packages tables and map-packages bucket.

    An owner is one of the rows list_owners() returns: an existing farm or catchment group, never created here.
    What the portal's other methods do (people, passwords, suggestions, visits) isn't used on the platform: membership
    of the farm or group decides who sees a map."""
    place = "platform"
    platform = True
    bucket = PLATFORM_BUCKET

    ensure_farm = list_farms = all_maps = update_map = delete_map = delete_farm = storage_report = _not_on_platform
    admin = people = reset_password = share = unshare = members = visits = staff = _not_on_platform
    suggestions = suggestion_events = add_note = delete_suggestion = update_suggestion = _not_on_platform
    new_suggestion_counts = download_photo = _not_on_platform

    @property
    def can_publish(self):
        return self.role is not None and self.session.aal == "aal2"

    @property
    def is_admin(self):
        return False

    def _req(self, *args, **kwargs):
        try:
            return super()._req(*args, **kwargs)
        except (OSError, http.client.HTTPException):         # a dropped connection or timeout while reading the answer
            raise PortalError(CONTACT_LOST) from None

    def _refused(self, code, detail):
        if code in (400, 401, 403) and re.search(r"row-level security|42501|unauthorized|permission denied|aal2|two.factor",
                                                 detail, re.I):
            return REFUSED
        return None

    def _start_upload_refused(self, status, body):
        if status not in (200, 201, 413) and self._refused(status, body.decode(errors="replace")):
            raise PortalError(REFUSED)

    def check(self):
        """Confirm the sign-in is two-factor and belongs to RCL staff on the platform."""
        if self.session.aal != "aal2":
            raise PortalError(TWO_FACTOR_NEEDED)
        rows = self.rest("GET", f"profiles?select=is_staff&user_id=eq.{self.session.user_id}") or []
        if not (rows and rows[0].get("is_staff")):
            raise PortalError(f"{self.email} isn't RCL staff on the platform, so it can't publish there.")
        self.role = "platform staff"
        return self.role

    def _need_publisher(self):
        if self.session.aal != "aal2":
            raise PortalError(TWO_FACTOR_NEEDED)
        if not self.can_publish:
            raise PortalError(REFUSED)

    def _all(self, path):
        """Every row of a read, a page at a time. Stops on an empty page, so a server cap can't shorten the list."""
        out = []
        while True:
            rows = self.rest("GET", f"{path}&limit=1000&offset={len(out)}") or []
            if not rows:
                return out
            out += rows

    # ---------------------------------------------------------------- owners
    def list_owners(self):
        """The farms and catchment groups this person can see, for picking who a map belongs to. A sub-group carries its
        parent group's id ("parent_id"), and its name ("parent_name") when the parent is one this person can see too.
        On a platform from before sub-groups (no organisations.parent_org_id) the groups carry neither key, and
        owner_rows() then lists everything flat."""
        owners = [{"kind": "farm", "id": f["id"], "name": f["name"], "label": f"{f['name']} (farm)",
                   "folder": f["id"]} for f in self._all("farms?select=id,name&order=name,id")]
        try:
            groups = self._all("organisations?select=id,name,parent_org_id&kind=eq.catchment_group&order=name,id")
            nested = True
        except PortalError as e:
            if "parent_org_id" not in str(e):
                raise
            groups = self._all("organisations?select=id,name&kind=eq.catchment_group&order=name,id")
            nested = False
        names = {g["id"]: g["name"] for g in groups}
        for g in groups:
            o = {"kind": "group", "id": g["id"], "name": g["name"], "label": f"{g['name']} (group)", "folder": f"org/{g['id']}"}
            if nested:
                o.update(parent_id=g.get("parent_org_id"), parent_name=names.get(g.get("parent_org_id")))
            owners.append(o)
        return sorted(owners, key=lambda o: o["label"].lower())

    @staticmethod
    def sub_groups(owners, parent):
        """The groups among owners whose parent group is parent: the ones that can share a layer up to it."""
        return [o for o in owners if o["kind"] == "group" and parent and o.get("parent_id") == parent["id"]]

    def shared_up_layers(self, sub_group):
        """A sub-group's shared layers marked shared with its parent group: [{"org_id", "key", "title"}], by key."""
        return self._all(f"group_shared_layers?select=org_id,key,title&org_id=eq.{sub_group['id']}"
                         f"&shared_with_parent=is.true&order=key")

    @staticmethod
    def _owner_column(owner):
        return "farm_id" if owner["kind"] == "farm" else "org_id"

    @staticmethod
    def _blob_dir(owner):
        return f"{owner['folder']}/blobs"

    # ---------------------------------------------------------------- maps
    def list_maps(self, owner):
        return self._all(f"published_maps?select=*&{self._owner_column(owner)}=eq.{owner['id']}&order=created_at,id")

    def ensure_map(self, owner, slug, title, description=None, kind=None):
        column = self._owner_column(owner)
        rows = self.rest("POST", f"published_maps?on_conflict={column},slug",
                         [{column: owner["id"], "slug": slug, "title": title, "description": description or None,
                           "kind": kind or None, "archived_at": None}],           # publishing brings an offline map back
                         prefer="resolution=merge-duplicates,return=representation")
        return rows[0]

    def map_info(self, map_id):
        return self._all(f"map_packages?select=id,version,survey_date,published_at,is_current"
                         f"&map_id=eq.{map_id}&order=published_at.desc,id")

    def _switch_to(self, map_id, target):
        """Make target (a complete row, new or existing) the map's one current version, in a single request, so the
        database does it as one transaction: either it all happens or nothing changes. The rows being switched off
        come first because rows are applied in order and only one version of a map can be current at any moment.
        published_at isn't sent, so existing versions keep theirs and a new one gets the time it's added."""
        columns = ",".join(PACKAGE_COLUMNS)
        current = self._all(f"map_packages?select={columns}&map_id=eq.{map_id}&is_current=is.true&order=id")
        rows = [{**{k: r[k] for k in PACKAGE_COLUMNS}, "is_current": False} for r in current if r["id"] != target["id"]]
        rows.append({**{k: target[k] for k in PACKAGE_COLUMNS}, "is_current": True})
        saved = self.rest("POST", "map_packages?on_conflict=id", rows,
                          prefer="resolution=merge-duplicates,return=representation") or []
        if not any(r.get("id") == target["id"] and r.get("is_current") is True for r in saved):
            raise PortalError(REFUSED)

    def publish(self, package_dir, owner, version, progress=None,
                map_slug=None, map_title=None, description=None, kind=None):
        """Upload a built package and make it the current version of one of the owner's maps (made if new).

        Files are stored by content (<owner's folder>/blobs/<hash>). The files go up first, then the new version is added
        and made current in one step, so a publish that fails part-way leaves the map showing what it showed before."""
        self._need_publisher()
        with open(os.path.join(package_dir, "manifest.json"), encoding="utf-8") as fh:
            manifest = json.load(fh)
        map_title = map_title or manifest.get("map_title") or manifest.get("title") or owner["name"]
        description = description if description is not None else manifest.get("description")
        kind = kind if kind is not None else manifest.get("kind")
        blob_dir = self._blob_dir(owner)
        stamp_dir = tempfile.mkdtemp(prefix="rcl-platform-")
        try:
            local = {rel: os.path.join(package_dir, rel) for rel in manifest["files"]}
            if owner["kind"] == "farm":
                local.update(stamp_farm_id(package_dir, manifest, owner["id"], stamp_dir))
            sizes = {rel: os.path.getsize(path) for rel, path in local.items()}
            total = sum(sizes.values()) or 1
            sent = [0]

            def tick(n):
                sent[0] += n
                if progress:
                    progress(sent[0], total)

            existing = set(self.list_objects(blob_dir))
            file_map, skipped = {}, 0
            for rel, path in local.items():
                name = f"{blob_dir}/{file_hash(path)}{os.path.splitext(rel)[1].lower()}"
                file_map[rel] = name
                if name in existing:
                    skipped += sizes[rel]
                    tick(sizes[rel])
                else:
                    self.upload_file(path, name, tick)
                    existing.add(name)
        finally:
            shutil.rmtree(stamp_dir, ignore_errors=True)
        mp = self.ensure_map(owner, map_slug or "map", map_title, description, kind)
        manifest["file_map"] = file_map
        manifest["property"] = owner["name"]
        manifest["map_title"] = mp["title"]
        self._switch_to(mp["id"], {
            "id": str(uuid.uuid4()), "map_id": mp["id"], "version": version, "manifest": manifest,
            "storage_prefix": blob_dir, "survey_date": manifest.get("survey_date") or None, "is_current": True})
        try:
            self.prune_versions(owner, keep=KEEP_VERSIONS)
        except PortalError:
            pass            # tidying up is best-effort; the new map is already live
        return dict(owner, map=mp, reused_bytes=skipped, uploaded_bytes=total - skipped,
                    missing_shared=self.missing_shared(manifest, owner))

    # ---------------------------------------------------------------- layers published once and referred to by key
    @staticmethod
    def _shared_folder(target, key):
        return f"core/{key}" if target is None else f"org/{target['id']}/shared/{key}"

    def publish_shared_layer(self, built, target=None, as_at=None, progress=None, share_with_parent=False):
        """Upload a layer built by package.build_shared_layer and record it, once: to core/<key>/… and core_layers (target None),
        or a catchment group's org/<id>/shared/<key>/… and group_shared_layers. Publishing the same key again replaces it in
        place, so storage only ever holds one copy. Returns {"folder", "tiles_path"}.

        share_with_parent (a sub-group's layer only): its parent group's members may read it too, from this one copy. Off by
        default, and sent with every group layer, so publishing a key again without it stops sharing it up."""
        self._need_publisher()
        key = built["key"]
        if not SHARED_KEY.match(key):
            raise PortalError("A shared layer's key can only use lower-case letters, digits, dashes and underscores.")
        if target is not None and target.get("kind") != "group":
            raise PortalError("A layer can only be shared with a catchment group.")
        if share_with_parent and (target is None or not target.get("parent_id")):
            raise PortalError("Only a sub-group's layer can be shared with its parent group.")
        folder = self._shared_folder(target, key)
        sizes = {rel: os.path.getsize(os.path.join(built["dir"], rel)) for rel in built["files"]}
        total = sum(sizes.values()) or 1
        sent = [0]

        def tick(n):
            sent[0] += n
            if progress:
                progress(sent[0], total)

        for rel in built["files"]:
            self.upload_file(os.path.join(built["dir"], rel), f"{folder}/{rel}", tick)
        tiles_path = f"{folder}/{built['tiles']}"
        row = {"key": key, "title": built["title"], "style": built["style"], "tiles_path": tiles_path, "as_at": as_at or None}
        if target is None:
            table, conflict = "core_layers", "key"
        else:
            table, conflict = "group_shared_layers", "org_id,key"
            row["org_id"] = target["id"]
            row["shared_with_parent"] = bool(share_with_parent)
        saved = self.rest("POST", f"{table}?on_conflict={conflict}", [row], prefer="resolution=merge-duplicates,return=representation") or []
        if not saved:
            raise PortalError(REFUSED)
        try:                                   # a piece or legend from an earlier publish of this key that this one doesn't use
            stale = [f for f in self.list_objects(folder) if f[len(folder) + 1:] not in sizes]
            if stale:
                self.delete_objects(stale)
        except PortalError:
            pass                               # tidying up is best-effort; the layer is already live
        return {"folder": folder, "tiles_path": tiles_path}

    def missing_shared(self, manifest, owner=None):
        """The titles of the shared layers a manifest refers to that aren't published (the map still opens without them).
        In a group's map, another group's layer counts only when it is a sub-group of this one and shared with it."""
        missing = []
        for ref in manifest.get("shared_layers") or []:
            if ref.get("tier") == "group" and owner and owner.get("kind") == "group" and ref.get("org_id") != owner["id"]:
                rows = self.rest("GET", f"organisations?select=id&id=eq.{ref.get('org_id')}&parent_org_id=eq.{owner['id']}") and                     self.rest("GET", f"group_shared_layers?select=key&org_id=eq.{ref.get('org_id')}&key=eq.{ref.get('key')}"
                                     f"&shared_with_parent=is.true")
            elif ref.get("tier") == "group":
                rows = self.rest("GET", f"group_shared_layers?select=key&org_id=eq.{ref.get('org_id')}&key=eq.{ref.get('key')}")
            else:
                rows = self.rest("GET", f"core_layers?select=key&key=eq.{ref.get('key')}")
            if not rows:
                missing.append(ref.get("title") or ref.get("key"))
        return missing

    def restore_previous(self, map_id):
        """Make the previous published version of a map current again."""
        self._need_publisher()
        prev = next((r for r in self.map_info(map_id) if not r["is_current"]), None)
        if not prev:
            raise PortalError("There's no earlier version of this map to go back to.")
        rows = self.rest("GET", f"map_packages?select={','.join(PACKAGE_COLUMNS)}&id=eq.{prev['id']}") or []
        if not rows:
            raise PortalError(REFUSED)
        self._switch_to(map_id, rows[0])
        return prev

    def prune_versions(self, owner, keep=2):
        """For each of the owner's maps keep the current version and the newest earlier one(s); delete older versions
        and any files in the owner's blobs folder that nothing refers to. Returns the number of files deleted."""
        rows, keep_rows = [], []
        for m in self.list_maps(owner):
            pk = self._all(f"map_packages?select=id,map_id,storage_prefix,is_current,manifest,published_at"
                           f"&map_id=eq.{m['id']}&order=published_at.desc,id")
            rows += pk
            keep_rows += ([r for r in pk if r["is_current"]] + [r for r in pk if not r["is_current"]])[:max(keep, 1)]
        keep_ids = {r["id"] for r in keep_rows}
        needed = set().union(*(self._package_paths(r) for r in keep_rows)) if keep_rows else set()
        for r in rows:
            if r["id"] not in keep_ids:
                self.rest("DELETE", f"map_packages?id=eq.{r['id']}")
        files = [f for f in self.list_objects(self._blob_dir(owner)) if f not in needed]
        self.delete_objects(files)
        return len(files)

    def take_offline(self, owner, map_id):
        """Take a map off the platform to save space: its versions and files go (files its other maps still use stay),
        the map itself is kept as offline, and publishing it again from the local copy brings it back. Returns bytes freed."""
        self._need_publisher()
        blob_dir = self._blob_dir(owner)
        before = sum(self.object_sizes(blob_dir).values())
        self.rest("DELETE", f"map_packages?map_id=eq.{map_id}")
        self.prune_versions(owner, keep=KEEP_VERSIONS)
        if not self.rest("PATCH", f"published_maps?id=eq.{map_id}&select=id",
                         {"archived_at": dt.datetime.now(dt.timezone.utc).isoformat()},
                         prefer="return=representation"):
            raise PortalError(REFUSED)
        return before - sum(self.object_sizes(blob_dir).values())
