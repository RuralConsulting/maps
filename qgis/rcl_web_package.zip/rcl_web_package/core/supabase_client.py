"""Upload a package to the RCL portal (Supabase) and manage who can see it.

Works as the signed-in staff member (email, password and two-factor code; see session.py). There is no
secret key on this computer: what each person can do is decided by their staff role in the database
(schema.sql), and customer accounts and passwords are made by the staff-admin function on the server.
"""
import base64
import hashlib
import datetime as dt
import json
import mimetypes
import os
import re
import urllib.error
import urllib.parse
import urllib.request

from .session import SignInError

BUCKET = "farm-maps"
PHOTO_BUCKET = "suggestion-photos"
CHUNK = 6 * 1024 * 1024          # Supabase resumable uploads require 6 MB chunks
SMALL = 5 * 1024 * 1024          # files below this go in one request
KEEP_VERSIONS = 2                # current map + the previous one, for going back

mimetypes.add_type("application/vnd.pmtiles", ".pmtiles")
mimetypes.add_type("application/geo+json", ".geojson")


class PortalError(Exception):
    pass


ROLE_NAMES = {"admin": "admin", "publisher": "publisher", "staff": "staff (view and suggestions only)"}


def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:32]


class Portal:
    def __init__(self, session, timeout=120):
        self.session = session
        self.url = session.url
        self.timeout = timeout
        self.role = None                          # admin / publisher / staff, set by check()
        self._people = None
        m = re.match(r"https://([a-z0-9]+)\.supabase\.co", self.url)
        # large uploads go straight to the storage host
        self.storage_url = f"https://{m.group(1)}.storage.supabase.co" if m else self.url

    @property
    def email(self):
        return self.session.email

    @property
    def can_publish(self):
        return self.role in ("admin", "publisher")

    @property
    def is_admin(self):
        return self.role == "admin"

    # ---------------------------------------------------------------- http
    def _token(self):
        try:
            return self.session.token()
        except SignInError as e:
            raise PortalError(str(e)) from None

    def _req(self, method, url, body=None, headers=None, raw=False, _retry=True):
        token = self._token()
        h = {"apikey": self.session.public_key, "Authorization": f"Bearer {token}"}
        h.update(headers or {})
        data = body
        if body is not None and not isinstance(body, (bytes, bytearray)):
            data = json.dumps(body).encode()
            h.setdefault("Content-Type", "application/json")
        req = urllib.request.Request(url, data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                content = r.read()
                if raw:
                    return r.status, dict(r.headers), content
                return json.loads(content) if content else None
        except urllib.error.HTTPError as e:
            detail = e.read().decode(errors="replace")[:400]
            # an access token that ran out (or was replaced) mid-way: renew it once and try again
            expired = e.code == 401 or (e.code in (400, 403) and re.search(r"jwt|token", detail, re.I)
                                        and re.search(r"expired|invalid", detail, re.I))
            if expired and _retry:
                try:
                    self.session.refresh(stale_token=token)
                except SignInError as err:
                    raise PortalError(str(err)) from None
                return self._req(method, url, body, headers, raw, _retry=False)
            if raw:
                return e.code, dict(e.headers), detail.encode()
            if e.code in (401, 403) and ("row-level security" in detail.lower() or "42501" in detail):
                raise PortalError("Your staff role doesn't allow this. Ask an admin (portal > Staff).") from None
            raise PortalError(f"{method} {url.split('?')[0]} failed ({e.code}): {detail}") from None
        except urllib.error.URLError as e:
            raise PortalError(f"Could not reach the portal: {e.reason}") from None

    def rpc(self, name, args=None):
        return self._req("POST", f"{self.url}/rest/v1/rpc/{name}", args or {})

    def admin(self, action, **args):
        """Ask the staff-admin function (it holds the secret key and checks your role)."""
        token = self._token()
        body = json.dumps({"action": action, **args}).encode()
        for attempt in (0, 1):
            req = urllib.request.Request(f"{self.url}/functions/v1/staff-admin", data=body, method="POST", headers={
                "apikey": self.session.public_key, "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    content = r.read()
                    return json.loads(content) if content else {}
            except urllib.error.HTTPError as e:
                detail = e.read().decode(errors="replace")[:400]
                if e.code == 401 and attempt == 0:
                    try:
                        token = self.session.refresh(stale_token=token)
                    except SignInError as err:
                        raise PortalError(str(err)) from None
                    continue
                try:
                    msg = json.loads(detail).get("error") or detail
                except ValueError:
                    msg = detail
                if e.code == 404 and not msg.strip().startswith("No account"):
                    msg = ("The portal's staff-admin function isn't set up yet. Deploy it in Supabase "
                           "(see the setup steps).")
                raise PortalError(msg) from None
            except urllib.error.URLError as e:
                raise PortalError(f"Could not reach the portal: {e.reason}") from None

    def rest(self, method, path, body=None, prefer=None):
        h = {"Prefer": prefer} if prefer else {}
        return self._req(method, f"{self.url}/rest/v1/{path}", body, h)

    # ---------------------------------------------------------------- checks
    def check(self):
        """Confirm the sign-in works, find this person's staff role and that the database is up to date."""
        try:
            role = self.rpc("staff_role")
        except PortalError as e:
            if "staff_role" in str(e) and "404" in str(e):
                raise PortalError("The portal's database needs updating: run the latest schema.sql in Supabase.") from None
            raise
        if not role:
            if self.session.aal != "aal2":
                raise PortalError("Sign in with your two-factor code to use the QGIS tool.")
            raise PortalError(f"{self.email} isn't RCL staff. Ask an admin to add you in the portal (Staff page).")
        self.role = role
        self.people(refresh=True)
        return role

    # ---------------------------------------------------------------- farms
    def list_farms(self):
        return self.rest("GET", "farms?select=id,name,slug&order=name")

    def ensure_farm(self, name, slug):
        rows = self.rest("POST", "farms?on_conflict=slug", [{"name": name, "slug": slug}],
                         prefer="resolution=merge-duplicates,return=representation")
        return rows[0]

    # ---------------------------------------------------------------- files
    def upload_file(self, local, object_name, progress=None):
        size = os.path.getsize(local)
        ctype = mimetypes.guess_type(local)[0] or "application/octet-stream"
        if size <= SMALL:
            with open(local, "rb") as fh:
                data = fh.read()
            self._req("POST", f"{self.url}/storage/v1/object/{BUCKET}/{urllib.parse.quote(object_name)}", data,
                      {"Content-Type": ctype, "x-upsert": "true", "Cache-Control": "max-age=3600"})
            if progress:
                progress(size)
            return
        meta = {"bucketName": BUCKET, "objectName": object_name, "contentType": ctype, "cacheControl": "3600"}
        md = ",".join(f"{k} {base64.b64encode(v.encode()).decode()}" for k, v in meta.items())
        st, hdrs, body = self._req("POST", f"{self.storage_url}/storage/v1/upload/resumable", b"",
                                   {"Tus-Resumable": "1.0.0", "Upload-Length": str(size), "Upload-Metadata": md,
                                    "x-upsert": "true"}, raw=True)
        if st == 413:
            raise PortalError(
                f"{os.path.basename(local)} is {size / 1e6:.0f} MB, which is over Supabase's file size limit.\n\n"
                "The free plan allows 50 MB per file. On the Pro plan, raise it in Supabase: "
                "Storage > Settings > Global file size limit (e.g. 20 GB). Or lower 'Imagery detail' and rebuild.")
        if st not in (200, 201):
            raise PortalError(f"Could not start upload of {object_name} ({st}): {body[:300]!r}")
        loc = hdrs.get("Location") or hdrs.get("location")
        if loc.startswith("/"):
            loc = self.storage_url + loc
        offset = 0
        with open(local, "rb") as fh:
            while offset < size:
                chunk = fh.read(CHUNK)
                for attempt in range(4):
                    st, hdrs, body = self._req("PATCH", loc, chunk,
                                               {"Tus-Resumable": "1.0.0", "Upload-Offset": str(offset),
                                                "Content-Type": "application/offset+octet-stream"}, raw=True)
                    if st in (200, 204):
                        break
                    if attempt == 3:
                        raise PortalError(f"Upload of {object_name} stopped at {offset} bytes ({st}): {body[:300]!r}")
                offset += len(chunk)
                if progress:
                    progress(len(chunk))

    # ---------------------------------------------------------------- maps
    def list_maps(self, farm_id):
        return self.rest("GET", f"maps?select=*&farm_id=eq.{farm_id}&order=created_at") or []

    def ensure_map(self, farm_id, slug, title, description=None, kind=None):
        row = {"farm_id": farm_id, "slug": slug, "title": title, "description": description or None,
               "kind": kind or None, "archived_at": None}           # publishing brings an offline map back
        try:
            rows = self.rest("POST", "maps?on_conflict=farm_id,slug", [row],
                             prefer="resolution=merge-duplicates,return=representation")
        except PortalError as e:
            if "archived_at" not in str(e):
                raise
            row.pop("archived_at")                                   # database not updated yet
            rows = self.rest("POST", "maps?on_conflict=farm_id,slug", [row],
                             prefer="resolution=merge-duplicates,return=representation")
        return rows[0]

    def update_map(self, map_id, **fields):
        self.rest("PATCH", f"maps?id=eq.{map_id}", {k: (v or None) for k, v in fields.items()})

    def publish(self, package_dir, farm_name, farm_slug, version, progress=None,
                map_slug=None, map_title=None, description=None, kind=None):
        """Upload a built package and make it the current version of one of the property's maps.

        map_slug picks the map (created if new). Files are stored by content (farm/blobs/<hash>), so
        anything already on the portal, such as unchanged drone imagery, isn't uploaded or stored twice."""
        with open(os.path.join(package_dir, "manifest.json"), encoding="utf-8") as fh:
            manifest = json.load(fh)
        farm = self.ensure_farm(farm_name, farm_slug)
        map_title = map_title or manifest.get("map_title") or manifest.get("title") or farm_name
        mp = self.ensure_map(farm["id"], map_slug or "map", map_title,
                             description if description is not None else manifest.get("description"),
                             kind if kind is not None else manifest.get("kind"))
        blob_dir = f"{farm['id']}/blobs"
        files = manifest["files"]
        sizes = {rel: os.path.getsize(os.path.join(package_dir, rel)) for rel in files}
        total = sum(sizes.values()) or 1
        sent = [0]

        def tick(n):
            sent[0] += n
            if progress:
                progress(sent[0], total)

        existing = set(self.list_objects(blob_dir))
        file_map, skipped = {}, 0
        for rel in files:
            local = os.path.join(package_dir, rel)
            name = f"{blob_dir}/{file_hash(local)}{os.path.splitext(rel)[1].lower()}"
            file_map[rel] = name
            if name in existing:
                skipped += sizes[rel]
                tick(sizes[rel])
            else:
                self.upload_file(local, name, tick)
                existing.add(name)
        manifest["file_map"] = file_map
        manifest["property"] = farm_name
        manifest["map_title"] = mp["title"]
        self.rest("PATCH", f"packages?map_id=eq.{mp['id']}&is_current=is.true", {"is_current": False})
        self.rest("POST", "packages", [{
            "farm_id": farm["id"], "map_id": mp["id"], "version": version, "title": mp["title"],
            "survey_date": manifest.get("survey_date") or None, "manifest": manifest,
            "storage_prefix": blob_dir, "is_current": True}], prefer="return=minimal")
        try:
            self.prune_versions(farm["id"], keep=KEEP_VERSIONS)
        except PortalError:
            pass            # tidying up is best-effort; the new map is already live
        farm["map"] = mp
        farm["reused_bytes"], farm["uploaded_bytes"] = skipped, total - skipped
        return farm

    # ---------------------------------------------------------------- housekeeping
    def list_objects(self, prefix, bucket=BUCKET):
        """Every file path under prefix (a folder, no trailing slash), recursively."""
        return list(self.object_sizes(prefix, bucket))

    def object_sizes(self, prefix, bucket=BUCKET):
        """{path: bytes} for every file under prefix, recursively."""
        out, offset = {}, 0
        while True:
            items = self._req("POST", f"{self.url}/storage/v1/object/list/{bucket}",
                              {"prefix": prefix, "limit": 1000, "offset": offset,
                               "sortBy": {"column": "name", "order": "asc"}}) or []
            for it in items:
                path = f"{prefix}/{it['name']}"
                if it.get("id") is None:          # a folder
                    out.update(self.object_sizes(path, bucket))
                else:
                    out[path] = int((it.get("metadata") or {}).get("size") or 0)
            if len(items) < 1000:
                return out
            offset += 1000

    def delete_objects(self, paths, bucket=BUCKET):
        for i in range(0, len(paths), 1000):
            self._req("DELETE", f"{self.url}/storage/v1/object/{bucket}", {"prefixes": paths[i:i + 1000]})

    def map_info(self, map_id):
        return self.rest("GET", f"packages?select=version,title,survey_date,published_at,is_current"
                                f"&map_id=eq.{map_id}&order=published_at.desc") or []

    @staticmethod
    def _package_paths(row):
        m = row.get("manifest") or {}
        fm = m.get("file_map")
        if fm:
            return set(fm.values())
        return {f"{row['storage_prefix']}/{rel}" for rel in m.get("files", [])}

    def prune_versions(self, farm_id, keep=2):
        """For each of the property's maps keep the current version and the newest earlier one(s);
        delete older versions and any files nothing refers to (e.g. half-finished uploads).
        Returns the number of files deleted."""
        pk = self.rest("GET", f"packages?select=id,map_id,storage_prefix,is_current,manifest,published_at"
                              f"&farm_id=eq.{farm_id}&order=published_at.desc") or []
        keep_rows = []
        for mid in {r.get("map_id") for r in pk}:
            rows = [r for r in pk if r.get("map_id") == mid]
            keep_rows += ([r for r in rows if r["is_current"]] + [r for r in rows if not r["is_current"]])[:max(keep, 1)]
        keep_ids = {r["id"] for r in keep_rows}
        needed = set().union(*(self._package_paths(r) for r in keep_rows)) if keep_rows else set()
        files = [f for f in self.list_objects(str(farm_id)) if f not in needed]
        self.delete_objects(files)
        for r in pk:
            if r["id"] not in keep_ids:
                self.rest("DELETE", f"packages?id=eq.{r['id']}")
        return len(files)

    def restore_previous(self, map_id):
        """Make the previous published version of a map current again."""
        pk = self.map_info(map_id)
        prev = next((r for r in pk if not r["is_current"]), None)
        if not prev:
            raise PortalError("There's no earlier version of this map to go back to.")
        self.rest("PATCH", f"packages?map_id=eq.{map_id}&is_current=is.true", {"is_current": False})
        self.rest("PATCH", f"packages?map_id=eq.{map_id}&version=eq.{urllib.parse.quote(prev['version'])}",
                  {"is_current": True})
        return prev

    def take_offline(self, farm_id, map_id):
        """Take a map off the portal to save space: its versions and files go (files other maps still use
        stay), the map itself is kept as "offline" so it shows in the register, and publishing it again
        from the local copy brings it back. Returns bytes freed."""
        before = sum(self.object_sizes(str(farm_id)).values())
        self.rest("DELETE", f"packages?map_id=eq.{map_id}")
        self.prune_versions(farm_id, keep=KEEP_VERSIONS)
        try:
            self.rest("PATCH", f"maps?id=eq.{map_id}",
                      {"archived_at": dt.datetime.now(dt.timezone.utc).isoformat()})
        except PortalError:
            pass                                                     # database not updated yet
        return before - sum(self.object_sizes(str(farm_id)).values())

    def storage_report(self):
        """Every map with its online size, when customers last opened it and when it was published.
        Returns {"maps": [...], "farms": {farm_id: bytes}, "photos": bytes}."""
        staff = {r["user_id"] for r in self.rest("GET", "staff?select=user_id") or []}
        farms = {f["id"]: f for f in self.list_farms()}
        maps = self.rest("GET", "maps?select=*&order=created_at") or []
        last = {}
        try:
            for v in self.rest("GET", "map_views?select=map_id,user_id,viewed_at&order=viewed_at.desc&limit=100000") or []:
                if v.get("user_id") not in staff and v.get("map_id") and v["map_id"] not in last:
                    last[v["map_id"]] = v["viewed_at"]
        except PortalError:
            pass
        out, farm_bytes, photos = [], {}, 0
        for fid, f in farms.items():
            sizes = self.object_sizes(str(fid))
            farm_bytes[fid] = sum(sizes.values())
            try:
                photos += sum(self.object_sizes(str(fid), PHOTO_BUCKET).values())
            except PortalError:
                pass
            pk = self.rest("GET", f"packages?select=map_id,storage_prefix,manifest,is_current,published_at"
                                  f"&farm_id=eq.{fid}") or []
            for m in [m for m in maps if m["farm_id"] == fid]:
                rows = [r for r in pk if r.get("map_id") == m["id"]]
                paths = set().union(*(self._package_paths(r) for r in rows)) if rows else set()
                cur = next((r for r in rows if r["is_current"]), None)
                out.append({"farm": f, "map": m, "online_bytes": sum(sizes.get(p, 0) for p in paths),
                            "versions": len(rows), "published_at": cur and cur.get("published_at"),
                            "last_visit": last.get(m["id"]), "archived_at": m.get("archived_at")})
        return {"maps": out, "farms": farm_bytes, "photos": photos}

    def delete_map(self, farm_id, map_id):
        """Remove one map of a property (its versions and files no other map uses)."""
        self.rest("DELETE", f"maps?id=eq.{map_id}")          # its packages go with it
        return self.prune_versions(farm_id, keep=KEEP_VERSIONS)

    def delete_farm(self, farm_id):
        """Remove a farm completely: its map files, versions and everyone's access to it.
        People's accounts stay (they may have other farms)."""
        files = self.list_objects(str(farm_id))
        self.delete_objects(files)
        try:
            self.delete_objects(self.list_objects(str(farm_id), PHOTO_BUCKET), PHOTO_BUCKET)
        except PortalError:
            pass
        self.rest("DELETE", f"farms?id=eq.{farm_id}")       # packages, access and suggestions go with it
        return len(files)

    # ---------------------------------------------------------------- people
    def people(self, refresh=False):
        """Everyone with access to a property, and staff: [{id, email, last_sign_in_at, created_at, staff_role}]."""
        if refresh or self._people is None:
            self._people = self.rpc("staff_people") or []
        return self._people

    def _find_user(self, email):
        email = email.strip().lower()
        return next((u for u in self.people() if (u.get("email") or "").lower() == email), None)

    def reset_password(self, email):
        """Give an existing account a new random password (made on the server) and return it."""
        return self.admin("reset_password", email=email.strip().lower())["password"]

    def share(self, farm_id, emails):
        """Give these people access. Returns [(email, new_password_or_None)]."""
        emails = [e.strip().lower() for e in emails if e.strip()]
        if not emails:
            return []
        people = self.admin("ensure_customers", emails=emails)["people"]
        self.rest("POST", "farm_members?on_conflict=farm_id,user_id",
                  [{"farm_id": farm_id, "user_id": p["id"]} for p in people],
                  prefer="resolution=ignore-duplicates,return=minimal")
        self._people = None
        return [(p["email"], p.get("password")) for p in people]

    def members(self, farm_id, detail=False):
        """Emails with access to a farm (sorted). detail=True gives [{id, email, last_sign_in_at}]."""
        rows = self.rest("GET", f"farm_members?select=user_id&farm_id=eq.{farm_id}")
        ids = {r["user_id"] for r in rows}
        people = self.people() if ids else []
        if ids - {u["id"] for u in people}:                # someone new since the list was fetched
            people = self.people(refresh=True)
        out = [{"id": u["id"], "email": u["email"], "last_sign_in_at": u.get("last_sign_in_at")}
               for u in people if u["id"] in ids]
        out.sort(key=lambda u: u["email"])
        return out if detail else [u["email"] for u in out]

    # ---------------------------------------------------------------- visits and staff
    def visits(self, farm_id):
        """Map visits per person: {user_id: {"count", "last", "phone", "computer"}} (RCL staff not counted)."""
        staff = {r["user_id"] for r in self.rest("GET", "staff?select=user_id") or []}
        rows = self.rest("GET", f"map_views?select=user_id,viewed_at,device&farm_id=eq.{farm_id}"
                                f"&order=viewed_at.desc&limit=10000") or []
        out = {}
        for r in rows:
            if r["user_id"] in staff or not r["user_id"]:
                continue
            v = out.setdefault(r["user_id"], {"count": 0, "last": r["viewed_at"], "phone": 0, "computer": 0})
            v["count"] += 1
            if r.get("device") in ("phone", "computer"):
                v[r["device"]] += 1
        return out

    def _all_users(self):
        """Customers and staff (the register uses this for emails and sign-in dates)."""
        return self.people(refresh=True)

    def staff(self):
        return sorted(u["email"] for u in self.people() if u.get("staff_role"))

    # ---------------------------------------------------------------- suggestions
    def suggestions(self, farm_id=None, status=None):
        q = "suggestions?select=*&order=created_at.desc"
        if farm_id:
            q += f"&farm_id=eq.{farm_id}"
        if status:
            q += f"&status=eq.{status}"
        return self.rest("GET", q) or []

    def suggestion_events(self, sid):
        """History of a suggestion: created, status changes, replies, notes, emails (oldest first)."""
        return self.rest("GET", f"suggestion_events?select=*&suggestion_id=eq.{sid}&order=at.asc,id.asc") or []

    def add_note(self, sid, body):
        """An internal note on a suggestion (only RCL staff see these)."""
        self.rest("POST", "suggestion_events", [{"suggestion_id": sid, "kind": "note", "body": body.strip()}],
                  prefer="return=minimal")         # who and when are filled in from the sign-in

    def delete_suggestion(self, s):
        """Delete a suggestion, its photos and its history."""
        if s.get("photos"):
            self.delete_objects(list(s["photos"]), bucket=PHOTO_BUCKET)
        self.rest("DELETE", f"suggestions?id=eq.{s['id']}")

    def all_maps(self):
        return self.rest("GET", "maps?select=id,farm_id,title,slug") or []

    def new_suggestion_counts(self, timeout=6):
        """{farm_id: n} of suggestions not dealt with yet (quick check when the panel opens)."""
        old, self.timeout = self.timeout, timeout
        try:
            rows = self.rest("GET", "suggestions?select=farm_id&status=eq.new")
        finally:
            self.timeout = old
        out = {}
        for r in rows or []:
            out[r["farm_id"]] = out.get(r["farm_id"], 0) + 1
        return out

    def update_suggestion(self, sid, status=None, reply=None):
        body = {}
        if status is not None:
            body["status"] = status
        if reply is not None:
            body["reply"] = reply.strip() or None
        if body:
            self.rest("PATCH", f"suggestions?id=eq.{sid}", body)

    def download_photo(self, path, dest):
        st, _, data = self._req("GET", f"{self.url}/storage/v1/object/{PHOTO_BUCKET}/{urllib.parse.quote(path)}",
                                raw=True)
        if st != 200:
            return False
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as fh:
            fh.write(data)
        return True

    def unshare(self, farm_id, email):
        u = self._find_user(email) or self._find_user_fresh(email)
        if u:
            self.rest("DELETE", f"farm_members?farm_id=eq.{farm_id}&user_id=eq.{u['id']}")

    def _find_user_fresh(self, email):
        self.people(refresh=True)
        return self._find_user(email)
