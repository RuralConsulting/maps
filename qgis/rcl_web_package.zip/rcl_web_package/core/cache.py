"""Drawn tiles kept on this computer until a layer is safely saved, so a build that fails at the end (e.g. the
packages drive refusing the file) or is cancelled carries on where it stopped next time instead of drawing again.

<local app data>/RCL Web Package/cache/<tile key>/tiles.sqlite   tables: t (tile id, data), done (metatile id, tiles),
                                                                  meta (format etc.)
A folder is in use while its "inuse" file is fresh. Entries are deleted once the layer's pieces are saved, and
clean_up() removes anything older than KEEP_DAYS plus old temporary build folders (rclpkg_*).
"""
import os
import shutil
import sqlite3
import tempfile
import time

KEEP_DAYS = 14
TEMP_DAYS = 1
INUSE_HOURS = 24


def cache_root():
    """Not in the roaming profile: these can be many GB."""
    base = os.environ.get("LOCALAPPDATA") if os.name == "nt" else None
    base = base or os.path.join(os.path.expanduser("~"), ".cache")
    return os.path.join(base, "RCL Web Package", "cache")


def entry_dir(key, root=None):
    return os.path.join(root or cache_root(), key) if key else None


def _newest(path):
    t = 0.0
    for r, _, names in os.walk(path):
        for n in names:
            try:
                t = max(t, os.path.getmtime(os.path.join(r, n)))
            except OSError:
                pass
    return t or os.path.getmtime(path)


def _size(path):
    n = 0
    for r, _, names in os.walk(path):
        for f in names:
            try:
                n += os.path.getsize(os.path.join(r, f))
            except OSError:
                pass
    return n


def in_use(path, now=None):
    try:
        return (now or time.time()) - os.path.getmtime(os.path.join(path, "inuse")) < INUSE_HOURS * 3600
    except OSError:
        return False


def clean_up(log=None, root=None, tmp=None, now=None):
    """Remove temporary build folders older than a day and cache entries untouched for KEEP_DAYS (never one in use).
    Returns [(path, bytes)] removed."""
    now = now or time.time()
    removed = []
    tmp = tmp or tempfile.gettempdir()
    try:
        for n in os.listdir(tmp):
            p = os.path.join(tmp, n)
            if n.startswith("rclpkg_") and os.path.isdir(p) and now - _newest(p) > TEMP_DAYS * 86400:
                size = _size(p)
                shutil.rmtree(p, ignore_errors=True)
                if not os.path.exists(p):
                    removed.append((p, size))
    except OSError:
        pass
    root = root or cache_root()
    try:
        for n in os.listdir(root):
            p = os.path.join(root, n)
            if os.path.isdir(p) and not in_use(p, now) and now - _newest(p) > KEEP_DAYS * 86400:
                size = _size(p)
                shutil.rmtree(p, ignore_errors=True)
                if not os.path.exists(p):
                    removed.append((p, size))
    except OSError:
        pass
    if log is not None and removed:
        log.write("cleared old build files: " + "; ".join(f"{p} ({s / 1e6:.0f} MB)" for p, s in removed))
    return removed


class TileStore:
    """The drawn tiles of one layer, with a record of which metatiles are finished."""

    def __init__(self, folder, fmt, quality, scale):
        self.folder = folder
        self.kept = folder is not None
        if not self.kept:
            folder = tempfile.mkdtemp(prefix="rclpkg_")
            self.folder = folder
        os.makedirs(folder, exist_ok=True)
        self.touch()
        self.path = os.path.join(folder, "tiles.sqlite")
        self.db = sqlite3.connect(self.path)
        self.db.execute("CREATE TABLE IF NOT EXISTS t (id INTEGER PRIMARY KEY, data BLOB)")
        self.db.execute("CREATE TABLE IF NOT EXISTS done (job INTEGER PRIMARY KEY, tiles INTEGER)")
        self.db.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
        want = {"fmt": fmt, "quality": str(quality), "scale": str(scale)}
        have = dict(self.db.execute("SELECT k, v FROM meta"))
        if have and have != want:                     # made with other settings: start again
            self.db.execute("DELETE FROM t")
            self.db.execute("DELETE FROM done")
            self.db.execute("DELETE FROM meta")
        self.db.executemany("INSERT OR REPLACE INTO meta VALUES (?, ?)", list(want.items()))
        self.db.commit()
        self.done = {j for (j,) in self.db.execute("SELECT job FROM done")}

    def touch(self):
        try:
            with open(os.path.join(self.folder, "inuse"), "w") as fh:
                fh.write(str(time.time()))
        except OSError:
            pass

    def add(self, tid, data):
        self.db.execute("INSERT OR REPLACE INTO t VALUES (?, ?)", (tid, sqlite3.Binary(data)))

    def finish(self, job, tiles):
        """A metatile's tiles are all in: remember it (saved with them at the next commit)."""
        self.db.execute("INSERT OR REPLACE INTO done VALUES (?, ?)", (job, tiles))
        self.done.add(job)

    def commit(self):
        self.db.commit()
        self.touch()

    def stats(self):
        """(tiles stored, lowest tile id or None, tiles counted in finished metatiles)"""
        n, lo = self.db.execute("SELECT count(*), min(id) FROM t").fetchone()
        attempted = self.db.execute("SELECT coalesce(sum(tiles), 0) FROM done").fetchone()[0]
        return n, lo, attempted

    def close(self):
        """Stop using it. Anything not committed (a part still being drawn when it failed) is dropped."""
        try:
            self.db.rollback()
        except sqlite3.Error:
            pass
        self.db.close()
        try:
            os.remove(os.path.join(self.folder, "inuse"))
        except OSError:
            pass

    def discard(self):
        """The layer is saved: the drawn tiles aren't needed any more."""
        self.close()
        shutil.rmtree(self.folder, ignore_errors=True)
