"""Render QGIS layers exactly as styled, clipped to a boundary, into a PMTiles file.

Tiles are web-mercator XYZ. Rendering happens in "metatiles" (several tiles at
once, with a padding buffer so symbols and labels are not cut at tile edges),
then sliced. Tiles that are entirely transparent are not stored.
"""
import math
import os
import sqlite3
import tempfile

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsGeometry,
    QgsMapClippingRegion,
    QgsMapRendererCustomPainterJob,
    QgsMapSettings,
    QgsProject,
    QgsRectangle,
)
from qgis.PyQt.QtCore import QBuffer, QByteArray, QIODevice, QSize
from qgis.PyQt.QtGui import QColor, QImage, QImageWriter, QPainter

CHUNK = 8 * 1024 * 1024
PART_BYTES = 900 * 1024 * 1024          # largest map file written: well under Egnyte and network-drive limits


def _tiles_bounds(ids):
    """lon/lat box covering these tiles (from each zoom's corner tiles is enough for a piece of the curve)"""
    w = s = 180.0
    e = n = -180.0
    for t in ids:
        z, x, y = tileid_to_zxy(t)
        k = 2 ** z
        lw, le = x / k * 360 - 180, (x + 1) / k * 360 - 180
        ln = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / k))))
        ls = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * (y + 1) / k))))
        w, e, s, n = min(w, lw), max(e, le), min(s, ls), max(n, ln)
    return w, s, e, n


def copy_out(src, dst, tries=4):
    """Copy a finished file into the packages folder in modest pieces, retrying, because shared network and Egnyte
    drives can refuse very large single writes ("Invalid argument"). Leaves the built file in place if it can't."""
    import time
    last = None
    for attempt in range(tries):
        try:
            part = dst + ".part"
            with open(src, "rb") as fi, open(part, "wb") as fo:
                while True:
                    buf = fi.read(CHUNK)
                    if not buf:
                        break
                    fo.write(buf)
                fo.flush()
                os.fsync(fo.fileno())
            if os.path.exists(dst):
                os.remove(dst)
            os.replace(part, dst)
            return
        except OSError as e:
            last = e
            time.sleep(1.5 * (attempt + 1))
    raise OSError(
        f"Couldn't save {os.path.basename(dst)} into {os.path.dirname(dst)} ({last}). "
        f"The drive may not accept large files. The built file is kept at {src}. "
        f"Choose a folder on this computer under 'Save packages in' and build again; publishing works from there.")


from ..vendor.pmtiles.tile import Compression, TileType, tileid_to_zxy, zxy_to_tileid
from ..vendor.pmtiles.writer import Writer

ORIGIN = 20037508.342789244
EPSG3857 = QgsCoordinateReferenceSystem("EPSG:3857")


class Cancelled(Exception):
    pass


def scaled_layer(layer, factor):
    """A copy of a vector layer with marker sizes and line widths multiplied by factor (for the web only;
    the project's own style is untouched)."""
    if abs(factor - 1.0) < 1e-6 or not hasattr(layer, "renderer") or layer.renderer() is None:
        return layer
    from qgis.core import QgsLineSymbol, QgsMarkerSymbol
    c = layer.clone()
    r = c.renderer()
    for item in r.legendSymbolItems():
        sym = item.symbol()
        if sym is None:
            continue
        s2 = sym.clone()
        if isinstance(s2, QgsMarkerSymbol):
            s2.setSize(s2.size() * factor)
        elif isinstance(s2, QgsLineSymbol):
            s2.setWidth(s2.width() * factor)
        else:
            continue
        try:
            r.setLegendSymbolItem(item.ruleKey(), s2)
        except Exception:  # noqa: renderers that don't support per-item symbols
            pass
    return c


def tile_size_m(z):
    return 2 * ORIGIN / (2 ** z)


def tile_rect(z, x, y):
    s = tile_size_m(z)
    minx = -ORIGIN + x * s
    maxy = ORIGIN - y * s
    return QgsRectangle(minx, maxy - s, minx + s, maxy)


def tile_range(z, rect):
    s = tile_size_m(z)
    n = 2 ** z
    x0 = max(0, int(math.floor((rect.xMinimum() + ORIGIN) / s)))
    x1 = min(n - 1, int(math.floor((rect.xMaximum() + ORIGIN) / s)))
    y0 = max(0, int(math.floor((ORIGIN - rect.yMaximum()) / s)))
    y1 = min(n - 1, int(math.floor((ORIGIN - rect.yMinimum()) / s)))
    return x0, x1, y0, y1


def webp_available():
    return b"webp" in [bytes(f) for f in QImageWriter.supportedImageFormats()]


def _encode(img, fmt, quality):
    ba = QByteArray()
    buf = QBuffer(ba)
    buf.open(QIODevice.WriteOnly)
    img.save(buf, fmt.upper(), quality)
    buf.close()
    return bytes(ba)


def _is_empty(img):
    """True when every pixel is fully transparent."""
    try:
        import numpy as np
        ptr = img.constBits()
        ptr.setsize(img.sizeInBytes() if hasattr(img, "sizeInBytes") else img.byteCount())
        arr = np.frombuffer(ptr, np.uint8).reshape(img.height(), img.bytesPerLine())
        alpha = arr[:, 3: img.width() * 4: 4]   # ARGB32 is BGRA in memory on little-endian
        return not alpha.any()
    except Exception:  # noqa: numpy missing - slower fallback
        for yy in range(0, img.height(), 4):
            for xx in range(0, img.width(), 4):
                if QColor.fromRgba(img.pixel(xx, yy)).alpha():
                    return False
        return True


def estimate_tiles(boundary_3857, minz, maxz, meta=4):
    n = 0
    bbox = boundary_3857.boundingBox()
    for z in range(minz, maxz + 1):
        x0, x1, y0, y1 = tile_range(z, bbox)
        n += (x1 - x0 + 1) * (y1 - y0 + 1)
    return n


def write_archive(db, out_path, tmpdir, fmt, name, scale, minz, bbox, progress=None):
    """Write the tiles in `db` (table t: id, data) as one or more .pmtiles files: out_path, then out-2.pmtiles...
    Returns ([{path, minzoom, maxzoom, bounds}], total bytes)."""
    # split into pieces of at most PART_BYTES: Egnyte and some network drives refuse single files of several GB.
    # Tiles are in tile-id order (zoom by zoom, then along a space-filling curve), so each piece covers a compact area;
    # the viewer draws all the pieces together.
    groups, cur, size = [], [], 0
    for tid, n in db.execute("SELECT id, length(data) FROM t ORDER BY id"):
        if cur and size + n > PART_BYTES:
            groups.append(cur)
            cur, size = [], 0
        cur.append(tid)
        size += n
    if cur:
        groups.append(cur)

    base = os.path.splitext(out_path)[0]
    stem = os.path.basename(base)
    folder = os.path.dirname(out_path)
    try:                                                   # pieces from an earlier build of this layer
        for old in os.listdir(folder):
            if old.startswith(stem + "-") and old.endswith(".pmtiles") and old[len(stem) + 1:-8].isdigit():
                os.remove(os.path.join(folder, old))
    except OSError:
        pass
    parts, total_bytes = [], 0
    for k, ids in enumerate(groups):
        dst = out_path if k == 0 else f"{base}-{k + 1}.pmtiles"
        zs = [tileid_to_zxy(t) for t in (ids[0], ids[-1])]
        zmin, zmax = zs[0][0], zs[1][0]
        w_, s_, e_, n_ = _tiles_bounds(ids) if len(groups) > 1 else bbox
        local_path = os.path.join(tmpdir, f"map-{k + 1}.pmtiles")   # build on this computer, then copy across
        with open(local_path, "wb") as f:
            wr = Writer(f)
            lo, hi = ids[0], ids[-1]
            for tid, data in db.execute("SELECT id, data FROM t WHERE id BETWEEN ? AND ? ORDER BY id", (lo, hi)):
                wr.write_tile(tid, bytes(data))
            wr.finalize(
                {
                    "tile_type": TileType.WEBP if fmt == "webp" else TileType.PNG,
                    "tile_compression": Compression.NONE,
                    "min_lon_e7": int(w_ * 1e7), "min_lat_e7": int(s_ * 1e7),
                    "max_lon_e7": int(e_ * 1e7), "max_lat_e7": int(n_ * 1e7),
                    "center_zoom": max(zmin, min(zmax, minz + 2)),
                    "center_lon_e7": int((w_ + e_) / 2 * 1e7), "center_lat_e7": int((s_ + n_) / 2 * 1e7),
                },
                {"name": name, "format": fmt, "scale": scale, "generator": "RCL Web Package", "part": k + 1, "parts": len(groups)},
            )
        if progress and len(groups) > 1:
            progress(f"{name}: saving piece {k + 1} of {len(groups)}")
        copy_out(local_path, dst)
        total_bytes += os.path.getsize(dst)
        try:
            os.remove(local_path)
        except OSError:
            pass
        parts.append({"path": dst, "minzoom": zmin, "maxzoom": zmax, "bounds": [round(w_, 7), round(s_, 7), round(e_, 7), round(n_, 7)]})
    return parts, total_bytes


def render_to_pmtiles(layers, boundary_3857, out_path, minz, maxz, *, scale=1, fmt=None, quality=85,
                      labels=True, project=None, progress=None, name="", meta=4, pad_px=48):
    """Render `layers` (list, top first) to `out_path`. Returns dict with stats.

    progress(done, total, message) may raise Cancelled.
    """
    project = project or QgsProject.instance()
    fmt = fmt or ("webp" if webp_available() else "png")
    tile_px = 256 * scale
    pad = pad_px * scale
    bbox = boundary_3857.boundingBox()

    tmpdir = tempfile.mkdtemp(prefix="rclpkg_")
    db = sqlite3.connect(os.path.join(tmpdir, "tiles.sqlite"))
    db.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, data BLOB)")

    # work list of metatiles
    jobs = []
    for z in range(minz, maxz + 1):
        x0, x1, y0, y1 = tile_range(z, bbox)
        for mx in range(x0 // meta, x1 // meta + 1):
            for my in range(y0 // meta, y1 // meta + 1):
                tx0, ty0 = max(mx * meta, x0), max(my * meta, y0)
                tx1, ty1 = min(mx * meta + meta - 1, x1), min(my * meta + meta - 1, y1)
                r = QgsRectangle(tile_rect(z, tx0, ty0).xMinimum(), tile_rect(z, tx0, ty1).yMinimum(),
                                 tile_rect(z, tx1, ty0).xMaximum(), tile_rect(z, tx0, ty0).yMaximum())
                if boundary_3857.intersects(r):
                    jobs.append((z, tx0, ty0, tx1, ty1, r))

    ms = QgsMapSettings()
    ms.setLayers(layers)
    ms.setDestinationCrs(EPSG3857)
    ms.setTransformContext(project.transformContext())
    ms.setBackgroundColor(QColor(0, 0, 0, 0))
    ms.setOutputDpi(96 * scale)
    ms.setFlag(QgsMapSettings.Antialiasing, True)
    ms.setFlag(QgsMapSettings.UseAdvancedEffects, True)
    ms.setFlag(QgsMapSettings.DrawLabeling, labels)
    ms.setFlag(QgsMapSettings.DrawSelection, False)       # features selected in QGIS must not show up yellow on the web
    ms.setFlag(QgsMapSettings.HighQualityImageTransforms, True)
    if hasattr(QgsMapSettings, "RenderPartialOutput"):
        ms.setFlag(QgsMapSettings.RenderPartialOutput, False)
    region = QgsMapClippingRegion(boundary_3857)
    region.setFeatureClip(QgsMapClippingRegion.FeatureClippingType.ClipPainterOnly)
    ms.addClippingRegion(region)
    ms.setLabelBoundaryGeometry(boundary_3857)
    ms.setPathResolver(project.pathResolver())
    # Draw features from outside each metatile too, so big symbols (photo view cones, wide labels)
    # aren't chopped where tiles meet.
    has_buffer = hasattr(ms, "setExtentBuffer")

    stored = 0
    first_zoom = None
    for i, (z, tx0, ty0, tx1, ty1, r) in enumerate(jobs):
        if progress:
            progress(i, len(jobs), f"{name}: zoom {z}")
        mpp = tile_size_m(z) / tile_px                         # map units per output pixel
        w = (tx1 - tx0 + 1) * tile_px + 2 * pad
        h = (ty1 - ty0 + 1) * tile_px + 2 * pad
        ext = QgsRectangle(r.xMinimum() - pad * mpp, r.yMinimum() - pad * mpp,
                           r.xMaximum() + pad * mpp, r.yMaximum() + pad * mpp)
        ms.setOutputSize(QSize(w, h))
        ms.setExtent(ext)
        if has_buffer:
            ms.setExtentBuffer(max(400.0, 512 * mpp))
        img = QImage(w, h, QImage.Format_ARGB32_Premultiplied)
        img.fill(0)
        p = QPainter(img)
        job = QgsMapRendererCustomPainterJob(ms, p)
        job.renderSynchronously()
        p.end()
        for tx in range(tx0, tx1 + 1):
            for ty in range(ty0, ty1 + 1):
                if not boundary_3857.intersects(tile_rect(z, tx, ty)):
                    continue
                sub = img.copy(pad + (tx - tx0) * tile_px, pad + (ty - ty0) * tile_px, tile_px, tile_px)
                if _is_empty(sub):
                    continue
                db.execute("INSERT OR REPLACE INTO t VALUES (?, ?)",
                           (zxy_to_tileid(z, tx, ty), sqlite3.Binary(_encode(sub, fmt, quality))))
                stored += 1
                first_zoom = z if first_zoom is None else min(first_zoom, z)
        if i % 20 == 0:
            db.commit()
    db.commit()
    if progress:
        progress(len(jobs), len(jobs), f"{name}: writing file")
    if stored == 0:
        db.close()
        return {"tiles": 0, "path": None}

    b4326 = QgsGeometry(boundary_3857)
    from qgis.core import QgsCoordinateTransform
    b4326.transform(QgsCoordinateTransform(EPSG3857, QgsCoordinateReferenceSystem("EPSG:4326"), project))
    bb = b4326.boundingBox()

    parts, total_bytes = write_archive(db, out_path, tmpdir, fmt, name, scale, minz,
                                       (bb.xMinimum(), bb.yMinimum(), bb.xMaximum(), bb.yMaximum()),
                                       (lambda msg: progress(len(jobs), len(jobs), msg)) if progress else None)
    db.close()
    try:
        os.remove(os.path.join(tmpdir, "tiles.sqlite"))
        os.rmdir(tmpdir)
    except OSError:
        pass
    return {"tiles": stored, "path": out_path, "format": fmt, "bytes": total_bytes, "first_zoom": first_zoom,
            "parts": parts if len(parts) > 1 else None}
