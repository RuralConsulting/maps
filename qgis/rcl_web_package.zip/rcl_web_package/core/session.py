"""Signing in to the RCL portal as a staff member: email, password and a 6-digit code (two-factor).

No secret key lives on this computer. After sign-in only a refresh token is kept (see dialog.py: Windows
Credential Manager, else the QGIS password store); it is swapped for a fresh short-lived access token as needed.
Refresh tokens change each time they're used, so the new one is handed to on_refresh to be saved.
"""
import base64
import json
import threading
import time
import urllib.error
import urllib.request

# Built-in connection. The public key is designed to be public (the same one the portal's web page uses);
# what a signed-in person can do is decided by the database's security rules.
DEFAULT_URL = "https://wmdhruwkcgtytojlmrkl.supabase.co"
DEFAULT_PUBLIC_KEY = "sb_publishable__Zr9HEyQWWtUCVOpYKnCrw_VPAx-CSs"
DEFAULT_SITE = "https://maps.ruralconsulting.co.nz"
# The farm platform ("publish to the platform"). The same public address and publishable key as the platform's
# web app (app/js/config.js in farm-platform); both are designed to be public.
PLATFORM_URL = "https://swbpymacxycbmdbexnuw.supabase.co"
PLATFORM_PUBLIC_KEY = "sb_publishable_ezMJPCuTFBl3wQAVeOJPXg_BoXxVY8A"
PLATFORM_SITE = "https://app.ruralconsulting.co.nz"
REFRESH_EARLY = 120          # seconds: get a new access token this long before the old one runs out


class SignInError(Exception):
    pass


class SignedOut(SignInError):
    """The saved sign-in no longer works (signed out elsewhere, removed, or expired): sign in again."""


def _claims(jwt):
    try:
        part = jwt.split(".")[1]
        return json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)))
    except Exception:  # noqa
        return {}


class Session:
    def __init__(self, url=DEFAULT_URL, public_key=DEFAULT_PUBLIC_KEY, on_refresh=None, timeout=30,
                 site=DEFAULT_SITE, place="portal", load_saved=None):
        self.url = url.rstrip("/")
        self.site, self.place = site, place          # where to set up two-factor; what messages call it
        self.public_key = public_key.strip()
        self.on_refresh = on_refresh
        # reads the saved sign-in: another QGIS window on this computer may have renewed it (each renewal can only
        # be used once; using an old one makes Supabase end the sign-in everywhere)
        self.load_saved = load_saved
        self.timeout = timeout
        self.access_token = None
        self.refresh_token = None
        self.expires_at = 0
        self.email = ""
        self.user_id = None
        self._factor = None
        self._lock = threading.RLock()

    # ---------------------------------------------------------------- http
    def _call(self, method, path, body=None, token=None):
        h = {"apikey": self.public_key, "Content-Type": "application/json"}
        if token:
            h["Authorization"] = f"Bearer {token}"
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.url + path, data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                content = r.read()
                return json.loads(content) if content else {}
        except urllib.error.HTTPError as e:
            try:
                j = json.loads(e.read().decode(errors="replace"))
            except Exception:  # noqa
                j = {}
            msg = j.get("msg") or j.get("error_description") or j.get("message") or j.get("error") or ""
            err = SignInError(msg or f"error {e.code}")
            err.status, err.code = e.code, j.get("error_code") or j.get("error") or ""
            raise err from None
        except urllib.error.URLError as e:
            raise SignInError(f"Could not reach the {self.place}: {e.reason}") from None

    def _take(self, res):
        self.access_token = res["access_token"]
        self.refresh_token = res.get("refresh_token") or self.refresh_token
        self.expires_at = int(res.get("expires_at") or (time.time() + int(res.get("expires_in") or 3600)))
        user = res.get("user") or {}
        self.email = (user.get("email") or self.email or "").lower()
        self.user_id = user.get("id") or self.user_id or _claims(self.access_token).get("sub")
        if self.on_refresh and self.refresh_token:
            try:
                self.on_refresh(self.refresh_token)
            except Exception:  # noqa: saving is best-effort; the session still works now
                pass
        return user

    @property
    def aal(self):
        return _claims(self.access_token or "").get("aal")

    # ---------------------------------------------------------------- sign in
    def start(self, email, password):
        """Step 1: email and password. Raises SignInError with a plain message if it can't continue."""
        try:
            res = self._call("POST", "/auth/v1/token?grant_type=password",
                             {"email": email.strip().lower(), "password": password})
        except SignInError as e:
            if getattr(e, "status", 0) == 429:
                raise SignInError("Too many attempts. Wait a few minutes and try again.") from None
            if getattr(e, "status", 0) in (400, 401):
                raise SignInError("That email and password don't match. Check them and try again.") from None
            raise
        on_refresh, self.on_refresh = self.on_refresh, None      # don't save anything until two-factor is done
        try:
            user = self._take(res)
        finally:
            self.on_refresh = on_refresh
        if "factors" not in user:                                  # not in every response: ask for it
            try:
                user = self._call("GET", "/auth/v1/user", None, token=self.access_token) or user
            except SignInError:
                pass
        factors = [f for f in user.get("factors") or []
                   if f.get("status") == "verified" and f.get("factor_type", "totp") == "totp"]
        if not factors:
            self.access_token = self.refresh_token = None
            raise SignInError(f"Set up two-factor first: sign in at {self.site} and follow the steps, "
                              "then sign in here.")
        self._factor = factors[0]["id"]

    def verify(self, code):
        """Step 2: the 6-digit code from the authenticator app. Afterwards the session is two-factor (aal2)."""
        code = "".join(ch for ch in str(code) if ch.isdigit())
        if len(code) != 6:
            raise SignInError("Enter the 6-digit code from your authenticator app.")
        if not self._factor or not self.access_token:
            raise SignInError("Enter your email and password first.")
        ch = self._call("POST", f"/auth/v1/factors/{self._factor}/challenge", {}, token=self.access_token)
        try:
            res = self._call("POST", f"/auth/v1/factors/{self._factor}/verify",
                             {"challenge_id": ch["id"], "code": code}, token=self.access_token)
        except SignInError as e:
            if getattr(e, "status", 0) in (400, 401, 422):
                raise SignInError("That code didn't work. Codes change every 30 seconds: "
                                  "enter the one showing now.") from None
            raise
        with self._lock:
            self._take(res)
        if self.aal != "aal2":
            raise SignInError("Two-factor sign-in didn't complete. Try again.")

    def sign_in(self, email, password, code):
        self.start(email, password)
        self.verify(code)
        return self

    @classmethod
    def resume(cls, refresh_token, **kw):
        """Carry on from a saved sign-in. Raises SignedOut if it no longer works."""
        s = cls(**kw)
        s.refresh_token = refresh_token
        s.refresh()
        return s

    # ---------------------------------------------------------------- tokens
    def refresh(self, stale_token=None):
        """Swap the refresh token for a new access token. With stale_token, only if no other thread already has."""
        with self._lock:
            if stale_token is not None and self.access_token and self.access_token != stale_token:
                return self.access_token
            newer = self._saved()
            if newer and newer != self.refresh_token:
                self.refresh_token = newer                 # another window renewed it: carry on from that one
            if not self.refresh_token:
                raise SignedOut("Not signed in.")
            for attempt in (1, 2):
                try:
                    res = self._call("POST", "/auth/v1/token?grant_type=refresh_token",
                                     {"refresh_token": self.refresh_token})
                    break
                except SignInError as e:
                    if getattr(e, "status", 0) not in (400, 401, 403):
                        raise                              # offline or server trouble: not signed out
                    newer = self._saved()
                    if attempt == 1 and newer and newer != self.refresh_token:
                        self.refresh_token = newer         # renewed elsewhere a moment ago: try that one
                        continue
                    raise SignedOut("Your sign-in has expired or was ended (for example after a password "
                                    "change, or by an admin). Sign in again (RCL Web Package > Sign in).") from None
            self._take(res)
            return self.access_token

    def _saved(self):
        if not self.load_saved:
            return None
        try:
            return self.load_saved()
        except Exception:  # noqa
            return None

    def token(self):
        """A current access token, renewed shortly before it runs out. Safe to call from any thread."""
        with self._lock:
            if not self.access_token or self.expires_at - time.time() < REFRESH_EARLY:
                return self.refresh()
            return self.access_token

    def sign_out(self):
        with self._lock:
            if self.access_token:
                try:
                    self._call("POST", "/auth/v1/logout?scope=local", {}, token=self.access_token)
                except SignInError:
                    pass
            self.access_token = self.refresh_token = None
            self.expires_at = 0
