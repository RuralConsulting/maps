"""A detailed log of each build and publish, kept on this computer for when something goes wrong.

Logs go in <QGIS profile>/rcl_web_package/logs/ (the last 40 are kept). Each one records the plugin, QGIS, Python and
Windows versions, the packages folder and its drive (type and free space), the temporary folder, every layer with its
source and options, every step with its time, and, on failure, the full error chain (including Windows error codes and
file names) plus a listing of the files written so far. Nothing in it is sent anywhere.
"""
import datetime
import os
import platform
import shutil
import sys
import tempfile
import time
import traceback

KEEP = 40


def log_dir():
    try:
        from qgis.core import QgsApplication
        base = QgsApplication.qgisSettingsDirPath()
    except Exception:  # noqa
        base = tempfile.gettempdir()
    d = os.path.join(base, "rcl_web_package", "logs")
    os.makedirs(d, exist_ok=True)
    return d


def _plugin_version():
    try:
        meta = os.path.join(os.path.dirname(os.path.dirname(__file__)), "metadata.txt")
        for line in open(meta, encoding="utf-8"):
            if line.startswith("version="):
                return line.split("=", 1)[1].strip()
    except OSError:
        pass
    return "?"


def _qgis_version():
    try:
        from qgis.core import Qgis
        return Qgis.QGIS_VERSION
    except Exception:  # noqa
        return "?"


def drive_info(path):
    """'NTFS, 76.2 GB free of 475.0 GB' (file system name on Windows: shows network and Egnyte drives)."""
    p = path
    while p and not os.path.exists(p):
        parent = os.path.dirname(p)
        if parent == p:
            break
        p = parent
    bits = []
    try:
        if os.name == "nt":
            import ctypes
            root = os.path.splitdrive(os.path.abspath(p))[0] + "\\"
            fs = ctypes.create_unicode_buffer(64)
            name = ctypes.create_unicode_buffer(256)
            maxlen = ctypes.c_ulong()
            flags = ctypes.c_ulong()
            if ctypes.windll.kernel32.GetVolumeInformationW(root, name, 256, None, ctypes.byref(maxlen),
                                                             ctypes.byref(flags), fs, 64):
                bits.append(f"{fs.value or '?'} file system, volume '{name.value}'")
            kind = ctypes.windll.kernel32.GetDriveTypeW(root)
            bits.append({2: "removable", 3: "local disk", 4: "network drive", 5: "CD", 6: "RAM disk"}.get(kind, f"drive type {kind}"))
    except Exception:  # noqa
        pass
    try:
        u = shutil.disk_usage(p)
        bits.append(f"{u.free / 1e9:.1f} GB free of {u.total / 1e9:.1f} GB")
    except OSError as e:
        bits.append(f"free space unknown ({e})")
    return ", ".join(bits)


def describe_error(e):
    """Every exception in the chain, with errno / Windows error / file names where present."""
    out = []
    seen = set()
    while e is not None and id(e) not in seen:
        seen.add(id(e))
        line = f"{type(e).__name__}: {e}"
        extra = []
        for attr in ("errno", "winerror", "filename", "filename2", "strerror"):
            v = getattr(e, attr, None)
            if v not in (None, ""):
                extra.append(f"{attr}={v!r}")
        if extra:
            line += "  [" + ", ".join(extra) + "]"
        out.append(line)
        e = e.__cause__ or e.__context__
    return "\n".join(out)


def listing(folder, limit=200):
    """Files under folder with sizes (largest first), for 'how far did it get'."""
    rows = []
    try:
        for root, _, names in os.walk(folder):
            for n in names:
                p = os.path.join(root, n)
                try:
                    rows.append((os.path.getsize(p), os.path.relpath(p, folder)))
                except OSError as e:
                    rows.append((-1, f"{os.path.relpath(p, folder)} (can't read size: {e})"))
    except OSError as e:
        return f"  (can't list {folder}: {e})"
    rows.sort(reverse=True)
    total = sum(s for s, _ in rows if s > 0)
    lines = [f"  {len(rows)} files, {total / 1e6:.1f} MB"]
    lines += [f"  {s / 1e6:10.1f} MB  {r}" if s >= 0 else f"  {'?':>10}     {r}" for s, r in rows[:limit]]
    if len(rows) > limit:
        lines.append(f"  ... and {len(rows) - limit} more")
    return "\n".join(lines)


class BuildLog:
    def __init__(self, what="build"):
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        self.path = os.path.join(log_dir(), f"{what}-{stamp}.log")
        self.t0 = time.time()
        self._last = None
        self._prune()
        self.write(f"RCL Web Package {what} log, {datetime.datetime.now():%Y-%m-%d %H:%M:%S}")
        self.write(f"plugin {_plugin_version()}, QGIS {_qgis_version()}, Python {sys.version.split()[0]}, "
                   f"{platform.platform()}")
        tmp = tempfile.gettempdir()
        self.write(f"temporary folder: {tmp} ({drive_info(tmp)})")

    def _prune(self):
        try:
            d = os.path.dirname(self.path)
            logs = sorted(f for f in os.listdir(d) if f.endswith(".log"))
            for f in logs[:-KEEP]:
                os.remove(os.path.join(d, f))
        except OSError:
            pass

    def write(self, text):
        try:
            with open(self.path, "a", encoding="utf-8") as fh:
                fh.write(text.rstrip("\n") + "\n")
        except OSError:
            pass

    def section(self, title, body=""):
        self.write(f"\n== {title}")
        if body:
            self.write(body)

    def step(self, msg):
        """A progress message, written once each time it changes, with the elapsed time."""
        if msg and msg != self._last:
            self._last = msg
            self.write(f"[{time.time() - self.t0:8.1f}s] {msg}")

    def folder(self, label, path):
        self.write(f"{label}: {path} ({drive_info(path)})")

    def failure(self, e, during="", folders=()):
        self.section("FAILED", f"during: {during}")
        self.write(describe_error(e))
        self.section("traceback", "".join(traceback.format_exception(type(e), e, e.__traceback__)))
        for label, path in folders:
            if path and os.path.isdir(path):
                self.section(f"files in {label} ({path})", listing(path))
        tmp = tempfile.gettempdir()
        try:
            left = [os.path.join(tmp, n) for n in os.listdir(tmp) if n.startswith("rclpkg_")]
        except OSError:
            left = []
        for p in left[-5:]:
            self.section(f"temporary build folder {p}", listing(p, limit=20))
        self.write(f"\ntotal time {time.time() - self.t0:.1f}s")

    def done(self, summary=""):
        self.section("finished", summary)
        self.write(f"total time {time.time() - self.t0:.1f}s")

    def text(self):
        try:
            return open(self.path, encoding="utf-8").read()
        except OSError:
            return ""
